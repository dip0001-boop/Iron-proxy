import http from 'node:http';
import { readFile } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import path from 'node:path';
import { createLogin, getLogin, logout, createTab, deleteTab, clearTabs, diagnostics, cleanup, equalSecret, getCap, writeDocumentState } from './sessions.js';
import { decodeBrowserPath, browserProxyPath } from './security.js';
import { proxyRequest, closeTransport } from './network.js';
import { schedulerStats } from './scheduler.js';
import { acceptUpgrade, websocketStats } from './websockets.js';
import { serveAdvancedAsset, routeWisp, advancedStats } from './advanced.js';

const VERSION = '0.4.0';
const ACCESS = process.env.IRON_ACCESS_KEY;
if (!ACCESS || ACCESS.length < 16) {
  console.error('IRON_ACCESS_KEY must be set to at least 16 characters. Startup aborted.');
  process.exit(1);
}
const PORT = Number(process.env.PORT || 10000);
const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../public');
const isProd = process.env.NODE_ENV === 'production';
const attempts = new Map();
const proxyRates = new Map();
const begunAt = Date.now();

function json(res, status, value) {
  res.writeHead(status, { 'Content-Type':'application/json; charset=utf-8', 'Cache-Control':'no-store', 'X-Content-Type-Options':'nosniff' });
  res.end(JSON.stringify(value));
}
function fail(res, status, message) { json(res, status, { error: message }); }
function getCookie(req, name) {
  const m = (req.headers.cookie || '').match(new RegExp(`(?:^|;\\s*)${name}=([^;]*)`));
  return m ? decodeURIComponent(m[1]) : '';
}
function originOkay(req) {
  const origin = req.headers.origin;
  if (!origin) return true; // non-browser CLI may omit Origin; still requires client header + login.
  if (process.env.IRON_PUBLIC_ORIGIN && origin === process.env.IRON_PUBLIC_ORIGIN) return true;
  return origin === `https://${req.headers.host}` || origin === `http://${req.headers.host}`;
}
function clientOkay(req) { return req.headers['x-iron-client'] === '1' && originOkay(req); }
function auth(req) {
  const token = getCookie(req, 'iron_session');
  return getLogin(token) ? token : null;
}
async function bodyJson(req, sizeLimit = 10_000) {
  let count = 0; let chunks = [];
  for await (const chunk of req) {
    count += chunk.length;
    if (count > sizeLimit) throw new Error('Request is too large');
    chunks.push(chunk);
  }
  try { return JSON.parse(Buffer.concat(chunks).toString('utf8')); }
  catch { throw new Error('Invalid JSON'); }
}
function remoteAddress(req) { return req.socket.remoteAddress || 'unknown'; }
function limited(map, key, maximum, windowMs) {
  const now = Date.now();
  const entry = map.get(key);
  if (!entry || entry.until <= now) { map.set(key, { total: 1, until: now + windowMs }); return false; }
  entry.total++;
  return entry.total > maximum;
}
function allowCorsPreflight(res) {
  res.writeHead(204, {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods':'GET, POST, HEAD, PUT, PATCH, DELETE, OPTIONS',
    'Access-Control-Allow-Headers':'content-type, accept, authorization, range, x-requested-with',
    'Access-Control-Max-Age':'600',
    'Cache-Control':'no-store'
  });
  res.end();
}
async function handleApi(req, res, url) {
  if (!clientOkay(req)) return fail(res, 403, 'Browser client header or origin missing');
  if (url.pathname === '/api/login' && req.method === 'POST') {
    const ip = remoteAddress(req);
    if (limited(attempts, ip, 8, 10 * 60_000)) return fail(res, 429, 'Too many attempts. Retry later.');
    const payload = await bodyJson(req);
    if (!equalSecret(payload.password, ACCESS)) return fail(res, 401, 'Incorrect access key');
    attempts.delete(ip);
    const token = createLogin();
    res.setHeader('Set-Cookie', `iron_session=${token}; HttpOnly; Path=/; SameSite=Lax; Max-Age=43200${isProd ? '; Secure' : ''}`);
    return json(res, 200, { ok: true, version: VERSION });
  }
  const token = auth(req);
  if (!token) return fail(res, 401, 'Login required');
  if (url.pathname === '/api/session' && req.method === 'GET') return json(res, 200, { ok: true, version: VERSION, searchConfigured: !!process.env.BRAVE_SEARCH_API_KEY, engines: ['native','compat'], advancedEngine: 'Scramjet 2.x (third-party)'  });
  if (url.pathname === '/api/logout' && req.method === 'POST') {
    logout(token);
    res.setHeader('Set-Cookie', `iron_session=; HttpOnly; Path=/; SameSite=Lax; Max-Age=0${isProd ? '; Secure' : ''}`);
    return json(res, 200, { ok: true });
  }
  if (url.pathname === '/api/tabs' && req.method === 'POST') return json(res, 201, createTab(token));
  if (url.pathname.startsWith('/api/tabs/') && req.method === 'DELETE') {
    const cap = url.pathname.slice('/api/tabs/'.length);
    const deleted = deleteTab(cap, token);
    return json(res, deleted ? 200 : 404, { ok: deleted });
  }
  if (url.pathname === '/api/tabs' && req.method === 'DELETE') {
    clearTabs(token);
    return json(res, 200, { ok:true });
  }
  if (url.pathname === '/api/diagnostics' && req.method === 'GET') return json(res, 200, { ...diagnostics(), ...schedulerStats(), ...websocketStats(), ...advancedStats(), version: VERSION, ageSeconds: Math.round((Date.now() - begunAt)/1000) });
  if (url.pathname === '/api/search' && req.method === 'GET') {
    const query = (url.searchParams.get('q') || '').trim();
    if (!query || query.length > 500) return fail(res, 400, 'Search query must be 1-500 characters');
    if (!process.env.BRAVE_SEARCH_API_KEY) return fail(res, 503, 'Real search needs BRAVE_SEARCH_API_KEY in your Render environment');
    if (limited(proxyRates, `search:${token}`, 25, 60_000)) return fail(res, 429, 'Search rate limit reached');
    const endpoint = new URL('https://api.search.brave.com/res/v1/web/search');
    endpoint.searchParams.set('q', query);
    endpoint.searchParams.set('count', '12');
    endpoint.searchParams.set('country', 'AU');
    endpoint.searchParams.set('search_lang', 'en');
    try {
      const result = await fetch(endpoint, {
        headers: { 'Accept':'application/json', 'X-Subscription-Token':process.env.BRAVE_SEARCH_API_KEY },
        signal: AbortSignal.timeout(12_000)
      });
      if (!result.ok) return fail(res, 502, `Search provider responded ${result.status}`);
      const data = await result.json();
      const results = (data.web?.results || []).slice(0, 12).map(item => ({ title: String(item.title || ''), url: String(item.url || ''), description: String(item.description || '') })).filter(x => /^https?:\/\//i.test(x.url));
      return json(res, 200, { query, provider:'Brave Search API', results });
    } catch { return fail(res, 502, 'Search provider unavailable'); }
  }
  return fail(res, 404, 'Unknown API endpoint');
}

const assets = {
  '/': ['index.html', 'text/html; charset=utf-8'],
  '/index.html': ['index.html', 'text/html; charset=utf-8'],
  '/app.css': ['app.css','text/css; charset=utf-8'],
  '/app.js': ['app.js','text/javascript; charset=utf-8']
};
const server = http.createServer(async (req, res) => {
  try {
    const url = new URL(req.url, 'http://local.invalid');
    if (url.pathname === '/healthz') return json(res, 200, { ok:true, name:'IRON', version: VERSION });
    if (url.pathname === '/sw.js') {
      if (!auth(req)) return fail(res, 401, 'Login required');
      const data = await readFile(path.join(ROOT, 'sw.js'));
      res.writeHead(200, { 'Content-Type':'text/javascript; charset=utf-8', 'Cache-Control':'no-store', 'Service-Worker-Allowed':'/', 'X-Content-Type-Options':'nosniff' });
      return res.end(data);
    }
    if (['/scram/', '/controller/', '/utils/', '/libcurl/'].some(prefix => url.pathname.startsWith(prefix))) {
      if (!auth(req)) return fail(res, 401, 'Login required');
      await serveAdvancedAsset(url.pathname, req, res);
      return;
    }
    if (url.pathname === '/scramjet-client.js') {
      const data = await readFile(path.join(ROOT, 'scramjet-client.js'));
      res.writeHead(200, { 'Content-Type':'text/javascript; charset=utf-8', 'Cache-Control':'no-store', 'X-Content-Type-Options':'nosniff' });
      return res.end(data);
    }
    if (url.pathname === '/robots.txt') { res.writeHead(200, { 'Content-Type':'text/plain', 'Cache-Control':'no-store' }); return res.end('User-agent: *\nDisallow: /\n'); }
    if (url.pathname.startsWith('/api/')) return await handleApi(req, res, url);
    if (url.pathname.startsWith('/_iron/state/')) {
      res.setHeader('Access-Control-Allow-Origin', '*');
      res.setHeader('Cache-Control', 'no-store');
      if (req.method === 'OPTIONS') return allowCorsPreflight(res);
      if (req.method !== 'POST') return fail(res, 405, 'Method not allowed');
      const match = url.pathname.match(/^\/_iron\/state\/([a-f0-9]{48})\/([a-f0-9]{32})$/);
      if (!match) return fail(res, 404, 'Invalid state endpoint');
      const tab = getCap(match[1]);
      if (!tab) return fail(res, 403, 'Tab session expired');
      if (limited(proxyRates, `state:${match[1]}`, 350, 60_000)) return fail(res, 429, 'State update rate limit');
      let payload;
      try { payload = await bodyJson(req, 70_000); } catch { return fail(res, 400, 'Invalid state payload'); }
      if (!await writeDocumentState(tab, match[2], payload)) return fail(res, 403, 'State update rejected');
      return json(res, 200, { ok: true });
    }
    if (url.pathname.startsWith('/p/')) {
      if (req.method === 'OPTIONS') return allowCorsPreflight(res);
      let parsed;
      try { parsed = decodeBrowserPath(url.pathname, url.search); }
      catch { return fail(res, 403, 'Blocked or invalid destination'); }
      const tab = getCap(parsed.cap);
      if (!tab) return fail(res, 403, 'Tab session expired or unavailable');
      if (limited(proxyRates, `tab:${parsed.cap}`, 450, 60_000)) return fail(res, 429, 'Tab rate limit reached');
      return await proxyRequest(req, res, tab, parsed.target);
    }
    const asset = assets[url.pathname];
    if (asset && req.method === 'GET') {
      const data = await readFile(path.join(ROOT, asset[0]));
      res.writeHead(200, {
        'Content-Type': asset[1],
        'Cache-Control':'no-store',
        'X-Frame-Options':'DENY',
        'Referrer-Policy':'no-referrer',
        'X-Content-Type-Options':'nosniff',
        'Content-Security-Policy':"default-src 'self'; script-src 'self' blob: 'wasm-unsafe-eval' 'unsafe-eval'; style-src 'self' 'unsafe-inline'; connect-src 'self' wss: ws:; frame-src 'self' blob:; worker-src 'self' blob:; img-src 'self' data: blob:; object-src 'none'; base-uri 'none'; form-action 'self'",
        'Cross-Origin-Opener-Policy':'same-origin',
        'Cross-Origin-Embedder-Policy':'require-corp'
      });
      return res.end(data);
    }
    return fail(res, 404, 'Not found');
  } catch (e) {
    if (!res.headersSent) return fail(res, e.statusCode || 400, e.message || 'Request failed');
    res.destroy();
  }
});
server.on('upgrade', (req, socket, head) => {
  if (routeWisp(req, socket, head, request => !!auth(request))) return;
  acceptUpgrade(req, socket, head);
});
server.headersTimeout = 15_000;
server.requestTimeout = 35_000;
server.keepAliveTimeout = 5_000;
server.listen(PORT, '0.0.0.0', () => console.log(`IRON ${VERSION} listening at 0.0.0.0:${PORT}`));
const sweeper = setInterval(() => {
  cleanup();
  for (const m of [attempts, proxyRates]) for (const [key, v] of m) if (v.until < Date.now()) m.delete(key);
}, 5 * 60_000);
sweeper.unref();
async function terminate() {
  server.close();
  clearInterval(sweeper);
  try { await closeTransport(); } catch {}
  process.exit(0);
}
process.on('SIGINT', terminate);
process.on('SIGTERM', terminate);
