# IRON Browser 0.4.0

**Read [`RELEASE-v0.4.md`](RELEASE-v0.4.md) for deployment, tests and warnings.**

IRON Browser contains two browsing engines: independent **IRON Native**, and third-party **Scramjet 2.x Compatibility Mode**. Attribution and licensing: [`THIRD_PARTY.md`](THIRD_PARTY.md).

## Running

Install Node 22+ and dependencies: `npm install`, then `npm run check && npm test`. Set `IRON_ACCESS_KEY` to a private secret of at least 16 characters and run `npm start`. Open `http://localhost:10000`.

Render build via archive: `tar -xzf iron-proxy-v0.4.0-render.tar.gz && cd iron-proxy && npm install --omit=dev && npm run check && npm test`. Start: `cd iron-proxy && npm start`.

**Compatibility mode has significant security and compatibility limitations.** Use a separate content origin to protect the shell before exposing it to arbitrary hostile sites, and do not use it for private accounts. This is an experimental prototype, not a secure general-purpose browser.
