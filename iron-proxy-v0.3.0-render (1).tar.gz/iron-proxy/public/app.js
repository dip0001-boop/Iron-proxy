const $ = (id) => document.getElementById(id);
const state = {
  tabs: [], current: null, view: 'home',
  history: readStore('iron-history', []),
  bookmarks: readStore('iron-bookmarks', []),
  settings: readStore('iron-settings', { theme:'graphite', reducedMotion:false, autoSuspend:true }),
  searchConfigured: false, closed: [], searchEngine: 'brave'
};
const $panel = $('panel');
const $frames = $('frames');
let toastTimer;

function readStore(key, fallback) {
  try { const val = JSON.parse(localStorage.getItem(key)); return val ?? fallback; }
  catch { return fallback; }
}
function saveStore(key, obj) {
  try { localStorage.setItem(key, JSON.stringify(obj)); } catch { showToast('Local storage unavailable'); }
}
function showToast(message) {
  $('toast').textContent = message;
  $('toast').classList.add('visible');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => $('toast').classList.remove('visible'), 3600);
}
async function api(route, options = {}) {
  const response = await fetch(route, {
    ...options,
    headers: { 'X-IRON-Client':'1', ...options.headers }
  });
  let result;
  try { result = await response.json(); } catch { result = {}; }
  if (!response.ok) throw new Error(result.error || `Server error ${response.status}`);
  return result;
}
function make(tag, cls, text) {
  const element = document.createElement(tag);
  if (cls) element.className = cls;
  if (text !== undefined) element.textContent = text;
  return element;
}
function currentTab() { return state.tabs.find(t => t.id === state.current); }
function titleFor(url) {
  if (!url) return 'New tab';
  try { return new URL(url).hostname; } catch { return url.slice(0, 35); }
}
function proxyPath(tab, url) {
  const parsed = new URL(url);
  if (!['https:', 'http:'].includes(parsed.protocol)) throw new Error('Only HTTP/HTTPS websites are supported');
  return `/p/${tab.cap}/${parsed.protocol.slice(0,-1)}/${parsed.host}${parsed.pathname}${parsed.search}${parsed.hash}`;
}
function applySettings() {
  document.documentElement.classList.toggle('theme-black', state.settings.theme === 'black');
  document.documentElement.classList.toggle('reduced-motion', !!state.settings.reducedMotion);
  $('bookmarksBar').classList.toggle('hidden', state.settings.bookmarkBar === false);
}
function setStatus(msg) { $('statusText').textContent = msg; }

async function newTab(options = {}) {
  if (state.tabs.length >= 12) return showToast('Maximum 12 tabs per session');
  let info;
  try { info = await api('/api/tabs', { method:'POST' }); }
  catch (e) { return showToast(e.message); }
  const frame = make('iframe', 'site-frame hidden');
  frame.setAttribute('sandbox', 'allow-scripts allow-forms allow-downloads allow-pointer-lock');
  frame.setAttribute('referrerpolicy', 'no-referrer');
  frame.setAttribute('allow', 'autoplay; fullscreen; picture-in-picture');
  frame.setAttribute('allowfullscreen', '');
  frame.setAttribute('loading', 'eager');
  frame.setAttribute('title', 'Sandboxed proxied site');
  const tab = { id:info.id, cap:info.cap, frame, url:'', title:'New tab', mode:'home', loading:false, stack:[], stackIndex:-1, private:!!options.private, lastActive:Date.now(), suspended:false };
  frame.addEventListener('load', () => {
    tab.loading = false;
    if (state.current === tab.id) { updateToolbar(); setStatus(`DOCUMENT LOADED / ${Math.round(performance.now() - (tab.startedAt || performance.now()))}ms`); }
  });
  $frames.appendChild(frame);
  state.tabs.push(tab);
  activate(tab.id);
  $('address').focus();
  if (options.private) showToast('Private tab: local history is off');
}
function activate(id) {
  if (!state.tabs.some(t => t.id === id)) return;
  state.current = id;
  const tab = currentTab();
  tab.lastActive = Date.now();
  if (tab.suspended && tab.url && tab.mode === 'site') {
    tab.suspended = false; tab.loading = true; tab.frame.src = proxyPath(tab, tab.url);
  }
  state.view = tab.mode;
  renderTabs(); render();
}
async function closeTab(id) {
  const index = state.tabs.findIndex(t => t.id === id);
  if (index < 0) return;
  const [tab] = state.tabs.splice(index, 1);
  if (!tab.private && tab.url) state.closed.unshift(tab.url);
  state.closed = state.closed.slice(0,10);
  // Dispose the frame immediately to halt scripts, resources and workers.
  tab.frame.src = 'about:blank'; tab.frame.remove();
  api(`/api/tabs/${tab.cap}`, { method:'DELETE' }).catch(() => {});
  if (!state.tabs.length) return newTab();
  if (state.current === id) state.current = state.tabs[Math.min(index, state.tabs.length-1)].id;
  state.view = currentTab().mode;
  renderTabs(); render();
}
function renderTabs() {
  const strip = $('tabStrip'); strip.replaceChildren();
  for (const tab of state.tabs) {
    const item = make('div', `tab ${tab.id === state.current ? 'active' : ''} ${tab.private ? 'private-tab' : ''}`);
    item.draggable = true;
    item.addEventListener('dragstart', e => { e.dataTransfer.setData('text/plain', tab.id); item.classList.add('dragging'); });
    item.addEventListener('dragend', () => item.classList.remove('dragging'));
    item.addEventListener('dragover', e => e.preventDefault());
    item.addEventListener('drop', e => { e.preventDefault(); const from = state.tabs.findIndex(t => t.id === e.dataTransfer.getData('text/plain')); const to = state.tabs.findIndex(t => t.id === tab.id); if(from < 0 || to < 0 || from === to)return; const [moved]=state.tabs.splice(from,1);state.tabs.splice(to,0,moved);renderTabs(); });
    item.setAttribute('role','tab'); item.setAttribute('aria-selected', tab.id === state.current ? 'true' : 'false');
    const icon = make('span','tab-favicon',tab.loading ? '◌' : (tab.private ? '◒' : (tab.url ? titleFor(tab.url).slice(0,1).toUpperCase() : '+')));
    const name = make('span','tab-title',tab.title);
    const close = make('button','tab-close','×'); close.title='Close tab (Ctrl+W)';
    close.addEventListener('click', e => { e.stopPropagation(); closeTab(tab.id); });
    item.addEventListener('click', () => activate(tab.id));
    item.append(icon,name,close); strip.appendChild(item);
  }
}
function setMode(mode) {
  const tab = currentTab(); if (!tab) return;
  tab.mode = mode; state.view = mode;
  renderTabs(); render(); closeMenu();
}
function isUrl(value) {
  const s = value.trim();
  if (/^https?:\/\//i.test(s)) return s;
  if (/^[a-z][a-z\d+.-]*:/i.test(s)) throw new Error('Only HTTP/HTTPS URLs are supported');
  if (/^(?:\[[0-9a-f:]+\]|localhost|[^\s]+\.[^\s]+)(?::\d+)?(?:\/[^\s]*)?$/i.test(s)) return `https://${s}`;
  return null;
}
async function omnibox(input) {
  const value = input.trim(); if (!value) return;
  let address;
  try { address = isUrl(value); }
  catch (e) { return showToast(e.message); }
  if (address) return navigate(address);
  return search(value);
}
function recordHistory(tab, url) {
  if (!tab.private) {
    state.history.unshift({ url, title:titleFor(url), at:Date.now() });
    state.history = state.history.slice(0,250);
    saveStore('iron-history', state.history);
  }
}
function navigate(url, opts = {}) {
  const tab = currentTab(); if (!tab) return;
  let canonical;
  try { canonical = new URL(url).href; tab.frame.src = proxyPath(tab, canonical); }
  catch { return showToast('Invalid HTTP or HTTPS address'); }
  tab.url = canonical; tab.title = titleFor(canonical); tab.loading = true; tab.startedAt = performance.now(); tab.suspended = false;
  if (!opts.backForward) {
    tab.stack.splice(tab.stackIndex + 1);
    tab.stack.push(canonical);
    tab.stackIndex = tab.stack.length - 1;
    recordHistory(tab, canonical);
  }
  tab.mode = 'site'; state.view = 'site';
  setStatus(`CONNECTING TO ${titleFor(canonical).toUpperCase()}`);
  renderTabs(); render();
}
async function search(query) {
  const tab = currentTab(); if (!tab) return;
  tab.mode = 'search'; tab.title = `Search: ${query}`; tab.searchQuery = query;
  state.view = 'search'; renderTabs(); render();
  const container = $('results'); if (!container) return;
  try {
    const data = await api(`/api/search?q=${encodeURIComponent(query)}`);
    if (tab !== currentTab() || tab.mode !== 'search' || tab.searchQuery !== query) return;
    container.replaceChildren();
    if (!data.results.length) container.appendChild(make('p','empty','No search results were returned by the provider.'));
    for (const result of data.results) {
      const button = make('button','result');
      button.append(make('div','url',result.url), make('h3',null,result.title),make('p',null,result.description));
      button.addEventListener('click', () => navigate(result.url));
      container.appendChild(button);
    }
    setStatus(`SEARCH RESULTS / ${data.provider.toUpperCase()}`);
  } catch (e) {
    if (container.isConnected) container.replaceChildren(make('p','empty', e.message));
    setStatus('SEARCH UNAVAILABLE');
  }
}
function openHome() { const tab=currentTab(); if (!tab) return; tab.mode='home';tab.title='New tab';tab.url='';state.view='home';renderTabs();render(); }
function openPrivateTab(){ return newTab({private:true}); }
function reopenClosed(){ const url=state.closed.shift(); if (!url) return showToast('No recently closed tab'); newTab().then(()=>navigate(url)); }
function back() {const t=currentTab();if(!t||t.stackIndex<=0)return; t.stackIndex--;navigate(t.stack[t.stackIndex],{backForward:true});}
function forward() {const t=currentTab();if(!t||t.stackIndex>=t.stack.length-1)return;t.stackIndex++;navigate(t.stack[t.stackIndex],{backForward:true});}
function reload() {const t=currentTab();if(!t)return;if(t.mode==='site'&&t.url){t.loading=true;t.frame.src=proxyPath(t,t.url);renderTabs();updateToolbar();}else render();}
function bookmarkCurrent() {
  const tab = currentTab(); if (!tab?.url) return showToast('Open a webpage first');
  const index = state.bookmarks.findIndex(x => x.url === tab.url);
  if (index >= 0) { state.bookmarks.splice(index,1); showToast('Bookmark removed'); }
  else { state.bookmarks.unshift({url:tab.url,title:tab.title,at:Date.now()}); showToast('Bookmark saved'); }
  saveStore('iron-bookmarks', state.bookmarks); updateToolbar(); renderBookmarksBar();
}
function updateToolbar() {
  const tab = currentTab(); if (!tab) return;
  $('address').value = tab.mode === 'site' ? tab.url : (tab.mode === 'search' ? tab.searchQuery || '' : '');
  $('back').disabled = tab.stackIndex <= 0;
  $('forward').disabled = tab.stackIndex >= tab.stack.length - 1;
  $('reload').disabled = tab.mode !== 'site';
  const saved = state.bookmarks.some(b => b.url === tab.url);
  $('bookmarkCurrent').textContent = saved ? '★' : '☆';
  $('schemeBadge').textContent = tab.mode === 'site' ? '◈' : '⌕';
  $('schemeBadge').title = 'Proxied view: this is not a native browser identity or security indicator';
  $('pageStatus').textContent = tab.mode === 'site' ? (tab.private ? 'PRIVATE TAB' : 'PROXY ISOLATED') : 'IRON SYSTEM';
  $('progress').classList.toggle('hidden',!tab.loading || tab.mode !== 'site');
  document.title = tab.mode === 'site' ? tab.title + ' — IRON Browser' : 'IRON Browser';
}
function render() {
  const tab = currentTab(); if (!tab) return;
  state.view = tab.mode;
  for (const t of state.tabs) t.frame.classList.toggle('hidden', t !== tab || tab.mode !== 'site');
  $panel.replaceChildren();
  $panel.classList.toggle('hidden-panel', tab.mode === 'site');
  if (tab.mode === 'home') renderHome();
  if (tab.mode === 'search') renderSearch(tab);
  if (tab.mode === 'bookmarks') renderCollection('bookmarks');
  if (tab.mode === 'history') renderCollection('history');
  if (tab.mode === 'settings') renderSettings();
  if (tab.mode === 'diagnostics') renderDiagnostics();
  if (tab.mode === 'downloads') renderDownloads();
  updateToolbar();
}
function pageShell(title, description) {
  const page = make('div','page');
  page.append(make('div','eyebrow','IRON / CONTROL CENTRE'), make('h1','panel-title',title),make('p','panel-subtitle',description));
  $panel.appendChild(page);
  return page;
}
function renderHome() {
  const page = make('div','page');
  const hero = make('div','hero');
  hero.append(make('div','hero-icon','◈'), make('div','eyebrow','AN INDEPENDENT BROWSING EXPERIMENT'));
  const h1 = make('h1'); h1.append('The web. ',make('span',null,'Reforged.'));
  hero.append(h1, make('p',null,'One browser workspace. Isolated tabs. An original proxy engine. Search or enter a URL to start exploring.'));
  const form=make('form','hero-search');const field=make('input');field.placeholder='Search the web or enter a website…';field.setAttribute('aria-label','Home search');const submit=make('button','primary','Explore ↗');submit.type='submit';form.append(field,submit);
  form.addEventListener('submit',e=>{e.preventDefault();omnibox(field.value);});hero.appendChild(form);
  const micro=make('div','hero-micro');['STREAMED TRANSPORT','TAB ISOLATION','ORIGINAL ENGINE'].forEach(s=>micro.append(make('span',null,s)));hero.appendChild(micro);
  page.appendChild(hero);
  const head=make('div','section-header');head.append(make('h2',null,'QUICK LAUNCH'),make('small',null,'BROWSE THE OPEN WEB'));page.appendChild(head);
  const tiles=make('div','tiles');
  for(const item of [{name:'Wikipedia',url:'https://en.wikipedia.org',icon:'◉',info:'Knowledge'},{name:'MDN Web Docs',url:'https://developer.mozilla.org',icon:'⌘',info:'Build & learn'},{name:'Example',url:'https://example.com',icon:'↗',info:'Test connectivity'},{name:'GitHub',url:'https://github.com',icon:'⌁',info:'Developer projects'}]){
    const b=make('button','tile');b.append(make('span','tile-icon',item.icon),make('strong',null,item.name),make('small',null,item.info));b.addEventListener('click',()=>navigate(item.url));tiles.appendChild(b);
  }
  page.appendChild(tiles);
  const banner=make('div','core-banner');const copy=make('div');copy.append(make('strong',null,'Powered by IRON CORE 0.3'),make('p',null,'Real HTTP transport · Isolated tabs · Browser workspace · Experimental compatibility'));
  banner.append(make('div','core-banner-badge','◈'),copy,make('span','badge-right','ALPHA BUILD'));page.appendChild(banner);
  $panel.appendChild(page);setStatus('NEW TAB / READY');
}
function renderSearch(tab) {
  const page = pageShell('Search the web', `Results for “${tab.searchQuery}” · Powered by a real web-search provider when configured.`);
  page.appendChild(make('div','results'));page.lastChild.id='results';page.lastChild.append(make('p','empty','Searching the web …'));
}
function renderCollection(type) {
  const items=state[type];const page=pageShell(type==='history'?'Your history':'Saved bookmarks',type==='history'?'Recent pages stored locally on this device.':'Your saved sites, one click away.');
  const container=make('div','list-box');
  if (!items.length) container.append(make('div','empty',`No ${type} yet.`));
  items.forEach((item,index)=>{
    const row=make('div','list-row');const open=make('button','row-main');open.append(make('strong',null,item.title||titleFor(item.url)),make('small',null,item.url));open.addEventListener('click',()=>navigate(item.url));
    const remove=make('button','row-delete','×');remove.title='Remove';remove.addEventListener('click',()=>{items.splice(index,1);saveStore(`iron-${type}`,items);render();});row.append(make('span',null,'◈'),open,remove);container.append(row);
  });page.appendChild(container);
  if (type==='history'&&items.length){const clear=make('button','small-btn','Clear browsing history');clear.style.marginTop='18px';clear.addEventListener('click',()=>{state.history=[];saveStore('iron-history',[]);render();});page.appendChild(clear);}
}
function renderDownloads(){
  const page=pageShell('Downloads','Downloads are handled by your real browser and its permissions.');
  const msg=make('div','download-explain','When an allowed download is started from a proxied page, your Chrome download manager handles the file. IRON does not currently have access to Chrome’s download history, and not every website download method works through the sandbox.');
  page.append(msg);
}
function renderBookmarksBar(){
  const holder=$('bookmarkShortcuts'); if(!holder)return; holder.replaceChildren();
  const visible=state.bookmarks.slice(0,8);
  if(!visible.length){ const placeholder=make('span','bookmark-chip','☆  Save a website using Ctrl+D'); holder.append(placeholder); return; }
  for(const entry of visible){ const b=make('button','bookmark-chip');b.append(make('span',null,'◈'),document.createTextNode(entry.title||titleFor(entry.url)));b.title=entry.url;b.addEventListener('click',()=>navigate(entry.url));holder.append(b);}
}
function addSettingCard(grid,heading,description) {const c=make('div','settings-card');c.append(make('h3',null,heading),make('p',null,description));grid.appendChild(c);return c;}
function renderSettings() {
  const page=pageShell('Browser settings','Change the appearance and control how IRON BROWSER stores local information.');const grid=make('div','settings-grid');
  const theme=addSettingCard(grid,'Appearance','A fast system-font interface with lightweight CSS effects.');
  const select=make('select');[['graphite','Metallic graphite'],['black','Midnight black']].forEach(([value,label])=>{const option=make('option',null,label);option.value=value;select.append(option);});select.value=state.settings.theme;select.addEventListener('change',()=>{state.settings.theme=select.value;saveStore('iron-settings',state.settings);applySettings();});theme.append(select);
  const bar=make('div','setting-row');const barLabel=make('label',null,'Show bookmarks bar');const barCheck=make('input');barCheck.type='checkbox';barCheck.checked=state.settings.bookmarkBar !== false;barCheck.addEventListener('change',()=>{state.settings.bookmarkBar=barCheck.checked;saveStore('iron-settings',state.settings);applySettings();});bar.append(barLabel,barCheck);theme.append(bar);
  const perf=addSettingCard(grid,'Performance','Reduce animation for low-power Chromebooks.');const line=make('div','setting-row');const label=make('label',null,'Reduced motion');const check=make('input');check.type='checkbox';check.checked=!!state.settings.reducedMotion;check.addEventListener('change',()=>{state.settings.reducedMotion=check.checked;saveStore('iron-settings',state.settings);applySettings();});line.append(label,check);perf.append(line);
  const suspend=make('div','setting-row');const suspendLabel=make('label',null,'Suspend idle background tabs (2 minutes)');const suspendCheck=make('input');suspendCheck.type='checkbox';suspendCheck.checked=state.settings.autoSuspend !== false;suspendCheck.addEventListener('change',()=>{state.settings.autoSuspend=suspendCheck.checked;saveStore('iron-settings',state.settings);});suspend.append(suspendLabel,suspendCheck);perf.append(suspend);
  const privacy=addSettingCard(grid,'Privacy & session','Site cookies are stored on the server in a separate jar per tab. They expire with the tab/session.');const privateBtn=make('button','small-btn',currentTab().private?'Private tab: ON':'Make current tab private');privateBtn.addEventListener('click',()=>{currentTab().private=!currentTab().private;showToast(currentTab().private?'This tab will no longer record local history':'Normal history recording restored');render();});privacy.append(privateBtn);
  const cache=addSettingCard(grid,'Local data','Bookmarks, history and appearance settings are stored in your browser’s local storage.');const clear=make('button','small-btn','Clear history and bookmarks');clear.addEventListener('click',()=>{state.history=[];state.bookmarks=[];saveStore('iron-history',[]);saveStore('iron-bookmarks',[]);showToast('Local data cleared');});cache.append(clear);
  const searchCard=addSettingCard(grid,'Search provider',state.searchConfigured?'Brave Search API is configured and uses live results.':'Brave Search API is not configured. Add BRAVE_SEARCH_API_KEY in Render to enable real search.');searchCard.append(make('span','eyebrow','BRAVE SEARCH / API'));
  const sess=addSettingCard(grid,'Session management','Signing out destroys this login and all its tab cookie jars.');const signout=make('button','small-btn','Sign out');signout.addEventListener('click',async()=>{await api('/api/logout',{method:'POST'}).catch(()=>{});location.reload();});sess.append(signout);
  page.appendChild(grid);
}
async function renderDiagnostics() {
  const page=pageShell('Core diagnostics','Live server telemetry for your IRON NETWORK process.');const grid=make('div','kv');page.appendChild(grid);
  try{const data=await api('/api/diagnostics');if(!grid.isConnected)return;for(const [name,value] of [['Memory usage',`${data.memoryMB} MB`],['Active browser tabs',data.activeTabs],['Open WebSockets',data.openWebSockets],['Requests in progress',data.activeRequests],['Authenticated sessions',data.logins],['Server uptime',`${data.uptimeSeconds}s`]]){const card=make('div','stat');card.append(make('strong',null,String(value)),make('small',null,name));grid.append(card);}const notice=make('p','panel-subtitle','These figures are IRON process diagnostics, not browser-wide CPU or actual page-load performance benchmarks.');page.append(notice);}catch(e){grid.append(make('div','empty',e.message));}
}
function attachListeners(){
  $('loginForm').addEventListener('submit', async e => {e.preventDefault();$('loginError').textContent='';try{await api('/api/login',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({password:$('password').value})});$('password').value='';await initialize();}catch(error){$('loginError').textContent=error.message;}});
  $('newTabButton').addEventListener('click',()=>newTab());
  $('privacyButton').addEventListener('click',openPrivateTab);
  $('showBookmarks').addEventListener('click',()=>setMode('bookmarks'));
  $('menuNewTab').addEventListener('click',()=>{closeMenu();newTab();});
  $('menuPrivate').addEventListener('click',()=>{closeMenu();openPrivateTab();});
  $('menuLogout').addEventListener('click',async()=>{closeMenu();await api('/api/logout',{method:'POST'}).catch(()=>{});location.reload();});
  $('menuButton').addEventListener('click',toggleMenu);
  $('menuScrim').addEventListener('click',closeMenu);
  $('addressForm').addEventListener('submit',e=>{e.preventDefault();omnibox($('address').value);});
  $('back').addEventListener('click',back);$('forward').addEventListener('click',forward);$('reload').addEventListener('click',reload);$('home').addEventListener('click',openHome);
  $('bookmarkCurrent').addEventListener('click',bookmarkCurrent);
  document.querySelectorAll('[data-view]').forEach(b=>b.addEventListener('click',()=>setMode(b.dataset.view)));
  document.addEventListener('keydown',e=>{
    if(e.key==='Escape'){closeMenu();const tab=currentTab();if(tab?.loading){tab.frame.src='about:blank';tab.loading=false;updateToolbar();setStatus('LOAD STOPPED');}return;}
    if((e.ctrlKey||e.metaKey) && e.shiftKey && e.key.toLowerCase()==='n'){e.preventDefault();openPrivateTab();return;}
    if((e.ctrlKey||e.metaKey) && e.shiftKey && e.key.toLowerCase()==='t'){e.preventDefault();reopenClosed();return;}
    if((e.ctrlKey||e.metaKey) && e.key.toLowerCase()==='d'){e.preventDefault();bookmarkCurrent();return;}
    if((e.ctrlKey||e.metaKey) && e.key.toLowerCase()==='b'){e.preventDefault();setMode('bookmarks');return;}
    if((e.ctrlKey||e.metaKey) && e.key.toLowerCase()==='h'){e.preventDefault();setMode('history');return;}
    if((e.ctrlKey||e.metaKey) && !e.shiftKey && /^[1-9]$/.test(e.key)){e.preventDefault();const t=state.tabs[Math.min(Number(e.key)-1,state.tabs.length-1)];if(t)activate(t.id);return;}
    const mod=e.ctrlKey||e.metaKey;
    if(mod&&e.key.toLowerCase()==='l'){e.preventDefault();$('address').focus();$('address').select();}
    if(mod&&e.key.toLowerCase()==='t'){e.preventDefault();newTab();}
    if(mod&&e.key.toLowerCase()==='w'){e.preventDefault();if(currentTab())closeTab(state.current);}
    if(mod&&e.key.toLowerCase()==='r'){e.preventDefault();reload();}
    if(mod&&e.key==='Tab'){e.preventDefault();const i=state.tabs.findIndex(t=>t.id===state.current);if(state.tabs.length)activate(state.tabs[(i+(e.shiftKey?-1:1)+state.tabs.length)%state.tabs.length].id);}
    if(e.altKey&&e.key==='ArrowLeft'){e.preventDefault();back();}if(e.altKey&&e.key==='ArrowRight'){e.preventDefault();forward();}
  });
  window.addEventListener('message',e=>{
    if(!e.data || !['iron:location','iron:title'].includes(e.data.type) || typeof e.data.url!=='string')return;
    // This is UNTRUSTED page-supplied data; never grant it shell privileges.
    const tab=state.tabs.find(t=>t.frame.contentWindow===e.source);if(!tab)return;
    let url;try{url=new URL(e.data.url);if(!['http:','https:'].includes(url.protocol))return;}catch{return;}
    const canonical=url.href;
    if(e.data.type==='iron:title' && canonical===tab.url && typeof e.data.title==='string'){
      tab.title=e.data.title.slice(0,100).trim() || titleFor(canonical);
      renderTabs();if(state.current===tab.id)updateToolbar();return;
    }
    if(e.data.type!=='iron:location')return;
    if(tab.url!==canonical){tab.url=canonical;tab.title=titleFor(canonical);tab.stack.splice(tab.stackIndex+1);tab.stack.push(canonical);tab.stackIndex=tab.stack.length-1;recordHistory(tab,canonical);renderTabs();if(state.current===tab.id)updateToolbar();}
  });
}
async function initialize(){
  const info=await api('/api/session');state.searchConfigured=info.searchConfigured;
  $('loginLayer').classList.add('hidden');$('workspace').classList.remove('hidden');
  applySettings();
  if(!state.tabs.length)await newTab();
  renderBookmarksBar();
}
function toggleMenu(){const opening=$('browserMenu').classList.contains('hidden');$('browserMenu').classList.toggle('hidden',!opening);$('menuScrim').classList.toggle('hidden',!opening);$('menuButton').setAttribute('aria-expanded',String(opening));}
function closeMenu(){$('browserMenu').classList.add('hidden');$('menuScrim').classList.add('hidden');$('menuButton').setAttribute('aria-expanded','false');}
attachListeners();applySettings();
api('/api/session').then(initialize).catch(()=>{$('loginLayer').classList.remove('hidden');});

// Memory-friendly background tab lifecycle on low-end hardware.
setInterval(() => {
  if (state.settings.autoSuspend === false) return;
  for (const tab of state.tabs) {
    if (tab.id !== state.current && tab.mode === 'site' && !tab.suspended && Date.now() - tab.lastActive > 120_000) {
      tab.frame.src = 'about:blank'; tab.suspended = true; tab.loading = false;
    }
  }
}, 60_000);
