# IRON BROWSER 0.3.0 — original proxy browser alpha

An **experimental Node.js browser-shell and proxy transport**, built independently of Ultraviolet, Rammerhead and Scramjet. This software does **not** include its own native HTML renderer: your real browser paints content inside intentionally sandboxed, per-tab iframes. It is not Chrome and does not provide Chrome's full security/origin/media stack.

## What's new in 0.3

### Browser-first interface (major redesign)
- Desktop browser window with horizontal draggable tabs, favicon-style site letters, active-tab indicator and close/new tab controls.
- Rounded omnibox, reload/back/forward/home, responsive toolbar, bookmark button and bookmark bar.
- Genuine browser pages for new tab, search results, bookmarks, history, settings, diagnostics and download information.
- Browser menu, private tabs, recently closed tab restoration (within current session), Ctrl+L/T/W/R/D/H/B/Shift+N/Shift+T, Ctrl+1–9, Alt+Left/Right.
- Website title updates from the isolated view back into the trusted shell (only for the frame that sent them, not arbitrary messages).
- Low-overhead dark UI; no UI libraries or build step; background tabs can be suspended after idle time.

### IRON CORE compatibility
- **Upstream Referer restoration:** requests issued by a proxied page send their actual original-page referer when available, not a fake Chrome fingerprint. State-changing requests use that page's origin, falling back to the target origin when the source is unavailable.
- JavaScript AST rule for `new URL('./asset.png', import.meta.url)` commonly emitted by bundlers.
- `fetch(Request)` best-effort remapping, streaming `EventSource` URL mapping, and server-scoped title updates.
- HTML transformation removes now-invalid SRI integrity attributes from transformed scripts/stylesheets; understand the security tradeoff.
- Sandboxed game views can request Pointer Lock where browser permission allows it.
- Existing HTTP Range / binary streaming, WebSocket bridge, scoped cookie jars, JS import rewriting and safe URL validation remain.
- Regression tests for resource mappings, unsafe-input encoding, the browser shell, SSRF, referrers and HTTP streaming.

## What this cannot promise

- **No CAPTCHA or anti-bot bypass:** websites can detect Render datacenter traffic and may challenge it. Pretending to be Chrome using user-agent headers is neither reliable nor equivalent to running Chrome. Google can still reject searches. Use a legitimate search API configured in the omnibox rather than automated Google HTML scraping.
- **Video / games:** MediaSource and YouTube playback, WASM workers, third-party login, DRM/EME, WebRTC, complex sandbox cross-origin APIs and games are **not fully supported**. Page load is not proof of playback.
- **Isolation:** Sandboxed iframes have opaque origins, and many native APIs work differently. Do not add `allow-same-origin` to the current same-origin shell/iframe layout; doing so with scripts would destroy its sandbox boundary. The script runtime virtualization is incomplete.
- **Security:** Tab capabilities are bearer tokens embedded in routed resources. A third-party page can discover the tab's proxy capability. Do not expose this service as an anonymous public relay. Do not enter sensitive passwords or banking information in proxied websites. This is an unaudited alpha.
- **Privacy:** Using IRON does not hide the Render server's outbound IP or guarantee anonymity. Browser UI data is stored in localStorage; server cookie jars and site state live in memory and vanish on restart.
- **Performance:** No superiority claim compared to UV/Rammerhead/Scramjet; comparable real-world benchmarks still needed.

## Render deployment — existing one-file archive workflow

1. Download `iron-proxy-v0.3.0-render.tar.gz` and upload that single file to the **root** of your existing GitHub repository (Add file → Upload files → Commit). Leave earlier archive releases in place as rollback options.
2. In Render, open your existing Web Service → Settings → Build & Deploy.
3. Set Build Command to:

```sh
tar -xzf iron-proxy-v0.3.0-render.tar.gz && cd iron-proxy && npm install --omit=dev && npm test
```

4. Keep Start Command:

```sh
cd iron-proxy && npm start
```

5. Leave Root Directory empty and reuse the existing `IRON_ACCESS_KEY` environment variable. Optionally add `BRAVE_SEARCH_API_KEY` to enable real omnibox web search. Set `NODE_ENV=production`; do not enable test loopback exceptions.
6. Deploy the latest commit. Check `/healthz`, which should return `{"ok":true,"name":"IRON","version":"0.3.0"}`. Test navigation and the browser menu before testing complex media.
7. If a build or test fails, view the Render logs. To roll back, restore the prior working archive build command and deploy the previous release. **Do not assume a successful build means every website works.**

The Render service's `PORT` is read automatically, and the server binds to `0.0.0.0`. Graceful shutdown and a `/healthz` endpoint are already implemented.

## Local installation (Node 22.19+)

```sh
npm install
npm test
# configure IRON_ACCESS_KEY environment variable with a unique 16+ character secret
npm start
```

## Test results in preparation environment

Passed: dependency-free bootstrap-code tests (2), static browser-shell test (1), `node --check` syntax on project JS. Existing HTTP/JS integration and WebSocket test files are provided but **not run here** because npm package downloads were unavailable. The Chromium visual screenshot attempt did not complete. Run `npm test` on Render after installing dependencies; fixes for any test failures must precede production use.

## Project layout

```
iron-proxy/
  package.json
  render.yaml
  .env.example
  src/
    server.js          # password auth, session API, static assets, diagnostics
    security.js        # safe URL validation / DNS blocking / proxy routes
    network.js         # streaming HTTP transport, headers, media range responses
    rewriter.js        # HTML & CSS structural rewriting
    javascript.js      # targeted JavaScript AST rewriting
    compat.js          # per-tab sandbox compatibility runtime
    sessions.js        # cookie jars, site storage, session tickets, tab cleanup
    websockets.js      # bounded WebSocket tunnel
    scheduler.js       # bounded request concurrency
  public/
    index.html         # browser shell
    app.css            # responsive UI
    app.js             # tabs, navigation, views, keyboard shortcuts
  test/                # core, bootstrap, HTTP/WS and static UI tests
  scripts/bench.js     # baseline request benchmark, not a browser compatibility test
```
