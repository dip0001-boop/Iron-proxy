// End-to-end latency sampler for IRON. This is NOT a comparison with other proxies.
// Usage: IRON_ACCESS_KEY='...' npm run bench -- --base http://localhost:10000 --target https://example.com --runs 20
const args = process.argv.slice(2);
function arg(name, fallback) { const idx=args.indexOf(name);return idx===-1?fallback:args[idx+1]; }
const root=arg('--base','http://localhost:10000');
const target=arg('--target','https://example.com/');
const runs=Math.min(100,Math.max(3,Number(arg('--runs','20'))));
const pass=process.env.IRON_ACCESS_KEY;
if(!pass){console.error('Set IRON_ACCESS_KEY before running this benchmark');process.exit(1);}
const login=await fetch(root+'/api/login',{method:'POST',headers:{'X-IRON-Client':'1','Content-Type':'application/json'},body:JSON.stringify({password:pass})});
if(!login.ok){console.error('Login failed',login.status);process.exit(1);}
const cookie=login.headers.get('set-cookie').split(';')[0];
const made=await fetch(root+'/api/tabs',{method:'POST',headers:{'X-IRON-Client':'1','Cookie':cookie}});
if(!made.ok){console.error('Create tab failed');process.exit(1);}
const tab=await made.json();
const dest=new URL(target);
const p=`/p/${tab.cap}/${dest.protocol.slice(0,-1)}/${dest.host}${dest.pathname}${dest.search}`;
const times=[];let successes=0;const errors=[];
for(let i=0;i<runs;i++){
  const begin=performance.now();
  try{
    const response=await fetch(root+p,{redirect:'follow'});await response.arrayBuffer();
    if(response.ok)successes++;else errors.push(response.status);
  }catch(e){errors.push(e.message)}
  times.push(performance.now()-begin);
}
const sorted=[...times].sort((a,b)=>a-b);
const percentile=p=>sorted[Math.min(sorted.length-1,Math.ceil(sorted.length*p)-1)].toFixed(1);
console.log(JSON.stringify({engine:'IRON 0.1',url:target,runs,successes,successRate:(100*successes/runs).toFixed(1)+'%',medianMs:percentile(.5),p95Ms:percentile(.95),errors},null,2));
await fetch(root+'/api/tabs/'+tab.cap,{method:'DELETE',headers:{'X-IRON-Client':'1',Cookie:cookie}});
