// Tiny bounded scheduler. No worker pool, no task spinning and no page-blocking
// operations. The slot remains held for a streamed response until it finishes.
const MAX_ACTIVE = 24;
const MAX_WAITING = 100;
let active = 0;
const waiting = [];

export async function scheduled(run) {
  if (active >= MAX_ACTIVE) {
    if (waiting.length >= MAX_WAITING) {
      const error = new Error('Too many concurrent requests');
      error.statusCode = 503;
      throw error;
    }
    await new Promise(resolve => waiting.push(resolve));
  } else {
    active++;
  }
  try { return await run(); }
  finally {
    // Hand the occupied slot directly to the next waiter, preserving the cap.
    const next = waiting.shift();
    if (next) next(); else active--;
  }
}
export function schedulerStats() { return { activeRequests: active, queuedRequests: waiting.length }; }
