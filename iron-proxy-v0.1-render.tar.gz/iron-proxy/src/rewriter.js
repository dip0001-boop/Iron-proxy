import * as parse5 from 'parse5';
import * as csstree from 'css-tree';
import { browserProxyPath } from './security.js';

const urlAttrs = new Set(['href', 'src', 'action', 'poster', 'data', 'formaction', 'cite', 'background', 'manifest', 'xlink:href']);

export function mapUrl(value, base, cap) {
  if (!value || /^\s*(?:data:|blob:|javascript:|mailto:|tel:|about:|#)/i.test(value)) return value;
  try {
    const u = new URL(value, base);
    if (!['http:', 'https:'].includes(u.protocol)) return value;
    return browserProxyPath(cap, u.href);
  } catch { return value; }
}

export function rewriteCss(css, base, cap) {
  try {
    const ast = csstree.parse(css, { parseValue: true, parseRulePrelude: false });
    csstree.walk(ast, (node) => {
      if (node.type === 'Url') {
        node.value = mapUrl(node.value, base, cap);
      }
      // @import 'file.css' is represented as a String node in an Atrule prelude.
      if (node.type === 'Atrule' && node.name.toLowerCase() === 'import' && node.prelude?.children) {
        const first = node.prelude.children.first;
        if (first?.type === 'String') first.value = mapUrl(first.value, base, cap);
      }
    });
    return csstree.generate(ast);
  } catch {
    // Fail closed on parsing failure: original stylesheet may be partly broken,
    // but we do not guess rewrites using a broad regex.
    return css;
  }
}

function rewriteSrcset(value, base, cap) {
  // Comma separation here covers ordinary srcset; data: URLs with commas are
  // retained and complex edge cases are documented as unsupported.
  return value.split(',').map(part => {
    const match = part.trim().match(/^(\S+)(\s+.*)?$/);
    return match ? mapUrl(match[1], base, cap) + (match[2] || '') : part;
  }).join(', ');
}

function getAttr(node, name) { return node.attrs?.find(a => a.name === name)?.value; }
function setAttr(node, name, value) {
  if (!node.attrs) node.attrs = [];
  const a = node.attrs.find(x => x.name === name);
  if (a) a.value = value;
  else node.attrs.push({ name, value });
}
function removeAttr(node, name) {
  if (node.attrs) node.attrs = node.attrs.filter(a => a.name !== name);
}

export function rewriteHtml(html, originalUrl, cap) {
  const document = parse5.parse(html);
  let base = originalUrl;
  // Honor the first legitimate <base href>, but never let it point the iframe
  // outside IRON's routed paths.
  function findBase(node) {
    if (node.tagName === 'base' && getAttr(node, 'href')) {
      try { base = new URL(getAttr(node, 'href'), originalUrl).href; } catch {}
      return true;
    }
    for (const c of node.childNodes || []) if (findBase(c)) return true;
    return false;
  }
  findBase(document);

  function walk(node) {
    if (node.tagName) {
      for (const attr of node.attrs || []) {
        if (urlAttrs.has(attr.name)) attr.value = mapUrl(attr.value, base, cap);
        if (attr.name === 'srcset' || attr.name === 'imagesrcset') attr.value = rewriteSrcset(attr.value, base, cap);
        if (attr.name === 'style') attr.value = rewriteCss(attr.value, base, cap);
      }
      if (node.tagName === 'base') setAttr(node, 'href', mapUrl(base, base, cap));
      if (node.tagName === 'a' || node.tagName === 'form') {
        removeAttr(node, 'ping');
        if (getAttr(node, 'target')) setAttr(node, 'target', '_self');
      }
      if (node.tagName === 'iframe') removeAttr(node, 'srcdoc');
      if (node.tagName === 'meta' && (getAttr(node, 'http-equiv') || '').toLowerCase() === 'content-security-policy') {
        setAttr(node, 'content', '');
      }
      if (node.tagName === 'meta' && (getAttr(node, 'http-equiv') || '').toLowerCase() === 'refresh') {
        const content = getAttr(node, 'content') || '';
        const m = content.match(/^(\s*\d+\s*;\s*url\s*=\s*)(.+)$/i);
        if (m) setAttr(node, 'content', m[1] + mapUrl(m[2].replace(/^["']|["']$/g, ''), base, cap));
      }
      if (node.tagName === 'style') {
        for (const c of node.childNodes || []) if (c.nodeName === '#text') c.value = rewriteCss(c.value, base, cap);
      }
    }
    for (const c of node.childNodes || []) walk(c);
  }
  walk(document);

  const script = bootstrap(cap);
  const fragment = parse5.parseFragment(`<script data-iron-bootstrap>${script.replace(/<\/script/gi, '<\\/script')}</script>`);
  let head;
  function seek(node) {
    if (node.tagName === 'head') { head = node; return; }
    for (const c of node.childNodes || []) if (!head) seek(c);
  }
  seek(document);
  if (head) {
    const inserted = fragment.childNodes[0];
    inserted.parentNode = head;
    head.childNodes.unshift(inserted);
  }
  return parse5.serialize(document);
}

function bootstrap(cap) {
  // This runs IN THE UNTRUSTED SANDBOX, not in the privileged browser shell.
  // It is an opt-in compatibility shim, not a complete JavaScript AST rewrite.
  return `(()=>{
    'use strict';
    const prefix='/p/${cap}/';
    const original=()=>{
      const m=location.pathname.match(/^\\/p\\/[a-f0-9]{48}\\/(https?)\\/([^/]+)(\\/.*)?$/);
      if(!m)return null;
      return m[1]+'://'+m[2]+(m[3]||'/')+location.search+location.hash;
    };
    const proxy=(input)=>{
      if(typeof input!=='string'&&!(input instanceof URL))return input;
      const s=String(input);
      if(/^(data:|blob:|javascript:|about:)/i.test(s))return input;
      try{
        const remote=new URL(s, original());
        if(!/^https?:$/.test(remote.protocol))return input;
        return prefix+remote.protocol.slice(0,-1)+'/'+remote.host+remote.pathname+remote.search+remote.hash;
      }catch{return input;}
    };
    const notify=()=>{try{parent.postMessage({type:'iron:location',url:original()},'*');}catch{}};
    addEventListener('DOMContentLoaded',notify);
    addEventListener('popstate',notify);
    addEventListener('hashchange',notify);
    const realFetch=window.fetch;
    if(realFetch)window.fetch=function(input,init){
      if(typeof input==='string'||input instanceof URL){
        return realFetch.call(this,proxy(input),{...init,credentials:'omit'});
      }
      return realFetch.call(this,input,init);
    };
    const realOpen=XMLHttpRequest.prototype.open;
    XMLHttpRequest.prototype.open=function(method,url,...rest){
      return realOpen.call(this,method,proxy(url),...rest);
    };
    try{
      const push=history.pushState, replace=history.replaceState;
      history.pushState=function(s,t,u){const r=push.call(this,s,t,u==null?u:proxy(u));notify();return r;};
      history.replaceState=function(s,t,u){const r=replace.call(this,s,t,u==null?u:proxy(u));notify();return r;};
    }catch{}
  })();`;
}
