import { randomBytes, timingSafeEqual } from 'node:crypto';
import { CookieJar } from 'tough-cookie';

export const randomSecret = (bytes = 24) => randomBytes(bytes).toString('hex');
export function equalSecret(a, b) {
  if (typeof a !== 'string' || typeof b !== 'string') return false;
  const ab = Buffer.from(a); const bb = Buffer.from(b);
  return ab.length === bb.length && timingSafeEqual(ab, bb);
}

const LOGIN_TTL = 12 * 60 * 60 * 1000;
const TAB_TTL = 2 * 60 * 60 * 1000;
const sessions = new Map();
const caps = new Map();

export function createLogin() {
  const token = randomSecret(32);
  sessions.set(token, { created: Date.now(), tabs: new Set() });
  return token;
}
export function getLogin(token) {
  const s = sessions.get(token);
  if (!s) return null;
  if (Date.now() - s.created > LOGIN_TTL) { logout(token); return null; }
  return s;
}
export function logout(token) {
  const s = sessions.get(token);
  if (!s) return;
  for (const cap of s.tabs) caps.delete(cap);
  sessions.delete(token);
}
export function createTab(token) {
  const session = getLogin(token);
  if (!session) throw new Error('Login required');
  if (session.tabs.size >= 12) throw new Error('Maximum 12 tabs');
  const cap = randomSecret();
  const tab = { cap, owner: token, cookies: new CookieJar(), created: Date.now(), accessed: Date.now(), requests: 0 };
  caps.set(cap, tab);
  session.tabs.add(cap);
  return { id: cap, cap };
}
export function getCap(cap) {
  const tab = caps.get(cap);
  if (!tab) return null;
  if (Date.now() - tab.accessed > TAB_TTL || !getLogin(tab.owner)) {
    deleteTab(cap);
    return null;
  }
  tab.accessed = Date.now();
  return tab;
}
export function deleteTab(cap, token) {
  const tab = caps.get(cap);
  if (!tab || (token && tab.owner !== token)) return false;
  caps.delete(cap);
  sessions.get(tab.owner)?.tabs.delete(cap);
  return true;
}
export function clearTabs(token) {
  const session = getLogin(token);
  if (!session) return;
  for (const cap of [...session.tabs]) deleteTab(cap, token);
}
export function diagnostics() {
  return { logins: sessions.size, activeTabs: caps.size, uptimeSeconds: Math.round(process.uptime()), memoryMB: Math.round(process.memoryUsage().rss / 1048576) };
}
export function cleanup() {
  for (const token of [...sessions.keys()]) getLogin(token);
  for (const cap of [...caps.keys()]) getCap(cap);
}
