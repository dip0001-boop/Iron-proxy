import { Agent, request } from 'undici';
import { pipeline } from 'node:stream/promises';
import { gunzipSync, inflateSync, brotliDecompressSync } from 'node:zlib';
import { pinnedPublicLookup, validateTarget, browserProxyPath } from './security.js';
import { rewriteCss, rewriteHtml } from './rewriter.js';
import { scheduled } from './scheduler.js';

const agent = new Agent({
  connections: 8,
  pipelining: 1,
  keepAliveTimeout: 10_000,
  connect: { timeout: 8_000, lookup: pinnedPublicLookup },
  headersTimeout: 15_000,
  bodyTimeout: 20_000
});
const MAX_REWRITE = 3_000_000;
const passHeaders = new Set(['accept', 'accept-language', 'range', 'if-none-match', 'if-modified-since', 'content-type']);
const permittedMethods = new Set(['GET','HEAD','POST']);

function upstreamHeaders(req, url, jarCookie) {
  const headers = { 'user-agent': 'IRON-Core/0.1 (+compatible Node transport)', 'accept-encoding': 'identity' };
  for (const [name, value] of Object.entries(req.headers)) {
    if (passHeaders.has(name) && typeof value === 'string') headers[name] = value;
  }
  if (jarCookie) headers.cookie = jarCookie;
  if (req.method === 'POST') headers.origin = url.origin;
  return headers;
}

async function toLimitedBuffer(body, max = MAX_REWRITE) {
  let size = 0;
  const chunks = [];
  for await (const chunk of body) {
    size += chunk.length;
    if (size > max) {
      body.destroy?.();
      const e = new Error('Document exceeds safe rewrite limit'); e.statusCode = 413; throw e;
    }
    chunks.push(chunk);
  }
  return Buffer.concat(chunks);
}

function decoded(buffer, encoding) {
  if (!encoding || encoding === 'identity') return buffer;
  if (encoding === 'gzip') return gunzipSync(buffer, { maxOutputLength: MAX_REWRITE });
  if (encoding === 'deflate') return inflateSync(buffer, { maxOutputLength: MAX_REWRITE });
  if (encoding === 'br') return brotliDecompressSync(buffer, { maxOutputLength: MAX_REWRITE });
  throw new Error('Unsupported compressed upstream content');
}

function writeStandard(res, status) {
  res.statusCode = status;
  res.setHeader('Referrer-Policy', 'no-referrer');
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('Cache-Control', 'private, no-store');
  // Sandboxed iframe has an opaque origin. Requests from it require CORS.
  // No credentials are exposed to it: remote cookies live only in tab jars.
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Cross-Origin-Resource-Policy', 'cross-origin');
}

export async function proxyRequest(req, res, tab, target) {
  return scheduled(() => executeRequest(req, res, tab, target));
}

async function executeRequest(req, res, tab, target) {
  if (!permittedMethods.has(req.method)) {
    res.writeHead(405, { Allow: 'GET, HEAD, POST' }).end('Method not allowed'); return;
  }
  if (req.method === 'POST' && Number(req.headers['content-length'] || 0) > 8_000_000) {
    res.writeHead(413, { 'Content-Type':'text/plain', 'Cache-Control':'no-store' }).end('Upload too large'); return;
  }
  const url = validateTarget(target.href);
  const cookie = await tab.cookies.getCookieString(url.href);
  let upstream;
  try {
    upstream = await request(url, {
      dispatcher: agent,
      method: req.method,
      headers: upstreamHeaders(req, url, cookie),
      body: req.method === 'POST' ? req : undefined,
      maxRedirections: 0,
      headersTimeout: 15_000,
      bodyTimeout: 20_000,
      signal: AbortSignal.timeout(30_000)
    });
  } catch (e) {
    res.writeHead(502, { 'Content-Type': 'text/plain; charset=utf-8', 'Cache-Control':'no-store' });
    res.end('IRON NETWORK could not connect to this website.');
    return;
  }
  // Store upstream cookies in the tab's private server-side jar.
  const setCookies = upstream.headers['set-cookie'];
  for (const item of (Array.isArray(setCookies) ? setCookies : setCookies ? [setCookies] : []).slice(0, 40)) {
    if ((tab.cookieWrites || 0) >= 2000) break;
    tab.cookieWrites = (tab.cookieWrites || 0) + 1;
    try { await tab.cookies.setCookie(item, url.href, { ignoreError: true }); } catch {}
  }

  const type = String(upstream.headers['content-type'] || 'application/octet-stream');
  const status = upstream.statusCode;
  writeStandard(res, status);
  // Never forward upstream cookies, CSP, frame policy, HSTS or auth challenges
  // to the proxy's own origin.
  res.setHeader('Content-Type', type);
  if (upstream.headers['content-disposition']) res.setHeader('Content-Disposition', String(upstream.headers['content-disposition']));
  if (upstream.headers['accept-ranges']) res.setHeader('Accept-Ranges', String(upstream.headers['accept-ranges']));
  if (upstream.headers['content-range']) res.setHeader('Content-Range', String(upstream.headers['content-range']));

  if (status >= 300 && status < 400 && upstream.headers.location) {
    const dest = validateTarget(new URL(String(upstream.headers.location), url.href).href);
    res.setHeader('Location', browserProxyPath(tab.cap, dest.href));
    upstream.body.destroy();
    res.end();
    return;
  }
  const html = /(?:^|\s|;)text\/html(?:;|$)/i.test(type);
  const css = /(?:^|\s|;)text\/css(?:;|$)/i.test(type);
  const transform = req.method !== 'HEAD' && status !== 204 && status !== 304 && (html || css);
  if (transform) {
    try {
      const raw = await toLimitedBuffer(upstream.body);
      const text = decoded(raw, String(upstream.headers['content-encoding'] || '').toLowerCase()).toString('utf8');
      const result = html ? rewriteHtml(text, url.href, tab.cap) : rewriteCss(text, url.href, tab.cap);
      res.end(result);
    } catch (e) {
      if (!res.headersSent) {
        res.statusCode = e.statusCode || 502;
        res.setHeader('Content-Type', 'text/plain; charset=utf-8');
        res.end('IRON CORE could not safely rewrite this document.');
      } else res.destroy(e);
    }
  } else if (req.method === 'HEAD' || status === 204 || status === 304) {
    upstream.body.destroy(); res.end();
  } else {
    if (upstream.headers['content-encoding']) res.setHeader('Content-Encoding', String(upstream.headers['content-encoding']));
    if (upstream.headers['content-length']) res.setHeader('Content-Length', String(upstream.headers['content-length']));
    try { await pipeline(upstream.body, res); }
    catch { if (!res.destroyed) res.destroy(); }
  }
}

export async function closeTransport() { await agent.close(); }
