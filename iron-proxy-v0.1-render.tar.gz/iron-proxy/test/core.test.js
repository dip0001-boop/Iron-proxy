import test from 'node:test';
import assert from 'node:assert/strict';
import { isPublicIp, validateTarget, browserProxyPath, decodeBrowserPath } from '../src/security.js';
import { mapUrl, rewriteHtml, rewriteCss } from '../src/rewriter.js';
const cap = 'a'.repeat(48);

test('SSRF guard blocks loopback, private, metadata and unsafe protocols', () => {
  for (const target of ['http://localhost/', 'http://127.0.0.1/', 'http://10.0.0.1/', 'http://169.254.169.254/', 'http://[::1]/', 'http://192.168.0.10/', 'http://1.1.1.1:3000/', 'file:///etc/passwd', 'http://admin:pw@example.com/']) {
    assert.throws(() => validateTarget(target), target);
  }
  assert.equal(isPublicIp('8.8.8.8'), true);
  assert.equal(isPublicIp('10.0.0.1'), false);
  assert.equal(validateTarget('https://example.com/a').href, 'https://example.com/a');
});

test('URLs roundtrip through the IRON route', () => {
  const remote = 'https://example.com/a/b?test=hello';
  const pathname = browserProxyPath(cap, remote);
  const result = decodeBrowserPath(new URL(pathname, 'https://iron.invalid').pathname, '?test=hello');
  assert.equal(result.cap, cap);
  assert.equal(result.target.href, remote);
});

test('HTML rewriting targets assets, links, forms and respects remote base', () => {
  const html = '<!doctype html><html><head><base href="https://example.com/folder/"><style>.a{background:url(/img.png)}</style></head><body><a href="next">next</a><img src="/pic.jpg"><form action="/submit"></form></body></html>';
  const rewritten = rewriteHtml(html, 'https://example.com/original', cap);
  assert.match(rewritten, /data-iron-bootstrap/);
  assert.match(rewritten, new RegExp(`/p/${cap}/https/example.com/folder/next`));
  assert.match(rewritten, new RegExp(`/p/${cap}/https/example.com/pic.jpg`));
  assert.match(rewritten, new RegExp(`/p/${cap}/https/example.com/submit`));
  assert.match(rewritten, new RegExp(`/p/${cap}/https/example.com/img.png`));
});

test('CSS rewriting only changes URL nodes', () => {
  const result = rewriteCss('.a{background:url("/hero.png");color:red}', 'https://example.com/page', cap);
  assert.match(result, /https\/example.com\/hero.png/);
  assert.match(result, /color:red/);
  assert.equal(mapUrl('data:image/png;base64,abc', 'https://example.com', cap), 'data:image/png;base64,abc');
});
