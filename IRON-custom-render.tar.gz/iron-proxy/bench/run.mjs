import { chromium } from 'playwright';
import { readFile, writeFile, mkdir } from 'node:fs/promises';
import { performance } from 'node:perf_hooks';
import os from 'node:os';
import { setTimeout as delay } from 'node:timers/promises';
import { startFixture, PASSWORD } from '../tests/fixture.js';

// No engine is bundled. Template adapters navigate real, separately deployed engines.
const argument = process.argv.slice(2).find(x => x !== '--self');
let fixture;
const config = argument ? JSON.parse(await readFile(argument, 'utf8')) : await (async () => {
  fixture = await startFixture();
  return { name: 'IRON deterministic development workload', repeats: 3, warmup: 1, concurrency: [1, 3], timeoutMs: 15000, network: { latencyMs: 0, downKbps: 0, upKbps: 0, cpuRate: 1 }, engines: [{ name: 'IRON 0.1', type: 'iron', baseURL: fixture.origin, password: PASSWORD }], workloads: [
    { name: 'Static HTML', url: fixture.upstream + '/other', selector: '#other', category: 'navigation' },
    { name: 'JS + modules + fetch + XHR', url: fixture.upstream + '/page', selector: 'body[data-dynamic="dynamic-ok"][data-fetch="fetch-ok"][data-xhr="xhr-ok"]', category: 'javascript' },
    { name: 'Redirect', url: fixture.upstream + '/redirect', selector: 'body[data-dynamic="dynamic-ok"]', category: 'redirect' },
    { name: 'WebSocket', url: fixture.upstream + '/page', selector: 'body[data-ws="echo-me"]', category: 'websocket' },
  ] };
})();
const launch = process.env.IRON_BROWSER_LAUNCH_FILE ? JSON.parse(await readFile(process.env.IRON_BROWSER_LAUNCH_FILE, 'utf8')) : { ...(process.env.CHROMIUM_EXECUTABLE_PATH ? { executablePath: process.env.CHROMIUM_EXECUTABLE_PATH } : {}), args: ['--no-sandbox'] };
const forbidden = launch.args?.filter(x => /disable-web-security|disable-site-isolation|single-process/.test(x));
if (forbidden?.length) throw new Error('Benchmark refuses browser flags that disable web isolation.');
const browser = await chromium.launch({ headless: true, ...launch });
const rows = []; const startup = []; const processSamples = [];
const percentile = (values, fraction) => values.length ? [...values].sort((a, b) => a - b)[Math.max(0, Math.ceil(values.length * fraction) - 1)] : null;
function encode(value, mode, xorKey = 2) {
  if (mode === 'base64') return Buffer.from(value).toString('base64');
  if (mode === 'base64url') return Buffer.from(value).toString('base64url');
  if (mode === 'xor') return encodeURIComponent([...value].map((c, i) => i % 2 ? String.fromCharCode(c.charCodeAt(0) ^ xorKey) : c).join(''));
  if (mode === 'raw') return value;
  return encodeURIComponent(value);
}
async function prepare(engine) {
  const begin = performance.now(); const context = await browser.newContext({ viewport: { width: 1280, height: 800 }, serviceWorkers: 'allow' }); const page = await context.newPage();
  const cdp = await context.newCDPSession(page); await cdp.send('Network.enable'); await cdp.send('Network.setCacheDisabled', { cacheDisabled: true }); await cdp.send('Performance.enable');
  const net = config.network || {};
  await cdp.send('Network.emulateNetworkConditions', { offline: false, latency: net.latencyMs || 0, downloadThroughput: net.downKbps ? net.downKbps * 1024 / 8 : -1, uploadThroughput: net.upKbps ? net.upKbps * 1024 / 8 : -1 });
  await cdp.send('Emulation.setCPUThrottlingRate', { rate: net.cpuRate || 1 });
  let csrf;
  if (engine.type === 'iron') {
    await page.goto(engine.baseURL, { waitUntil: 'domcontentloaded' });
    const password = engine.password || process.env[engine.passwordEnv || 'IRON_BENCH_PASSWORD'];
    if (!password) throw new Error(`Set ${engine.passwordEnv || 'IRON_BENCH_PASSWORD'} for ${engine.name}.`);
    await page.locator('#password').fill(password); await page.locator('#login-form button[type=submit]').click(); await page.locator('.tab-select').waitFor();
    const me = await (await context.request.get(engine.baseURL + '/api/me')).json(); csrf = me.csrf;
    const tabs = await (await context.request.get(engine.baseURL + '/api/tabs')).json();
    for (const tab of tabs.tabs) await context.request.post(`${engine.baseURL}/api/tabs/${tab.id}/settings`, { headers: { origin: engine.baseURL, 'x-iron-csrf': csrf }, data: { cacheEnabled: false } });
  } else {
    if (engine.bootstrapURL) await page.goto(engine.bootstrapURL, { waitUntil: 'load' });
    if (engine.waitForServiceWorker) await page.waitForFunction(async () => {
      const registrations = await navigator.serviceWorker.getRegistrations();
      return registrations.some(registration => registration.active);
    }, null, { timeout: config.timeoutMs || 20000 });
    if (engine.cookies) await context.addCookies(engine.cookies);
  }
  startup.push({ engine: engine.name, milliseconds: performance.now() - begin });
  const diagnostics = async () => {
    if (engine.type !== 'iron') {
      if (!engine.metricsURL) return null;
      try {
        const response = await fetch(engine.metricsURL, { headers: engine.metricsTokenEnv ? { authorization: `Bearer ${process.env[engine.metricsTokenEnv] || ''}` } : {}, signal: AbortSignal.timeout(2000) });
        return response.ok ? response.json() : null;
      } catch { return null; }
    }
    const r = await context.request.get(engine.baseURL + '/api/diagnostics'); return r.ok() ? r.json() : null;
  };
  return { context, page, cdp, engine, diagnostics, async dispose() { if (csrf) await context.request.post(engine.baseURL + '/api/logout', { headers: { origin: engine.baseURL, 'x-iron-csrf': csrf }, data: {} }).catch(() => {}); await context.close(); } };
}
async function run(worker, workload, concurrency, repetition, warmup) {
  if (config.pacingMs) await delay(config.pacingMs);
  const { page, context, engine } = worker; const errors = [];
  const onError = error => errors.push(error.message); page.on('pageerror', onError);
  const before = await worker.diagnostics(); const start = performance.now(); let success = false; let error; let heapBytes = null; let scriptCpuSeconds = null;
  try {
    if (engine.type === 'iron') {
      const committed = page.waitForEvent('framenavigated', { predicate: frame => frame.parentFrame() === page.mainFrame() && frame.url().includes('/p/'), timeout: config.timeoutMs || 20000 });
      await page.locator('#address').fill(workload.url); await page.locator('#address').press('Enter');
      await committed;
      await page.frameLocator('.browser-frame:not(.hidden)').locator(workload.selector).waitFor({ timeout: config.timeoutMs || 20000 });
    } else if (engine.type === 'template') {
      const destination = engine.urlTemplate.replace('{url}', encode(workload.url, engine.encoding, engine.xorKey));
      await page.goto(destination, { waitUntil: 'domcontentloaded', timeout: config.timeoutMs || 20000 });
      const scope = engine.frameSelector ? page.frameLocator(engine.frameSelector) : page;
      await scope.locator(workload.selector).waitFor({ timeout: config.timeoutMs || 20000 });
    } else throw new Error(`Unsupported adapter type: ${engine.type}`);
    success = true;
  } catch (e) { error = e.message.split('\n')[0]; }
  const durationMs = performance.now() - start;
  try {
    const { metrics } = await worker.cdp.send('Performance.getMetrics');
    const map = Object.fromEntries(metrics.map(m => [m.name, m.value]));
    heapBytes = map.JSHeapUsedSize ?? null; scriptCpuSeconds = map.TaskDuration ?? null;
  } catch { /* CDP metrics can be unavailable for some frame/process layouts; report null. */ }
  const after = await worker.diagnostics(); page.off('pageerror', onError);
  if (!warmup) rows.push({ engine: engine.name, workload: workload.name, category: workload.category, concurrency, repetition, success, durationMs, pageErrors: errors, error: error || null, rendererJsHeapBytes: heapBytes, rendererTaskSeconds: scriptCpuSeconds });
  if (!warmup && after && before) processSamples.push({ engine: engine.name, concurrency, rssBytes: after.memory.rss, cpuUserMicros: after.cpu.user - before.cpu.user, cpuSystemMicros: after.cpu.system - before.cpu.system, wallMs: durationMs, note: concurrency > 1 ? 'Overlapping process counters; do not sum samples.' : fixture ? 'Development fixture, engine and runner share one Node process.' : 'Server process counters.' });
  return success;
}
try {
  if (!config.engines?.length || !config.workloads?.length) throw new Error('Configuration needs at least one engine and workload.');
  for (const engine of config.engines) {
    const workerCount = Math.max(...config.concurrency); const workers = [];
    try {
      for (let i = 0; i < workerCount; i++) workers.push(await prepare(engine));
      for (const concurrency of config.concurrency) for (const workload of config.workloads) {
        for (let round = -(config.warmup || 0); round < (config.repeats || 3); round++) {
          const good = await Promise.all(workers.slice(0, concurrency).map(worker => run(worker, workload, concurrency, round, round < 0)));
          console.log(`${engine.name} | ${workload.name} | concurrency ${concurrency} | ${round < 0 ? 'warmup' : 'run ' + round} | ${good.filter(Boolean).length}/${good.length}`);
        }
      }
    } finally { for (const worker of workers) await worker.dispose(); }
  }
} finally { await browser.close(); await fixture?.close(); }
const summaries = [];
for (const engine of config.engines) for (const concurrency of config.concurrency) {
  const all = rows.filter(r => r.engine === engine.name && r.concurrency === concurrency); const successful = all.filter(r => r.success);
  const rate = category => { const subset = all.filter(r => r.category === category); return subset.length ? subset.filter(r => r.success).length / subset.length : null; };
  const samples = processSamples.filter(s => s.engine === engine.name && s.concurrency === concurrency);
  summaries.push({ engine: engine.name, concurrency, count: all.length, successRate: all.length ? successful.length / all.length : null, medianSuccessfulNavigationMs: percentile(successful.map(r => r.durationMs), .5), p95SuccessfulNavigationMs: percentile(successful.map(r => r.durationMs), .95), p95AllAttemptsMs: percentile(all.map(r => r.durationMs), .95), javascriptSuccessRate: rate('javascript'), redirectSuccessRate: rate('redirect'), websocketSuccessRate: rate('websocket'), peakSampledServerRssBytes: samples.length ? Math.max(...samples.map(s => s.rssBytes)) : null, medianRendererJsHeapBytes: percentile(successful.map(r => r.rendererJsHeapBytes).filter(v => v != null), .5), startupMedianMs: percentile(startup.filter(s => s.engine === engine.name).map(s => s.milliseconds), .5) });
}
const report = { schemaVersion: 1, createdAt: new Date().toISOString(), workload: config.name, selfTest: !!fixture, comparisonEstablished: false, methodology: 'Same Chromium process, viewport, cache-disabled warm sessions, explicit content-ready selectors, workload order, repetitions and CDP settings. Engine server caches must also be disabled in comparable deployments. No superior-engine claim is generated automatically.', host: { platform: os.platform(), arch: os.arch(), cpus: os.cpus().length, cpuModel: os.cpus()[0]?.model, totalMemoryBytes: os.totalmem(), node: process.version }, browser: browser.version(), network: config.network, engineVersions: config.engines.map(e => ({ name: e.name, commit: e.commit || 'UNRECORDED' })), summaries, startup, processSamples, samples: rows };
await mkdir('artifacts', { recursive: true }); await writeFile('artifacts/benchmark.json', JSON.stringify(report, null, 2));
console.log(JSON.stringify(summaries, null, 2));
if (rows.some(r => !r.success)) process.exitCode = 1;
