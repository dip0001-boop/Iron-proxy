import http from 'node:http';
import { readFile } from 'node:fs/promises';
import { execFileSync } from 'node:child_process';
import { timingSafeEqual } from 'node:crypto';

// Optional localhost-only Linux sampler for separately hosted competing engines.
// Run beside each engine: IRON_METRICS_TOKEN=... node bench/process-metrics.mjs PID PORT
const pid = Number(process.argv[2]); const port = Number(process.argv[3] || 9801);
const secret = process.env.IRON_METRICS_TOKEN;
if (!Number.isSafeInteger(pid) || pid < 1 || !secret || secret.length < 16) throw new Error('Provide a valid engine PID and IRON_METRICS_TOKEN of at least 16 characters.');
const ticks = Number(execFileSync('getconf', ['CLK_TCK'], { encoding: 'utf8' }).trim());
const server = http.createServer(async (req, res) => {
  const actual = Buffer.from(req.headers.authorization || ''); const expected = Buffer.from(`Bearer ${secret}`);
  if (actual.length !== expected.length || !timingSafeEqual(actual, expected)) { res.writeHead(401); res.end(); return; }
  if (req.method !== 'GET' || req.url !== '/metrics') { res.writeHead(404); res.end(); return; }
  try {
    const [stat, status] = await Promise.all([readFile(`/proc/${pid}/stat`, 'utf8'), readFile(`/proc/${pid}/status`, 'utf8')]);
    const fields = stat.slice(stat.lastIndexOf(')') + 2).split(' ');
    const rss = Number(status.match(/^VmRSS:\s+(\d+)\s+kB/m)?.[1]) * 1024;
    const data = { memory: { rss }, cpu: { user: Number(fields[11]) * 1e6 / ticks, system: Number(fields[12]) * 1e6 / ticks }, pid, scope: 'One Linux process; worker threads included, child processes excluded.' };
    res.writeHead(200, { 'content-type': 'application/json', 'cache-control': 'no-store' }); res.end(JSON.stringify(data));
  } catch { res.writeHead(503); res.end('{"error":"PROCESS_UNAVAILABLE"}'); }
});
server.listen(port, '127.0.0.1', () => console.log(`Process metrics listening on 127.0.0.1:${port}`));
for (const signal of ['SIGTERM', 'SIGINT']) process.on(signal, () => server.close());
