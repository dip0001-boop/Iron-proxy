import { spawn } from 'node:child_process';
import { randomBytes } from 'node:crypto';
import { setTimeout as delay } from 'node:timers/promises';
import { mkdir, writeFile } from 'node:fs/promises';
import http from 'node:http';
const samples = [];
for (let i = 0; i < 5; i++) {
  const port = await new Promise(resolve => { const probe = http.createServer(); probe.listen(0, '127.0.0.1', () => { const p = probe.address().port; probe.close(() => resolve(p)); }); });
  const start = performance.now();
  const child = spawn(process.execPath, ['src/server.js'], { env: { ...process.env, NODE_ENV: 'development', PORT: String(port), PUBLIC_ORIGIN: `http://127.0.0.1:${port}`, IRON_PASSWORD: randomBytes(24).toString('base64url'), BRAVE_SEARCH_API_KEY: '' }, stdio: 'ignore' });
  try {
    let healthy = false;
    while (performance.now() - start < 10000) { try { healthy = (await fetch(`http://127.0.0.1:${port}/health`, { signal: AbortSignal.timeout(100) })).ok; } catch {} if (healthy) break; await delay(10); }
    if (!healthy) throw new Error('Server failed to become healthy.');
    samples.push(performance.now() - start);
  } finally { const exit = new Promise(resolve => child.once('exit', resolve)); child.kill('SIGTERM'); await exit; }
}
samples.sort((a, b) => a - b); const data = { createdAt: new Date().toISOString(), node: process.version, metric: 'Local process spawn to successful /health response; 10 ms polling; no Render cold start claim.', samplesMs: samples, medianMs: samples[2] };
await mkdir('artifacts', { recursive: true }); await writeFile('artifacts/startup-benchmark.json', JSON.stringify(data, null, 2)); console.log(JSON.stringify(data, null, 2));
