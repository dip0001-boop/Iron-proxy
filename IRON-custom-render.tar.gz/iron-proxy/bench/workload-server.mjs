import http from 'node:http';
import { WebSocketServer } from 'ws';
const port = Number(process.env.PORT || 3001);
const send = (res, type, data, status = 200, headers = {}) => { res.writeHead(status, { 'content-type': type, 'cache-control': 'no-store', ...headers }); res.end(data); };
const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, 'http://fixture.invalid');
  if (url.pathname === '/health') return send(res, 'application/json', '{"ok":true,"fixtureVersion":1}');
  if (url.pathname === '/static') return send(res, 'text/html', '<!doctype html><title>Static workload</title><h1 data-bench-ready="true">IRON benchmark fixture v1</h1><p>Identical content for every engine.</p>');
  if (url.pathname === '/redirect') { res.writeHead(302, { location: '/redirect-two' }); return res.end(); }
  if (url.pathname === '/redirect-two') { res.writeHead(307, { location: '/static' }); return res.end(); }
  if (url.pathname === '/data') return send(res, 'application/json', '{"answer":42}');
  if (url.pathname === '/dep.js') return send(res, 'text/javascript', 'export const answer = 42;');
  if (url.pathname === '/module.js') return send(res, 'text/javascript', 'import {answer} from "./dep.js"; const next=await import("./dep.js"); const data=await (await fetch("/data")).json(); if(answer===42 && next.answer===42 && data.answer===42) document.body.dataset.benchReady="true";');
  if (url.pathname === '/javascript') return send(res, 'text/html', '<!doctype html><title>JavaScript workload</title><body><h1>JavaScript + modules + fetch</h1><script type="module" src="/module.js"></script></body>');
  if (url.pathname === '/websocket') return send(res, 'text/html', '<!doctype html><title>WebSocket workload</title><body><h1>WebSocket echo</h1><script>const socket=new WebSocket(location.origin.replace(/^http/,"ws")+"/echo"); socket.onopen=()=>socket.send("iron-workload-v1"); socket.onmessage=e=>{if(e.data==="iron-workload-v1")document.body.dataset.benchReady="true";socket.close();};</script></body>');
  if (url.pathname === '/form') {
    if (req.method === 'POST') { let length = 0; for await (const chunk of req) { length += chunk.length; if (length > 4096) { res.writeHead(413); res.end(); return; } } return send(res, 'text/html', '<!doctype html><title>Form result</title><body data-bench-ready="true"><h1>Form submitted</h1></body>'); }
    return send(res, 'text/html', '<!doctype html><title>Form workload</title><form method="post" action="/form"><input name="sample" value="iron"><button>Submit</button></form>');
  }
  send(res, 'text/plain', 'Choose /static, /javascript, /redirect or /websocket.', 404);
});
server.requestTimeout = 10000; server.headersTimeout = 5000;
const wss = new WebSocketServer({ server, path: '/echo', maxPayload: 4096, perMessageDeflate: false });
wss.on('connection', ws => { const timeout = setTimeout(() => ws.close(1000), 10000); ws.on('message', (data, binary) => ws.send(data, { binary })); ws.on('close', () => clearTimeout(timeout)); ws.on('error', () => {}); });
server.listen(port, '0.0.0.0', () => console.log(`Benchmark fixture v1 on 0.0.0.0:${port}`));
for (const signal of ['SIGTERM', 'SIGINT']) process.on(signal, () => { for (const ws of wss.clients) ws.terminate(); wss.close(); server.close(); });
