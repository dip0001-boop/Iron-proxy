import { performance } from 'node:perf_hooks';
import { writeFile, mkdir } from 'node:fs/promises';
import { rewriteHTML, rewriteCSS, rewriteJS } from '../src/core.js';
const ctx = { cap: 'microbenchmark-capability', channel: 'test', proxyOrigin: 'https://iron.example', state: { local: {}, session: {}, cookies: [] } };
const base = 'https://upstream.example/app/index.html';
const cases = [
  ['html', rewriteHTML, '<!doctype html><head><title>Benchmark</title></head><body>' + '<article><a href="../next?q=one">Next</a><img src="/pic.webp"><p>Example content.</p></article>'.repeat(1500) + '</body>'],
  ['css', rewriteCSS, Array.from({ length: 1000 }, (_, i) => `.card${i}{background:url("/asset${i}.png");margin:0;color:#123456}`).join('\n')],
  ['javascript', rewriteJS, Array.from({ length: 1000 }, (_, i) => `function run${i}(input){const u=new URL(input,location.href);return fetch(u.href).then(r=>r.json());}`).join('\n')],
];
const output = [];
for (const [name, fn, source] of cases) {
  for (let i = 0; i < 5; i++) fn(source, base, ctx);
  const samples = []; const cpu = process.cpuUsage();
  for (let i = 0; i < 30; i++) { const start = performance.now(); fn(source, base, ctx); samples.push(performance.now() - start); }
  samples.sort((a, b) => a - b);
  output.push({ name, inputBytes: Buffer.byteLength(source), samples: samples.length, medianMs: samples[14], p95Ms: samples[28], cpuMicros: process.cpuUsage(cpu), rssBytes: process.memoryUsage().rss });
}
await mkdir('artifacts', { recursive: true }); await writeFile('artifacts/rewrite-benchmark.json', JSON.stringify({ date: new Date().toISOString(), node: process.version, results: output }, null, 2)); console.table(output.map(({ cpuMicros, ...r }) => r));
