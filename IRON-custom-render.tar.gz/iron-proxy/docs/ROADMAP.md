# Requested phase accounting

This release is the largest coherent initial version produced in this build, not completion of the full competitive-browser program. “Implemented” means the specific delivered subset is present and runnable; consult the compatibility matrix for limits.

| Phase | Delivered in 0.1 | Remaining before declaring the full phase complete |
| --- | --- | --- |
| 1 — Architecture/minimal proxy | Independent modules, actual proxy route, authenticated shell boundary, URL policy | External architecture/security review |
| 2 — Networking | Real HTTP/HTTPS transport implementation, streaming, pools, redirect rules, cancellation, WebSocket relay; local TCP/WS tests pass | Public TLS/Render validation, upstream retry classification, HTTP/2 characterization, long-lived connection soak tests |
| 3 — Rewriting | Structural HTML/CSS parsing, scope-aware JS edits, runtime injection, URL-based ES modules | Wider syntax/API corpus, complete import maps, dynamic code/DOM/CSSOM, streaming HTML, nested browsing contexts |
| 4 — Browsing/navigation | Iframe document lifecycle, shell navigation, links, forms, Location subset, SPA history subset | Complete history state/popstate/POST restoration and API identity semantics |
| 5 — Custom browser | Integrated tabs/toolbar/home/search/results/settings/diagnostics, desktop/mobile layout; actual content tested | Accessibility audit, Firefox/Safari testing, design refinements based on use |
| 6 — Search | Real Brave API implementation, server-held key, results routed into the browser, honest no-key errors | Keyed API smoke test and additional legitimate provider integrations |
| 7 — State/features | Separate tab jars/storage, private mode, local history/bookmarks, downloads, tab suspension/disposal | Durable encrypted state if wanted; crash recovery; robust multi-window behavior |
| 8 — Performance | Byte-bounded public asset cache, streaming, connection reuse, one lazy parser worker, compact client bundles, suspension, bounded CPU/memory queues | Profile guided optimization, safe request coalescing, incremental HTML, broader benchmarks, actual 4 GB Chromebook validation; WASM only if justified |
| 9 — Competitive testing | Reproducible workload runner, generic deployed-engine adapters, explicit success milestones, process metrics sampler, startup/rewriter tools, raw local evidence | Deploy pinned Ultraviolet/Rammerhead/Scramjet builds, verify each adapter, matched hardware/network/security, larger corpus, confidence intervals and regression analysis |
| 10 — Production | Render blueprint, Node start/build, PORT/0.0.0.0, health, secrets, CSP, SSRF/DNS checks, rate limits and shutdown | Actual deployment, independent security review, malicious-page tests, load/soak tests, public TLS/search checks, production operational procedures |

## Next engineering priority

Validate this exact build on a private Render instance and a modest public website corpus. Record compatibility failures by layer instead of weakening sandboxing to make a single site work. Then verify competitor deployments and baseline the same corpus. Choose the next optimization from measured bottlenecks; do not select Rust/WASM or add workers merely because the architecture can support them.

The initial build's original engineering choices are capability-scoped origin checks, opaque tab isolation, server-side structural rewrites in one bounded worker, and explicit resource budgets. These are architectural decisions, not demonstrated competitive advantages. Any performance or reliability benefit must still be measured against equivalent security and workload conditions.
