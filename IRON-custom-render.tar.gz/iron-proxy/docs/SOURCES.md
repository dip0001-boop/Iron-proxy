# Implementation references

Official/reference documentation consulted on 28 October 2026. No competing proxy implementation was copied or bundled.

- Render Node Web Services: https://render.com/docs/web-services — PORT and 0.0.0.0 deployment contract.
- Render WebSockets: https://render.com/docs/websocket — HTTP upgrade on the web service port and instance shutdown behavior.
- Render Blueprint specification: https://render.com/docs/blueprint-spec — runtime, commands, health endpoint, secrets and autoDeployTrigger.
- Render Node version: https://render.com/docs/node-version — NODE_VERSION and bounded version selection.
- Render Free service limitations: https://render.com/docs/free — evaluation tier, idle spin-down and limitations; not a production availability promise.
- Brave Search API: https://api-dashboard.search.brave.com/app/documentation/web-search — HTTPS endpoint, query arguments and server-side subscription header.
- Undici Agent: https://github.com/nodejs/undici/blob/main/docs/docs/api/Agent.md — bounded per-origin pools and connector options.
- Undici source/types installed in the lockfile — actual supported Agent options for the pinned version.
- MDN iframe reference: https://developer.mozilla.org/en-US/docs/Web/HTML/Reference/Elements/iframe — native sandbox and embedding behavior.
- Parser/library APIs and license metadata were inspected from the exact installed npm versions recorded in package-lock.json.

The source links describe platform/library behavior. They do not establish that IRON passes real-world compatibility, an audit, or competitive benchmarks.
