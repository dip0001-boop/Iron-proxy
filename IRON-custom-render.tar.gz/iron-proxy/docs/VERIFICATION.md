# Verification record — 28 October 2026

This is an engineering-alpha verification record, not a production certification or competitor comparison.

## Completed checks

| Check | Observed result | Evidence |
| --- | --- | --- |
| Unit + integration | 38 passed, 0 failed | artifacts/unit-integration.txt |
| Chromium browser suite | 15 passed, 0 failed; Chromium 153.0.8010.0 | artifacts/browser-results.json |
| Fixture navigation benchmark | 48 measured attempts, all selected content markers passed | artifacts/benchmark.json |
| Production dependency advisory check | 0 reported production-package vulnerabilities | artifacts/dependency-audit.json |
| Production build + prune | Completed; health, HTML, JS/runtime and CSS all served HTTP 200 after dev dependencies removed | artifacts/production-smoke.json |
| Local server startup | Five process launches; median 227.1 ms from spawn to health | artifacts/startup-benchmark.json |
| Public HTTPS smoke | Did not complete: environment DNS returned EAI_AGAIN | artifacts/public-smoke.json |

The browser suite used real TCP/WS test servers, not mocked fetch responses. It verified HTML/CSS, inline/external JS, static/dynamic modules, runtime fetch/XHR, cookie/storage order, WebSocket echo, dynamic images, native parent isolation, denied cross-origin reads, links/history, bookmarks, tab separation, private mode, POST forms, exact downloaded bytes, memory-mode suspension, the no-key search error, diagnostics, cleanup and a 390 px mobile layout. No page script crashes or direct-to-upstream browser resource requests were observed in that suite. Desktop and mobile screenshots were inspected internally; they are not included in the archive.

Browser flags that disable web security/site isolation were rejected. Chromium was supplied separately because the standard Playwright browser download failed in this environment. The browser executable is not bundled or required by the deployed service. Only Node is required to run IRON.

## Local benchmark results

| Concurrent tabs | Measured attempts | Success | Median navigation | p95 navigation | Peak sampled Node RSS |
| --- | --- | --- | --- | --- | --- |
| 1 | 12 | 100% | 87.6 ms | 127.2 ms | 271.1 MiB |
| 3 | 36 | 100% | 150.1 ms | 329.7 ms | 294.9 MiB |

Four deterministic workload categories: static HTML, JavaScript/modules/fetch/XHR, redirects, and WebSocket echo. Three measured repetitions per category/worker, one discarded warmup. Chromium caches and IRON public asset caching were disabled. The fixture, benchmark runner and backend share one Node process, so RSS/CPU include all three. These are local regression samples, not internet page-load timings or standalone backend-memory figures. The machine is shared execution infrastructure, not a 4 GB Chromebook. Small samples do not establish statistically reliable p95 values. Full CPU counters, heap samples and host metadata remain in the raw JSON.

## Rewriter microbenchmark

Thirty warm in-process samples per representative source, after five warmups. These isolated parser timings are not full navigation latency. RSS values in the raw report include sequential parser workloads and GC behavior.

| Input | Input bytes | Median | p95 |
| --- | --- | --- | --- |
| html | 142565 | 18.3 ms | 47.6 ms |
| css | 64779 | 17.7 ms | 43.2 ms |
| javascript | 100889 | 33.2 ms | 62.6 ms |

## Delivered client size

| File | Uncompressed bytes |
| --- | --- |
| dist/app.js | 16643 |
| dist/runtime.js | 10339 |
| dist/style.css | 14366 |
| dist/index.html | 5857 |

## Not verified

- No live Render deployment or public TLS browser session. The production smoke uses local HTTP to simulate the reverse-proxy/backend hop with an HTTPS public-origin configuration; it does not validate TLS termination.
- No keyed Brave Search API request. Only the real adapter implementation and truthful missing-key behavior are delivered.
- No Ultraviolet, Rammerhead or Scramjet run, no confirmed competitor configuration, no superiority claim.
- No broad popular-site corpus, OAuth/SSO/challenge success guarantee, long-running soak test, actual ChromeOS/4 GB device benchmark, Firefox/Safari run, or independent security audit.
- The full requested program remains incomplete. See ROADMAP.md for each phase and COMPATIBILITY.md for supported subsets.
