# Reproducible benchmarking

No comparison with Ultraviolet, Rammerhead or Scramjet has been executed in this build. No superiority claim is supported. The generic adapter does not bundle or modify those engines.

## Run the local proof-of-function workload

```sh
npm ci
npm run build
npx playwright install chromium
npm run bench
npm run bench:rewrite
node bench/startup.mjs
```

These are Node-only tools; Python is not required. For an already installed Chromium, set CHROMIUM_EXECUTABLE_PATH. An optional IRON_BROWSER_LAUNCH_FILE is a local JSON object passed to Playwright launch. Both browser tests and benchmarks refuse common flags that disable web security or site isolation. The build environment used a separately supplied Chromium binary with those insecure defaults removed.

The default benchmark uses real local TCP/WS fixtures and a test-only injected resolver/URL policy. Production has no private-network bypass environment option. The fixture, engine and benchmark run in one Node process, so server process RSS/CPU include fixture/runner overhead. Do not compare those numbers with a separately hosted competitor. The fixture measurement is a regression baseline, not an internet page-load claim or Chromebook measurement.

## What is measured

| Requirement | Measurement |
| --- | --- |
| Website success rate | Explicit workload-ready selector reached before timeout, divided by attempts |
| Median page latency | Median elapsed navigation-to-ready time among successes |
| p95 latency | Nearest-rank p95 among successes, plus p95 across all attempts including timeouts |
| JS compatibility | Success rate on the designated JS/module/fetch/XHR fixture; separate script errors recorded |
| Memory | Sampled backend process RSS and top-level Chromium-target JS heap; excludes complete browser process-tree memory |
| CPU | Backend process user/system microsecond deltas; renderer TaskDuration is a cumulative target counter |
| Startup overhead | Browser context/shell/auth preparation time; separate script measures fresh local server process spawn-to-health |
| Redirect reliability | Success rate on redirect workloads |
| WebSocket compatibility | Successful real echo message marker; text/binary semantics separately covered by integration tests |
| Concurrent browsing | Identical workload repeated at each configured simultaneous-tab count |

The harness waits for the new frame's committed navigation before testing its content marker. Otherwise, a previous document with the same selector could produce a false fast result. Cold login/startup is separate from navigation latency. Warmups are excluded. Failures are retained, not silently removed from success rates. Missing counters are null, never invented zeros.

## Compare engines under controlled conditions

1. Deploy exact tagged/commit-pinned builds of IRON and each competitor on identical hardware, with identical connection/memory limits and the same TLS termination. Pin Node/browser versions and record all engine commits. Review each dependency's license.
2. Deploy `node bench/workload-server.mjs` on one **separate public** origin, or use an explicitly authorized stable external corpus. Ports are exposed through standard HTTPS on the host. The fixture provides `/static`, `/javascript`, `/redirect` and `/websocket`; all finish with `[data-bench-ready="true"]`. It performs no arbitrary proxying. Use the same exact pages for every engine.
3. Copy bench/config.example.json to a private local config. Set workload URLs and the real engine entry endpoints. Add competitor entries with `type: "template"`, a `urlTemplate` containing `{url}`, and an `encoding` of `uri`, `raw`, `base64`, `base64url`, or `xor`. XOR defaults to key 2; verify against the deployed engine rather than assuming. For engines whose entry page embeds content, set `frameSelector`. For required initialization, set `bootstrapURL` and, for service-worker engines, `waitForServiceWorker: true`. Browser service workers are permitted by the harness so competitors that depend on them are not artificially disabled; IRON’s document CSP still blocks upstream workers. Optional cookies can be configured but should never be committed.
4. Example adapter shape for a real deployment: `{ "name": "Engine name + version", "type": "template", "urlTemplate": "https://your-engine-host/its-real-service-path/{url}", "encoding": "uri", "commit": "actual-commit" }`. This is configuration guidance, not a claim that a competitor uses that path or encoding. An engine-specific service-worker initialization/authentication flow may require adaptation before its benchmark is valid. The generic adapter is implemented; competitor-specific configurations are not verified here.
5. Use at least 20 measured repetitions and multiple independent runs. The example adds `pacingMs: 2000` between attempts to respect authenticated API rate limits; apply the same pacing to every engine. Rotate engine order across runs. Include a larger page corpus and explicit correctness assertions. Fix viewport, power/thermal conditions and Chromium CPU/network settings. The included CDP latency/bandwidth shaping affects the browser leg; it does **not** shape server-to-upstream traffic. Control that leg with the same host/network or an OS-level shaper. Record topology and all limits.
6. Disable browser and server caches for every engine in one experiment; perform a separate precisely warmed-cache experiment. IRON's adapter disables its raw asset cache. Competitor caches must be disabled using their real configuration. All proxy pages must pass identical security constraints; speed achieved by dropping isolation, JavaScript, resources or CORS is not a fair improvement.
7. Run `node bench/run.mjs path/to/config.json`. Keep the raw artifacts/benchmark.json, dependency lockfiles, engine commits and machine metadata together. Never commit a benchmark config containing passwords or cookie values.

For external process counters, run `IRON_METRICS_TOKEN=<random secret> node bench/process-metrics.mjs <PID> <PORT>` beside each engine on Linux. It binds loopback and requires a bearer token. Set metricsURL and metricsTokenEnv on template adapter entries. Its JSON matches IRON diagnostics' memory/cpu shape. The sampler measures one process (worker threads included; child processes excluded). If a competitor uses multiple processes, aggregate the same complete process scope for all engines before comparing. Keep the sampler private.

Concurrent process samples overlap and **must not be summed**. RSS samples are not a guaranteed peak measurement; use a periodic external sampler for publication-quality maxima. Top-level Chromium-target heap can include same-process child frames and exclude out-of-process frames. It is a diagnostic, not total browser RAM. Renderer TaskDuration values are cumulative and cannot be presented as per-navigation CPU without subtracting matching-target baselines.

## Gates for any superiority claim

A claim needs a named workload, matched versions/hardware/network/caches/security, raw results, comparable success rates, confidence intervals across repeated runs, and documented regressions. Neither a local fixture's 100% pass rate nor a lower one-run median establishes superiority. Real 4 GB Chromebook usability, Render cold starts, upstream anti-bot behavior and keyed search require separate evidence.
