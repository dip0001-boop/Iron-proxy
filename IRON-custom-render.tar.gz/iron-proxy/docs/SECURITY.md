# Security design and deployment scope

This is a private, single-instance engineering alpha. It is not a security-audited browser, an anonymity service, or an unrestricted public relay. Do not advertise it as a route around organizational controls.

## Implemented controls

- Password-gated control API. No default password. Minimum 16 characters; scrypt verification; constant-time comparisons; bounded login attempts. Generate a random password and store it in Render secret environment configuration.
- HttpOnly, host-only login cookie; SameSite=Strict; Secure when PUBLIC_ORIGIN uses HTTPS. Origin and CSRF checks on control mutations. Cross-site or opaque-origin control requests rejected.
- Unpredictable 256-bit per-document capabilities, bound to a tab and initiating upstream origin. Possession grants limited access for that tab until revocation; treat these URLs as credentials. No capability opens the control API. Limits and expiration apply.
- Upstream cookies in a Tough-cookie jar per tab; origin/domain/path semantics; HttpOnly never injected into document state. Host browser cookies, hop-by-hop headers, and IRON credentials are never forwarded.
- Every navigated proxy response carries `CSP: sandbox allow-scripts allow-forms allow-downloads`. Native same-origin access, top navigation, workers and device permissions are not granted. Native sandboxing is the boundary; JavaScript rewrites only improve compatibility.
- Outbound scheme/port checks, local-name rejection, IP normalization, public-address policy, and DNS checks for **every newly created connection**. All A/AAAA results must be public; one private result rejects the entire lookup. The actual connector consumes those validated records. Keepalive reuses already validated sockets rather than re-resolving into private space.
- All HTTP redirects re-enter target validation and keep the connector lookup. WS redirects are disabled. Upstream Origin is mapped to the real initiating website. Cross-origin credentialed requests are deliberately disabled; readable cross-origin responses must satisfy upstream CORS, including preflight before unsafe methods/content types.
- 12 active upstream HTTP requests globally, four/tab, 128 queued; 30-second overall timeout; per-tab request rate limits. 4 MiB decoded transformed inputs, 16 MiB transformed outputs, 8 MiB uploads, 128 MiB streamed asset ceiling. One lazy worker, 96 MiB old-generation ceiling and five-second task deadline. Rewrite queue has a 16 MiB input-byte ceiling.
- At most 256 cookies and 256 KiB virtual storage/tab. Up to 12 tabs/login, 16 simultaneous logins, fixed eight-hour session lifetime. Tabs revoke caps, abort requests and close sockets on disposal. Ordinary navigation revokes old caps. WebSockets have 1 MiB frames and bounded buffering.
- Private/no-store responses; an internal 16 MiB cache accepts only small explicitly public GET assets without request credentials, Set-Cookie or Vary. It stores raw bytes, not globally reusable session-bearing rewritten URLs.
- Logs contain event codes and statuses, not URLs, tokens, cookies, passwords, queries or headers. Diagnostics require authentication. Production configuration requires HTTPS; HSTS and restrictive shell CSP are supplied.

## Operating constraints

Use one process and one Render instance: cookie jars, sessions and capabilities are memory-only. Restarting or scaling destroys/partitions state. Persistent Redis-backed sessions and safe multi-instance routing are future work. Do not add generic Redis serialization of cookie jars without encryption, TTL and access controls.

The startup password is a single instance credential, suitable for a small trusted group. It is not a multi-user identity provider. Several shell windows using the same cookie are not independent accounts; reloading a shell closes that login's old tabs. Login throttling deliberately does not trust arbitrary forwarded IP headers; on Render, attempts may share the edge proxy's bucket. A future identity/rate-limit deployment should configure a verified trust chain.

A capability can be copied or stolen from its own website and replayed by that website. It is a limited bearer credential, not an HttpOnly secret. It cannot be bound cryptographically to a browser frame in this design. Browser-only forbidden Fetch Metadata headers and opaque sandboxing distinguish navigation from readable fetch; arbitrary external clients holding a capability can impersonate fetch metadata for their own tab. Cross-tab capabilities remain unguessable, but this is not a hardened multi-tenant public service. Do not open sensitive accounts before independent security review.

Browser CSRF protections, cookie SameSite policies, top-level-site accounting, CORP/COEP/COOP, SRI, CSP, Permissions Policy and cross-origin isolation are not fully emulated. IRON replaces upstream CSP/frame restrictions because transformed documents execute on a different native origin. Keep that compatibility/security tradeoff visible; never claim original website security policy parity. Use only on sites and networks you are authorized to access.

## Not done

Independent penetration testing; a broad malicious-page corpus; HTTPS and public-web smoke tests in the deployed environment; account recovery and per-user identities; persistent session encryption; an audit of all uncommon IP address classes; multi-instance scaling; a distributed rate limiter; WS heartbeat/reconnection tests; exhaustive browser API attack testing. Tests provide evidence about named cases, not a universal isolation proof.
