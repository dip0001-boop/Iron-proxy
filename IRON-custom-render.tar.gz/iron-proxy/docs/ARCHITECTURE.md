# IRON 0.1 architecture — engineering alpha

IRON is an independent implementation. It does not embed, fork, rebrand, or depend on Ultraviolet, Rammerhead, or Scramjet. Native Chromium/Firefox/WebKit still render the documents. This is a browser application, not a new native rendering engine.

## Boundaries

```mermaid
flowchart TD
    Shell["IRON BROWSER"] --> API["Authenticated control API"]
    API --> State["Tabs and isolated sessions"]
    Shell --> Frame["Opaque document sandbox"]
    Frame <--> Core["IRON CORE runtime and routes"]
    Core --> Worker["Bounded parser worker"]
    Core --> Queue["Request admission queue"]
    Queue --> Network["IRON NETWORK: DNS and transport"]
    Network <--> Web["Upstream website"]
```

Each shell login has independent tabs. Each tab owns a CookieJar, per-upstream-origin local/session storage, sockets, abort controllers, and navigation capabilities. Private tabs are omitted from shell history and bookmark actions. All upstream state is memory-only and disappears on expiration, close, logout, or restart. Regular bookmarks/history are local to this browser profile.

A capability contains 256 random bits, is bound to one tab and initiating upstream origin, expires with the tab, and is never the shell login credential. Subresource URLs carry it. The server authorizes readable cross-origin fetch responses against the real upstream CORS policy; cross-origin requests never receive upstream cookies in this alpha. Navigation to a different origin gets a fresh capability. Response headers enforce an opaque sandbox even when somebody opens the content URL outside the shell. Neither `allow-same-origin` nor top-level navigation permission is granted. The shell validates message source and tab channel. It does not expose its control API to the opaque content origin.

## Pipeline

1. Reject unauthenticated control requests. Validate capability, method, target scheme/port and size.
2. Admit bounded global/per-tab concurrency; cancel queued or active work on tab close.
3. Resolve all DNS answers at socket creation. Reject the complete result if any address is non-public. Return the vetted addresses to the connector itself, avoiding a validate-then-resolve gap. TLS retains hostname verification.
4. Construct an allowlisted upstream request. Browser shell cookies and proxy credentials are never forwarded. Apply upstream cookie rules, CORS preflight where needed, and manual redirect validation at each hop.
5. Stream binary resources with backpressure. Decompress transformable text, enforce a decoded-size ceiling, then parse in one lazily started worker. Text is bounded-buffered, not advertised as incrementally parsed.
6. Parse HTML with parse5, CSS with css-tree, JavaScript with Acorn and eslint-scope. Edit JS source with MagicString. The parser lives on the server, keeping the browser runtime small.
7. Inject the runtime before upstream scripts. Apply a restrictive proxy CSP and strip upstream security headers only where proxy transformation requires replacement. No direct network destination is permitted for ordinary subresources.
8. Retain only explicitly public, uncredentialed, small GET assets in the byte-bounded raw response cache. Never cache private HTML or transformed capability URLs globally.

## Deliberate constraints

- One Node process, one rewrite worker by default, bounded queues. No WASM until a measured parser bottleneck justifies it.
- Explicitly unsupported surfaces fail or remain blocked: service workers, dedicated/shared workers, eval/new Function, native IndexedDB, DRM, WebRTC, direct external popups and device permissions.
- Cookies and storage have synchronous local views and ordered asynchronous server persistence. They are a compatibility layer, not a complete browser implementation.
- Generic hostile JavaScript cannot be perfectly virtualized with source rewriting. Sandboxing is the security boundary; runtime hooks are compatibility tools. See COMPATIBILITY.md for concrete gaps.
- The 0.1 benchmark harness measures observable milestones and process diagnostics. Competitor superiority is unproven and no competitor result is fabricated.

The ten requested phases are represented in source and documented in ROADMAP.md. Phases 9 and 10 remain incomplete until external comparative runs, an independent security review, and an actual Render deployment are performed.
