# Compatibility matrix — 0.1.0

“Verified” below means deterministic fixtures passed in the delivered Node and Chromium tests. It does **not** mean arbitrary websites or other host browsers have passed. Chromium, Firefox, Safari, and ChromeOS are not interchangeable; only the recorded Chromium build was exercised here. Inspect artifacts/browser-results.json and VERIFICATION.md.

| Surface | Implementation and verification | Limits |
| --- | --- | --- |
| HTTP transport | Real TCP requests via Undici; GET/HEAD and POST/PUT/PATCH/DELETE transport; POST body fixture verified | Public upstream ports 80/443 only; 8 MiB request bodies; direct public DNS unavailable in build environment |
| HTTPS | Native TLS and hostname verification retained; safe DNS lookup installed on connector | Public TLS end-to-end smoke attempt failed at environment DNS resolution; must validate on Render |
| Redirects | Relative/absolute targets resolved and validated at every hop; method rules, cookie storage and loops tested | Ten-hop ceiling; navigation retries require user action; native response redirect mode is not fully emulated |
| HTML | parse5 structural rewrites, base URL handling, inline handlers, forms, style/script transformation; runtime injected first | 4 MiB decoded limit; buffered, not streaming HTML; XHTML/XML and meta-refresh unsupported |
| CSS | css-tree URLs and quoted imports; custom property parsing enabled; stylesheet fixture rendered | Dynamic CSSOM strings, image-set string URLs, uncommon extensions and parser Raw nodes may remain unrewritten and be blocked by CSP |
| JavaScript | Acorn + eslint-scope + MagicString; scoped global Location reads/writes, member access; shadowed bindings tested | Not complete JavaScript virtualization; computed aliases, unusual globalThis shadowing and unsupported parser syntax can break |
| ES modules | External modules, relative static imports, re-exports, dynamic URL imports, import.meta.url | Fixtures verify static/dynamic modules; bare names preserved for exact import-map keys; import-map prefix/scope semantics incomplete |
| Fetch | Relative URL resolution, Request input, body forwarding, AbortSignal, same-origin cookies, CORS checks | Streaming upload converted to a bounded body; Request/Response identity, redirect/manual/opaque modes not fully emulated; cross-origin credentials always omitted |
| XHR | Async native XHR wrapper; URLs rewritten; real fixture succeeds | Synchronous XHR explicitly throws; responseURL after redirects is approximate; abort-before-queued-send edge cases remain |
| WebSocket | ws bridge with DNS policy, upstream Origin, protocol negotiation, text/binary relay, payload limits and pause/resume | Fixture text/binary echoed; reconnect is the website’s responsibility; redirects rejected; eight endpoints per tab |
| DOM links | Rewritten markup, click broker, URL property setters, setAttribute, innerHTML, insertAdjacentHTML, append/insert/replace | No universal DOM interception; document.write, adopted nodes, outerHTML, CSSOM, dynamic inline code can escape rewriting and be blocked or behave incorrectly |
| Location / URL | AST-backed Location view, native URL parsing, document URL/base URI views | Native window.location descriptors cannot be replaced; reflection and hidden aliases may expose proxy URL; fragments and SPA history are a subset |
| Forms | Native GET/POST submissions use rewritten proxy actions; POST response verified inside frame | Multipart body bounded at 8 MiB; parent history reloads with GET and does not replay POST; complex target/nested forms partial |
| Cookies | Tough-cookie jar per tab; HttpOnly excluded from document view; secure/domain/path checks; ordered persistence; tests | Max 256 cookies/tab, 4 KiB/cookie; sync local view can temporarily diverge from server rejection; no complete SameSite/CHIPS/browser policy emulation |
| Storage | Per-tab and per-upstream-origin localStorage/sessionStorage views, quota and server persistence | 256 KiB total/tab, memory only; no StorageEvent coordination or native Storage identity; native IndexedDB/CacheStorage unavailable |
| History API | Virtual pushState/replaceState and shell back/forward | Full page reload on shell traversal; history state/popstate/bfcache semantics incomplete |
| Tabs | Multiple live frames, active switching, private tabs, configurable suspension, close/reset disposal | Up to 12 tabs/login; suspended pages lose DOM/JS/form state; shell reload starts fresh tabs |
| Bookmarks/history | Device-local records from navigated tabs; bookmark add/remove and history clear verified | Regular history up to 300 URLs; no account sync; private mode is not network anonymity |
| Downloads | Streaming headers preserved; sandbox permits user-initiated downloads; exact fixture bytes verified | Host browser determines permission, filename handling and save location; completion is not observable from the shell |
| Popups | window.open requests become IRON tabs and respect current private mode | Returns null; window.opener workflows, popup OAuth and arbitrary native windows unsupported |
| Search | Server-only Brave Search API adapter; no-key behavior tested | Real paid/keyed API round-trip not run without credentials; one provider implemented; no fake results or scraping fallback |
| Workers | Dedicated/shared worker constructors throw clear unsupported errors; CSP blocks workers | Service workers, offscreen worker rendering and background sync unsupported |
| Frames | Every response has a CSP sandbox and frame-ancestor restriction | Nested upstream frames are effectively blocked by opaque ancestors; no complete nested browsing-context support |
| Permissions/media | Images and binary resources stream; inline SVG resource fixture verified | Camera/mic/geolocation/payment/USB/serial blocked; DRM, EME, WebRTC, WebAuthn, passkeys, browser extensions unsupported; video streaming not specifically verified |
| Authentication | IRON instance password, HttpOnly shell login, strict Origin/CSRF controls | Upstream OAuth, SSO, CAPTCHA, anti-bot checks, origin-bound credentials, DRM and challenge pages can fail; no universal bypass claimed |
| Security | SSRF policy, connector DNS validation, opaque sandbox, capability scope, CORS and ownership checks | No independent security audit; runtime source rewriting is not a complete hostile-code membrane; address text and page titles are untrusted website UI data |

## Browser-native boundaries

IRON deliberately uses sandboxed frames because the host browser is the rendering and isolation authority. Omitting `allow-same-origin` prevents unrelated proxied sites from sharing a real origin or reading the shell’s native cookies/storage. Emulating a subset of APIs on top of opaque origins trades compatibility for a defensible boundary. Relaxing the sandbox to make login challenges work would undermine that boundary and is not a supported setting.

The browser may reserve Ctrl/Cmd+L/T/W/R before an embedded app sees them, and embedded page focus can consume keys. IRON uses Alt shortcuts while the shell has focus; use visible buttons while content has focus. Mobile users get the same underlying engine with a responsive shell, not an independent mobile browser executable.
