import { Worker } from 'node:worker_threads';
export class Rewriter {
  constructor() { this.worker = null; this.queue = []; this.current = null; this.serial = 0; this.count = 0; this.totalMs = 0; this.closed = false; this.queuedBytes = 0; }
  run(kind, source, base, context) {
    const bytes = Buffer.byteLength(source);
    if (this.closed || this.queue.length >= 32 || this.queuedBytes + bytes > 16 * 1024 * 1024) return Promise.reject(Object.assign(new Error('Rewrite queue unavailable.'), { status: 503 }));
    this.queuedBytes += bytes;
    return new Promise((resolve, reject) => { this.queue.push({ id: ++this.serial, kind, source, base, context, resolve, reject, bytes }); this.pump(); });
  }
  pump() {
    if (this.current || !this.queue.length || this.closed) return;
    if (!this.worker) {
      const worker = this.worker = new Worker(new URL('./rewrite-worker.js', import.meta.url), { resourceLimits: { maxOldGenerationSizeMb: 96 } });
      worker.on('message', msg => {
        if (this.worker !== worker || msg.id !== this.current?.id) return;
        const task = this.current; clearTimeout(task.timer); this.current = null;
        this.count++; this.totalMs += performance.now() - task.started;
        if (msg.error) task.reject(Object.assign(new Error(msg.error), { status: 422, code: 'REWRITE_FAILED' })); else task.resolve(msg.result);
        this.pump();
      });
      worker.on('error', e => this.broken(worker, e));
      worker.on('exit', code => { if (this.worker === worker && code !== 0) this.broken(worker, new Error('Rewrite worker exited.')); });
    }
    const task = this.current = this.queue.shift(); this.queuedBytes -= task.bytes; task.started = performance.now();
    task.timer = setTimeout(() => this.broken(this.worker, Object.assign(new Error('Rewrite time limit exceeded.'), { status: 504 })), 5000);
    const { id, kind, source, base, context } = task; this.worker.postMessage({ id, kind, source, base, context });
  }
  broken(worker, error) {
    if (this.worker !== worker) return;
    this.worker = null; worker?.terminate();
    if (this.current) { clearTimeout(this.current.timer); this.current.reject(error); this.current = null; }
    this.pump();
  }
  async close() {
    this.closed = true; for (const task of this.queue) task.reject(new Error('Server stopping.')); this.queue = [];
    const worker = this.worker; this.worker = null;
    if (this.current) { clearTimeout(this.current.timer); this.current.reject(new Error('Server stopping.')); this.current = null; }
    await worker?.terminate();
  }
}
