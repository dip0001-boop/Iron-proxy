import * as html from 'parse5';
import * as css from 'css-tree';
import { parse } from 'acorn';
import * as walk from 'acorn-walk';
import { analyze } from 'eslint-scope';
import MagicString from 'magic-string';

import { proxyURL } from './url.js';
export { encodeURL, decodeURL, proxyURL } from './url.js';

export function rewriteCSS(source, base, context, inline = false) {
  const ast = css.parse(source, { context: inline ? 'declarationList' : 'stylesheet', positions: false, parseCustomProperty: true });
  css.walk(ast, node => {
    if (node.type === 'Url') node.value = proxyURL(node.value, base, context);
    if (node.type === 'Atrule' && node.name.toLowerCase() === 'import' && node.prelude) {
      const first = node.prelude.children?.first;
      if (first?.type === 'String') first.value = proxyURL(first.value, base, context);
    }
  });
  return css.generate(ast);
}

export function rewriteJS(source, base, context, inlineHandler = false) {
  if (!source.trim()) return source;
  const options = { ecmaVersion: 'latest', ranges: true, allowHashBang: true, allowReturnOutsideFunction: inlineHandler };
  let tree;
  try { tree = parse(source, { ...options, sourceType: 'module' }); }
  catch { tree = parse(source, { ...options, sourceType: 'script' }); }
  const scope = analyze(tree, { ecmaVersion: 2024, sourceType: tree.sourceType, optimistic: true, ignoreEval: true });
  const globals = new Set(scope.globalScope.through.map(r => r.identifier));
  const edits = []; const insertions = [];
  const add = (node, replacement) => edits.push({ start: node.start, end: node.end, replacement });
  walk.ancestor(tree, {
    Identifier(node, ancestors) {
      if (node.name !== 'location' || !globals.has(node)) return;
      const parent = ancestors.at(-2);
      if (parent?.type === 'Property' && parent.shorthand) add(node, 'location: globalThis.__iron.location');
      else add(node, 'globalThis.__iron.location');
    },
    MemberExpression(node) {
      const object = node.object;
      const property = node.computed ? node.property.value : node.property.name;
      if (property === 'location' && object.type === 'Identifier' && globals.has(object) && ['window', 'self', 'globalThis', 'document'].includes(object.name)) add(node, 'globalThis.__iron.location');
      if (object.type === 'MetaProperty' && object.meta.name === 'import' && property === 'url') add(node, JSON.stringify(base));
    },
    ImportDeclaration(node) { add(node.source, JSON.stringify(moduleURL(node.source.value, base, context))); },
    ExportNamedDeclaration(node) { if (node.source) add(node.source, JSON.stringify(moduleURL(node.source.value, base, context))); },
    ExportAllDeclaration(node) { add(node.source, JSON.stringify(moduleURL(node.source.value, base, context))); },
    ImportExpression(node) {
      insertions.push([node.source.start, 'globalThis.__iron.moduleURL('], [node.source.end, `,${JSON.stringify(base)})`]);
    },
  });
  const text = new MagicString(source); let end = -1;
  for (const e of edits.sort((a, b) => a.start - b.start || b.end - a.end)) { if (e.start < end) continue; text.overwrite(e.start, e.end, e.replacement); end = e.end; }
  for (const [position, value] of insertions) text.appendLeft(position, value);
  return text.toString();
}
function moduleURL(value, base, context) { return /^[./]|^[a-zA-Z][\w+.-]*:/.test(value) ? proxyURL(value, base, context) : value; }

const URL_ATTRS = new Set(['src', 'href', 'action', 'formaction', 'poster', 'data', 'background', 'cite', 'xlink:href']);
const JAVASCRIPT_TYPES = new Set(['', 'module', 'text/javascript', 'application/javascript', 'application/ecmascript', 'text/ecmascript']);
function attr(node, name) { return node.attrs?.find(a => a.name === name)?.value; }
function setAttr(node, name, value) { const a = node.attrs.find(a => a.name === name); if (a) a.value = value; else node.attrs.push({ name, value }); }
function visit(node, fn) { fn(node); for (const child of [...node.childNodes || []]) visit(child, fn); if (node.content) visit(node.content, fn); }
function remove(node) { if (node.parentNode) node.parentNode.childNodes = node.parentNode.childNodes.filter(c => c !== node); }
function safeJSON(value) { return JSON.stringify(value).replace(/</g, '\\u003c').replace(/\u2028/g, '\\u2028').replace(/\u2029/g, '\\u2029'); }

// srcset scanning follows the URL-token and descriptor boundaries; commas inside data URLs stay in the URL token.
export function rewriteSrcset(input, base, context) {
  let i = 0; const out = [];
  while (i < input.length) {
    while (/[\s,]/.test(input[i] || '') && i < input.length) i++;
    const start = i;
    while (i < input.length && !/\s/.test(input[i])) i++;
    let url = input.slice(start, i); if (!url) break;
    if (url.endsWith(',')) { url = url.replace(/,+$/, ''); out.push(proxyURL(url, base, context)); continue; }
    const descriptorStart = i; let parens = 0;
    while (i < input.length) { if (input[i] === '(') parens++; if (input[i] === ')') parens--; if (input[i] === ',' && !parens) break; i++; }
    out.push(proxyURL(url, base, context) + input.slice(descriptorStart, i)); i++;
  }
  return out.join(', ');
}

export function rewriteHTML(source, base, context) {
  const doc = html.parse(source);
  let effectiveBase = base; let foundBase = false;
  visit(doc, node => { if (!foundBase && node.tagName === 'base' && attr(node, 'href')) { try { effectiveBase = new URL(attr(node, 'href'), base).href; } catch {} foundBase = true; } });
  visit(doc, node => {
    if (!node.tagName) return;
    if (['base', 'object', 'embed'].includes(node.tagName)) { remove(node); return; }
    if (node.tagName === 'meta' && ['content-security-policy', 'refresh', 'set-cookie'].includes((attr(node, 'http-equiv') || '').toLowerCase())) { remove(node); return; }
    if (node.tagName === 'link' && /\b(prefetch|preconnect|dns-prefetch|prerender|manifest)\b/.test(attr(node, 'rel') || '')) { remove(node); return; }
    node.attrs = node.attrs.filter(a => !['integrity', 'nonce', 'ping', 'srcdoc', 'credentialless'].includes(a.name));
    for (const a of node.attrs) {
      if (URL_ATTRS.has(a.name)) a.value = proxyURL(a.value, effectiveBase, context);
      else if (a.name === 'srcset' || a.name === 'imagesrcset') a.value = rewriteSrcset(a.value, effectiveBase, context);
      else if (a.name === 'style') a.value = rewriteCSS(a.value, effectiveBase, context, true);
      else if (a.name.startsWith('on')) a.value = rewriteJS(a.value, effectiveBase, context, true);
      else if (a.name === 'target' || a.name === 'formtarget') a.value = '_self';
    }
    if (node.tagName === 'iframe') setAttr(node, 'sandbox', 'allow-scripts allow-forms');
    if (node.tagName === 'style') for (const c of node.childNodes || []) if (c.nodeName === '#text') c.value = rewriteCSS(c.value, effectiveBase, context);
    if (node.tagName === 'script') {
      const type = (attr(node, 'type') || '').toLowerCase();
      if (type === 'importmap') {
        for (const c of node.childNodes || []) if (c.nodeName === '#text') {
          const map = JSON.parse(c.value);
          const transform = values => Object.fromEntries(Object.entries(values || {}).map(([k, v]) => [k, typeof v === 'string' ? proxyURL(v, effectiveBase, context) : v]));
          map.imports = transform(map.imports);
          if (map.scopes) map.scopes = Object.fromEntries(Object.entries(map.scopes).map(([k, v]) => [proxyURL(k, effectiveBase, context), transform(v)]));
          c.value = safeJSON(map);
        }
      } else if (JAVASCRIPT_TYPES.has(type) && !attr(node, 'src')) {
        for (const c of node.childNodes || []) if (c.nodeName === '#text') c.value = rewriteJS(c.value, effectiveBase, context).replace(/<\/script/gi, '<\\/script');
      }
    }
  });
  let head;
  visit(doc, node => { if (node.tagName === 'head' && !head) head = node; });
  const config = { ...context, url: base, base: effectiveBase };
  const fragment = html.parseFragment(`<script id="iron-config" type="application/json">${safeJSON(config)}</script><script src="${context.proxyOrigin}/runtime.js"></script>`);
  for (const node of fragment.childNodes) node.parentNode = head;
  head.childNodes.unshift(...fragment.childNodes);
  return html.serialize(doc);
}
