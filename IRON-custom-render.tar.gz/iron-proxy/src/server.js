import express from 'express';
import http from 'node:http';
import { readFile } from 'node:fs/promises';
import { fileURLToPath, pathToFileURL } from 'node:url';
import path from 'node:path';
import { pipeline } from 'node:stream/promises';
import { WebSocket, WebSocketServer } from 'ws';
import { randomBytes, timingSafeEqual } from 'node:crypto';
import { gzip } from 'node:zlib';
import { promisify } from 'node:util';
import { readConfig } from './config.js';
import { State } from './state.js';
import { Network, collect, decodedStream, byteLimit } from './network.js';
import { Rewriter } from './rewriter.js';
import { decodeURL, proxyURL } from './url.js';
import { IronError, fail, hashPassword, equal, RateLimiter, shellHeaders, contentCSP, validateTarget } from './security.js';

const ROOT = fileURLToPath(new URL('../', import.meta.url));
const compress = promisify(gzip);
const escape = value => String(value).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const requestHeaderAllow = 'content-type, authorization, range, if-range, x-iron-credentials';
const methods = new Set(['GET', 'HEAD', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS']);
const mimeKind = type => type.includes('text/html') ? 'html' : type.includes('text/css') ? 'css' : /(?:java|ecma)script/.test(type) ? 'js' : null;
function cookieId(req) { return String(req.headers.cookie || '').split(';').map(v => v.trim()).find(v => v.startsWith('iron_auth='))?.slice(10); }
function readableHeaders(headers) {
  const names = ['content-type', 'content-disposition', 'accept-ranges', 'content-range', 'last-modified', 'etag'];
  return Object.fromEntries(names.filter(k => headers[k] !== undefined).map(k => [k, headers[k]]));
}
function cookieHeader(user, secure) { return `iron_auth=${user?.id || ''}; Path=/; HttpOnly; SameSite=Strict; Max-Age=${user ? 8 * 60 * 60 : 0}${secure ? '; Secure' : ''}`; }

export async function createApplication(config, injected = {}) {
  const app = express(); app.disable('x-powered-by');
  const server = http.createServer({ maxHeaderSize: 16 * 1024 }, app);
  server.requestTimeout = 30_000; server.headersTimeout = 15_000; server.keepAliveTimeout = 5000;
  const state = new State(config); const network = injected.network || new Network(config); const rewriter = new Rewriter();
  const passwordSalt = randomBytes(32); const passwordHash = await hashPassword(config.password, passwordSalt);
  const loginLimit = new RateLimiter(8, 60_000); const globalLoginLimit = new RateLimiter(32, 60_000);
  const apiLimit = new RateLimiter(120, 60_000); const proxyLimit = new RateLimiter(1200, 60_000);
  const wsLimit = new RateLimiter(30, 60_000);
  let stopping = false;
  const baseHeaders = shellHeaders(config.origin);
  app.use((req, res, next) => { res.set(baseHeaders); if (stopping) return res.status(503).json({ error: 'SHUTTING_DOWN' }); next(); });
  app.get('/health', (_req, res) => res.json({ ok: !stopping, version: '0.1.0' }));
  function sameOrigin(req) {
    if (req.headers.origin && req.headers.origin !== config.origin) fail(403, 'ORIGIN_BLOCKED', 'Control requests must originate in IRON BROWSER.');
    if (req.headers['sec-fetch-site'] === 'cross-site') fail(403, 'ORIGIN_BLOCKED', 'Cross-site control request blocked.');
  }
  function authenticated(req) {
    sameOrigin(req);
    const user = state.logins.get(cookieId(req));
    if (!user || user.expires < Date.now()) fail(401, 'AUTH_REQUIRED', 'Sign in to IRON BROWSER.');
    if (!['GET', 'HEAD'].includes(req.method) && (!equal(req.headers['x-iron-csrf'], user.csrf) || req.headers.origin !== config.origin)) fail(403, 'CSRF_BLOCKED', 'Invalid control request.');
    apiLimit.take(user.id); return user;
  }
  const auth = (req, _res, next) => { try { req.ironUser = authenticated(req); next(); } catch (e) { next(e); } };
  app.use('/api', express.json({ limit: '24kb', type: 'application/json' }), (_req, res, next) => { res.set('Cache-Control', 'no-store'); next(); });
  app.post('/api/login', async (req, res) => {
    sameOrigin(req);
    if (req.headers.origin !== config.origin) fail(403, 'ORIGIN_REQUIRED', 'Login requires the configured public origin.');
    // Do not trust arbitrary X-Forwarded-For values on public deployments.
    globalLoginLimit.take('all'); loginLimit.take(req.socket.remoteAddress || 'unknown');
    if (typeof req.body?.password !== 'string' || req.body.password.length > 256) fail(400, 'PASSWORD_INVALID', 'Invalid password.');
    const candidate = await hashPassword(req.body.password, passwordSalt);
    if (!timingSafeEqual(candidate, passwordHash)) fail(401, 'LOGIN_FAILED', 'Incorrect password.');
    const old = state.logins.get(cookieId(req)); if (old) state.logout(old);
    const user = state.login(); res.set('Set-Cookie', cookieHeader(user, config.origin.startsWith('https:')));
    res.json({ csrf: user.csrf, searchProviders: config.braveKey ? ['brave'] : [], maxTabs: config.maxTabs });
  });
  app.get('/api/me', auth, (req, res) => res.json({ csrf: req.ironUser.csrf, searchProviders: config.braveKey ? ['brave'] : [], maxTabs: config.maxTabs }));
  app.get('/api/tabs', auth, (req, res) => res.json({ tabs: [...req.ironUser.tabs].map(id => ({ id })) }));
  app.post('/api/logout', auth, (req, res) => { state.logout(req.ironUser); res.set('Set-Cookie', cookieHeader(null, config.origin.startsWith('https:'))); res.json({ ok: true }); });
  app.post('/api/tabs', auth, (req, res) => {
    const tab = state.createTab(req.ironUser, req.body?.private === true);
    res.status(201).json({ id: tab.id, channel: tab.channel, private: tab.private });
  });
  app.post('/api/tabs/:id/navigate', auth, (req, res) => {
    const tab = state.getTab(req.ironUser, req.params.id);
    const url = network.validate(req.body?.url).href;
    const sequence = req.body?.sequence ?? (tab.navigationSequence || 0) + 1;
    if (!Number.isSafeInteger(sequence) || sequence <= (tab.navigationSequence || 0)) fail(409, 'STALE_NAVIGATION', 'A newer navigation already started.');
    tab.navigationSequence = sequence;
    state.resetNavigation(tab); tab.url = url; const cap = state.cap(tab, url);
    res.json({ url, src: proxyURL(url, url, { cap: cap.id, proxyOrigin: config.origin }) });
  });
  app.delete('/api/tabs/:id', auth, (req, res) => { state.closeTab(state.getTab(req.ironUser, req.params.id)); res.json({ ok: true }); });
  app.post('/api/tabs/:id/suspend', auth, (req, res) => { state.resetNavigation(state.getTab(req.ironUser, req.params.id)); res.json({ ok: true }); });
  app.post('/api/tabs/:id/settings', auth, (req, res) => { const tab = state.getTab(req.ironUser, req.params.id); tab.cacheEnabled = req.body?.cacheEnabled !== false; res.json({ ok: true }); });
  app.post('/api/tabs/:id/clear', auth, (req, res) => {
    const tab = state.getTab(req.ironUser, req.params.id); state.resetNavigation(tab); tab.jar.removeAllCookiesSync(); tab.storage.clear(); res.json({ ok: true });
  });
  app.post('/api/cache/clear', auth, (_req, res) => { network.cache.clear(); res.json({ ok: true }); });
  app.get('/api/diagnostics', auth, (req, res) => {
    const memory = process.memoryUsage();
    res.json({ version: '0.1.0', uptimeSeconds: process.uptime(), memory, cpu: process.cpuUsage(), tabs: req.ironUser.tabs.size, activeRequests: network.scheduler.active, queuedRequests: network.scheduler.queue.length, cache: { bytes: network.cache.bytes, entries: network.cache.items.size, hits: network.cache.hits, misses: network.cache.misses }, rewrite: { count: rewriter.count, totalMs: rewriter.totalMs, queued: rewriter.queue.length }, network: network.metrics });
  });
  const searchLimit = new RateLimiter(20, 60_000);
  app.get('/api/search', auth, async (req, res) => {
    searchLimit.take(req.ironUser.id);
    if (!config.braveKey) fail(503, 'SEARCH_NOT_CONFIGURED', 'Set BRAVE_SEARCH_API_KEY on the server to enable real web search. URLs already work.');
    if (req.query.provider && req.query.provider !== 'brave') fail(400, 'SEARCH_PROVIDER', 'Only the configured Brave Search API is available in this build.');
    const query = String(req.query.q || '').trim();
    if (!query || query.length > 600 || query.split(/\s+/).length > 75) fail(400, 'SEARCH_QUERY', 'Search requires 1–600 characters and at most 75 words.');
    const response = await network.open(`https://api.search.brave.com/res/v1/web/search?q=${encodeURIComponent(query)}&count=10&safesearch=moderate`, { method: 'GET', headers: { accept: 'application/json', 'x-subscription-token': config.braveKey, 'accept-encoding': 'identity' }, signal: AbortSignal.timeout(15_000) });
    const buffer = await collect(decodedStream(response.body, response.headers), 2 * 1024 * 1024);
    if (response.statusCode !== 200) fail(502, 'SEARCH_UPSTREAM', 'The search provider could not complete this request. Check the API key, quota, and provider status.');
    const data = JSON.parse(buffer.toString());
    const results = (data.web?.results || []).filter(r => /^https?:\/\//.test(r.url)).slice(0, 10).map(r => ({ title: String(r.title || r.url), url: r.url, description: String(r.description || '').replace(/<[^>]*>/g, '') }));
    res.json({ provider: 'Brave Search', query, results });
  });

  function proxyHeaders(res) {
    res.set({ 'Content-Security-Policy': contentCSP(config.origin), 'Cache-Control': 'no-store', 'Access-Control-Allow-Origin': 'null', 'Access-Control-Expose-Headers': 'content-type, content-disposition, content-range, x-iron-upstream-url', 'Referrer-Policy': 'no-referrer' });
  }
  app.use('/v', express.json({ limit: '270kb' }), async (req, res) => {
    proxyHeaders(res);
    const cap = state.getCap(req.path.split('/')[1]); proxyLimit.take(cap.tab.id);
    if (req.headers.origin && req.headers.origin !== 'null') fail(403, 'CONTENT_ORIGIN', 'Expected an isolated document.');
    if (req.method === 'OPTIONS') return res.set({ 'Access-Control-Allow-Methods': 'POST, OPTIONS', 'Access-Control-Allow-Headers': 'content-type' }).sendStatus(204);
    if (req.method !== 'POST') fail(405, 'METHOD_BLOCKED', 'Use POST.');
    const data = req.body;
    if (data?.type === 'cookie') {
      if (typeof data.value !== 'string' || data.value.length > 4096) fail(400, 'COOKIE_INVALID', 'Invalid cookie.');
      const url = new URL(data.url || cap.url);
      if (url.origin !== cap.origin) fail(403, 'ORIGIN_BLOCKED', 'Cookie origin mismatch.');
      try {
        const candidate = cap.tab.jar.cloneSync(); candidate.setCookieSync(data.value, url.href, { http: false, ignoreError: false });
        if (candidate.serializeSync().cookies.length > 256) fail(413, 'COOKIE_QUOTA', 'This tab exceeded its cookie quota.');
        cap.tab.jar = candidate;
      } catch (error) { if (error instanceof IronError) throw error; fail(400, 'COOKIE_INVALID', 'Cookie was rejected.'); }
      return res.json({ cookies: state.snapshot(cap, url.href).cookies });
    }
    if (data?.type === 'storage') {
      if (!['local', 'session'].includes(data.area) || !data.values || typeof data.values !== 'object' || Array.isArray(data.values) || Object.values(data.values).some(v => typeof v !== 'string')) fail(400, 'STORAGE_INVALID', 'Invalid storage update.');
      const current = cap.tab.storage.get(cap.origin) || { local: {}, session: {} };
      const next = { ...current, [data.area]: data.values };
      let bytes = Buffer.byteLength(JSON.stringify(next));
      for (const [origin, store] of cap.tab.storage) if (origin !== cap.origin) bytes += Buffer.byteLength(JSON.stringify(store));
      if (bytes > config.maxStorageBytes) fail(413, 'STORAGE_QUOTA', 'This tab exceeded its storage quota.');
      cap.tab.storage.set(cap.origin, next); return res.json({ ok: true });
    }
    fail(400, 'STATE_OPERATION', 'Unknown state operation.');
  });

  app.use('/p', async (req, res) => {
    proxyHeaders(res);
    const [capId, encoded, ...extra] = req.path.slice(1).split('/');
    if (!encoded || extra.length) fail(400, 'ROUTE_INVALID', 'Invalid IRON resource URL.');
    let cap = state.getCap(capId); proxyLimit.take(cap.tab.id);
    if (!methods.has(req.method)) fail(405, 'METHOD_BLOCKED', 'Unsupported HTTP method.');
    if (req.method === 'OPTIONS') return res.set({ 'Access-Control-Allow-Methods': [...methods].join(', '), 'Access-Control-Allow-Headers': requestHeaderAllow, 'Access-Control-Max-Age': '60' }).sendStatus(204);
    let target;
    try { target = network.validate(decodeURL(encoded)); } catch (e) { if (e instanceof IronError) throw e; fail(400, 'URL_INVALID', 'Invalid encoded target.'); }
    const query = new URL(req.originalUrl, config.origin).search;
    if (query) target.search = query;
    const destination = String(req.headers['sec-fetch-dest'] || '');
    const navigation = ['iframe', 'document'].includes(destination);
    const controller = new AbortController(); cap.tab.controllers.add(controller);
    const timeout = setTimeout(() => controller.abort(), 30_000);
    const onClose = () => { if (!res.writableFinished) controller.abort(); };
    res.on('close', onClose);
    let release;
    try {
      release = await network.scheduler.acquire(cap.tab.id, controller.signal);
      const body = ['GET', 'HEAD'].includes(req.method) ? undefined : await collect(req, config.maxBodyBytes);
      const response = await network.fetch(cap, target.href, { method: req.method, headers: req.headers, body, signal: controller.signal, destination, mode: req.headers['sec-fetch-mode'], credentials: req.headers['x-iron-credentials'] === 'omit' ? 'omit' : 'same-origin' });
      let kind = mimeKind(String(response.headers['content-type'] || '').toLowerCase());
      if (kind === 'html' && !navigation) kind = null;
      if (navigation && new URL(response.url).origin !== cap.origin) cap = state.cap(cap.tab, response.url);
      if (navigation) { cap.url = response.url; cap.tab.url = response.url; }
      res.status(response.statusCode).set(readableHeaders(response.headers)).set('X-Iron-Upstream-URL', response.url);
      if (req.method === 'HEAD' || [204, 205, 304].includes(response.statusCode)) { response.body.destroy(); return res.end(); }
      if (kind) {
        const bytes = await collect(decodedStream(response.body, response.headers), config.maxTextBytes);
        network.maybeCache(response, bytes);
        const charset = String(response.headers['content-type'] || '').match(/charset\s*=\s*["']?([^;"'\s]+)/i)?.[1] || 'utf-8';
        let source; try { source = new TextDecoder(charset).decode(bytes); } catch { fail(422, 'CHARSET_UNSUPPORTED', 'Unsupported upstream text encoding.'); }
        const context = { proxyOrigin: config.origin, cap: cap.id, channel: cap.tab.channel, state: kind === 'html' ? state.snapshot(cap, response.url) : undefined, storageLimit: config.maxStorageBytes };
        const output = await rewriter.run(kind, source, response.url, context);
        if (controller.signal.aborted) return;
        res.type(kind === 'html' ? 'text/html; charset=utf-8' : kind === 'css' ? 'text/css; charset=utf-8' : 'text/javascript; charset=utf-8');
        // Downstream transformed text is sent once, without upstream content-length/encoding/integrity metadata.
        res.removeHeader('etag');
        if (output.length > 1024 && /\bgzip\b/.test(req.headers['accept-encoding'] || '')) {
          const compressed = await compress(output, { level: 4 });
          return res.set('Content-Encoding', 'gzip').end(compressed);
        }
        return res.send(output);
      }
      const source = decodedStream(response.body, response.headers);
      // Cache only bounded, explicitly sized assets. Large/unknown resources remain streams.
      if (response.cacheKey && !response.headers['content-encoding'] && Number(response.headers['content-length']) <= 512 * 1024 && /\bpublic\b/.test(String(response.headers['cache-control']))) {
        const bytes = await collect(source, 512 * 1024); network.maybeCache(response, bytes); network.metrics.streamedBytes += bytes.length; return res.end(bytes);
      }
      const counter = byteLimit(config.maxAssetBytes);
      counter.on('data', chunk => { network.metrics.streamedBytes += chunk.length; });
      await pipeline(source, counter, res, { signal: controller.signal });
    } finally { clearTimeout(timeout); res.off('close', onClose); cap.tab.controllers.delete(controller); release?.(); }
  });

  const wss = new WebSocketServer({ noServer: true, maxPayload: 1024 * 1024, perMessageDeflate: false, handleProtocols: (_protocols, req) => req.ironProtocol || false });
  server.on('upgrade', async (req, socket, head) => {
    let upstream;
    try {
      if (stopping || req.headers.origin !== 'null') fail(403, 'WS_ORIGIN', 'Invalid WebSocket origin.');
      const route = new URL(req.url, config.origin).pathname.split('/');
      if (route.length !== 4 || route[1] !== 'ws') fail(404, 'WS_ROUTE', 'Invalid WebSocket route.');
      const cap = state.getCap(route[2]); wsLimit.take(cap.tab.id);
      if (cap.tab.sockets.size >= 8) fail(429, 'WS_LIMIT', 'Too many WebSockets in this tab.');
      const target = decodeURL(route[3]);
      if (injected.validateWebSocket) injected.validateWebSocket(target); else validateTarget(target, config.origin, true);
      const url = new URL(target); const httpURL = target.replace(/^ws/, 'http');
      const protocols = String(req.headers['sec-websocket-protocol'] || '').split(',').map(p => p.trim()).filter(Boolean);
      const cookie = new URL(httpURL).origin === cap.origin ? cap.tab.jar.getCookieStringSync(httpURL) : '';
      upstream = new WebSocket(url, protocols, { lookup: network.lookup, followRedirects: false, origin: cap.origin, headers: cookie ? { Cookie: cookie } : {}, handshakeTimeout: 10_000, maxPayload: 1024 * 1024, perMessageDeflate: false });
      cap.tab.sockets.add(upstream);
      socket.once('close', () => upstream.terminate());
      upstream.once('close', () => cap.tab.sockets.delete(upstream));
      await new Promise((resolve, reject) => { upstream.once('open', resolve); upstream.once('error', reject); });
      req.ironProtocol = upstream.protocol;
      wss.handleUpgrade(req, socket, head, downstream => {
        cap.tab.sockets.add(downstream);
        const relay = (from, to) => from.on('message', (data, binary) => {
          if (to.readyState !== WebSocket.OPEN) return from.close(1011, 'Upstream unavailable');
          if (to.bufferedAmount > 2 * 1024 * 1024) return from.close(1013, 'Slow connection');
          from.pause(); to.send(data, { binary }, error => { if (error) from.terminate(); else from.resume(); });
        });
        relay(downstream, upstream); relay(upstream, downstream);
        downstream.on('error', () => upstream.terminate()); upstream.on('error', () => downstream.terminate());
        downstream.on('close', () => { cap.tab.sockets.delete(downstream); upstream.close(); });
        upstream.on('close', () => downstream.close());
      });
    } catch { upstream?.terminate(); if (!socket.destroyed) { socket.write('HTTP/1.1 403 Forbidden\r\nConnection: close\r\n\r\n'); socket.destroy(); } }
  });

  app.get('/runtime.js', async (_req, res) => { res.removeHeader('Content-Security-Policy'); res.set({ 'Access-Control-Allow-Origin': '*', 'Cache-Control': 'public, max-age=3600' }).type('text/javascript').send(await readFile(path.join(ROOT, 'dist/runtime.js'))); });
  app.use(express.static(path.join(ROOT, 'dist'), { index: 'index.html', dotfiles: 'deny', etag: true, maxAge: 0 }));
  app.use((_req, res) => res.status(404).json({ error: 'NOT_FOUND' }));
  app.use((error, req, res, _next) => {
    if (res.headersSent) return res.destroy();
    const status = error.status >= 400 && error.status <= 599 ? error.status : error.name === 'AbortError' ? 504 : 502;
    const code = error.code && /^[A-Z_]+$/.test(error.code) ? error.code : status === 504 ? 'TIMEOUT' : 'REQUEST_FAILED';
    const message = error instanceof IronError || error.code === 'REWRITE_FAILED' ? error.message : status === 413 ? 'Resource exceeds the configured size limit.' : 'The request could not be completed. Retry or check diagnostics.';
    // Deliberately exclude URLs, credentials, headers, cookies, and raw exception objects.
    if (status >= 500) process.stderr.write(JSON.stringify({ event: 'request_error', code, status }) + '\n');
    if (req.path.startsWith('/p/') && ['document', 'iframe'].includes(req.headers['sec-fetch-dest'])) {
      res.set('Content-Security-Policy', contentCSP(config.origin)).status(status).type('html').send(`<!doctype html><meta charset="utf-8"><title>IRON · Request stopped</title><style>body{background:#10141c;color:#d8e2f1;font:16px system-ui;padding:8vw;max-width:700px}small{color:#55a6ff}h1{font-size:30px}</style><small>IRON CORE · ${escape(code)}</small><h1>This page could not load.</h1><p>${escape(message)}</p><p>Use the browser address bar to retry or navigate elsewhere.</p>`);
    } else res.status(status).json({ error: code, message });
  });
  async function close() {
    stopping = true; state.close(); wss.close();
    const deadline = setTimeout(() => server.closeAllConnections(), 5000); deadline.unref();
    await Promise.allSettled([rewriter.close(), network.close(), new Promise(resolve => server.close(resolve))]); clearTimeout(deadline);
  }
  return { app, server, state, network, rewriter, close };
}

if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) {
  const config = readConfig(); const application = await createApplication(config);
  application.server.listen(config.port, '0.0.0.0', () => process.stdout.write(`IRON 0.1 listening on 0.0.0.0:${config.port}\n`));
  let closing = false;
  for (const signal of ['SIGTERM', 'SIGINT']) process.on(signal, async () => { if (closing) return; closing = true; await application.close(); process.exit(0); });
}
