export function readConfig(env = process.env) {
  const port = Number(env.PORT || 3000);
  const origin = new URL(env.PUBLIC_ORIGIN || `http://localhost:${port}`).origin;
  const production = env.NODE_ENV === 'production';
  if (!Number.isInteger(port) || port < 1 || port > 65535) throw new Error('Invalid PORT');
  if (!env.IRON_PASSWORD || env.IRON_PASSWORD.length < 16 || env.IRON_PASSWORD.length > 256) throw new Error('IRON_PASSWORD must contain 16–256 characters.');
  if (production && !origin.startsWith('https://')) throw new Error('PUBLIC_ORIGIN must use HTTPS in production.');
  return Object.freeze({
    port, origin, production, password: env.IRON_PASSWORD,
    braveKey: env.BRAVE_SEARCH_API_KEY || '',
    maxTabs: 12, maxLogins: 16, sessionMs: 8 * 60 * 60 * 1000,
    maxTextBytes: 4 * 1024 * 1024, maxAssetBytes: 128 * 1024 * 1024,
    maxBodyBytes: 8 * 1024 * 1024, maxStorageBytes: 256 * 1024,
    concurrency: 12, perTabConcurrency: 4, queueLimit: 128,
    cacheBytes: 16 * 1024 * 1024,
  });
}
