import { parentPort } from 'node:worker_threads';
import { rewriteHTML, rewriteCSS, rewriteJS } from './core.js';
parentPort.on('message', ({ id, kind, source, base, context }) => {
  try {
    const fn = { html: rewriteHTML, css: rewriteCSS, js: rewriteJS }[kind];
    if (!fn) throw new Error('Unknown transform type');
    const result = fn(source, base, context);
    if (Buffer.byteLength(result) > 16 * 1024 * 1024) throw new Error('Transformed output exceeds 16 MiB.');
    parentPort.postMessage({ id, result });
  } catch (e) { parentPort.postMessage({ id, error: `Cannot safely transform ${kind}: ${e.message}` }); }
});
