import dns from 'node:dns';
import net from 'node:net';
import ipaddr from 'ipaddr.js';
import { randomBytes, timingSafeEqual, scrypt } from 'node:crypto';
import { promisify } from 'node:util';

export class IronError extends Error {
  constructor(status, code, message) { super(message); this.status = status; this.code = code; }
}
export const token = () => randomBytes(32).toString('base64url');
export const fail = (status, code, message) => { throw new IronError(status, code, message); };
export const equal = (a, b) => typeof a === 'string' && typeof b === 'string' && Buffer.byteLength(a) === Buffer.byteLength(b) && timingSafeEqual(Buffer.from(a), Buffer.from(b));
export const hashPassword = async (password, salt) => promisify(scrypt)(password, salt, 64);

export function isPublicAddress(input) {
  try {
    const addr = ipaddr.process(input);
    if (addr.range() !== 'unicast') return false;
    if (addr.kind() === 'ipv6' && !addr.match(ipaddr.parse('2000::'), 3)) return false;
    return true;
  } catch { return false; }
}

export function validateTarget(input, ownOrigin = '', websocket = false) {
  let url;
  try { url = new URL(input); } catch { fail(400, 'URL_INVALID', 'Enter a valid absolute URL.'); }
  const schemes = websocket ? ['ws:', 'wss:'] : ['http:', 'https:'];
  if (!schemes.includes(url.protocol)) fail(400, 'SCHEME_BLOCKED', 'Only HTTP(S) browsing is supported.');
  if (url.username || url.password || url.href.length > 8192) fail(400, 'URL_BLOCKED', 'Credentials in URLs and oversized URLs are not accepted.');
  if (url.port && !['80', '443'].includes(url.port)) fail(403, 'PORT_BLOCKED', 'Only upstream ports 80 and 443 are permitted.');
  const host = url.hostname.replace(/^\[|\]$/g, '').toLowerCase().replace(/\.$/, '');
  if (!host || /(^|\.)(localhost|local|internal|lan|home|onion)$/.test(host) || !host.includes('.') && !net.isIP(host)) fail(403, 'HOST_BLOCKED', 'Local and internal hostnames are blocked.');
  if (ownOrigin && host === new URL(ownOrigin).hostname.replace(/^\[|\]$/g, '')) fail(403, 'SELF_PROXY', 'IRON cannot proxy its own host.');
  if (net.isIP(host) && !isPublicAddress(host)) fail(403, 'IP_BLOCKED', 'Private, reserved, and special-use addresses are blocked.');
  url.hash = '';
  return url;
}

// This callback is installed on the actual connector: there is no second DNS lookup.
export function safeLookup(host, options, callback) {
  dns.lookup(host, { all: true, verbatim: true }, (error, addresses) => {
    if (error) return callback(error);
    if (!addresses.length || addresses.some(a => !isPublicAddress(a.address))) return callback(new IronError(403, 'DNS_BLOCKED', 'DNS returned a non-public address.'));
    const family = typeof options === 'number' ? options : options?.family;
    const filtered = family ? addresses.filter(a => a.family === family) : addresses;
    if (!filtered.length) return callback(new IronError(502, 'DNS_EMPTY', 'No usable DNS address.'));
    if (options?.all) callback(null, filtered);
    else callback(null, filtered[0].address, filtered[0].family);
  });
}

export class RateLimiter {
  constructor(limit, period, maxKeys = 4096) { this.limit = limit; this.period = period; this.maxKeys = maxKeys; this.items = new Map(); }
  take(key) {
    const now = Date.now();
    let entry = this.items.get(key);
    if (!entry || now - entry.since >= this.period) {
      if (!entry && this.items.size >= this.maxKeys) {
        for (const [k, v] of this.items) if (now - v.since >= this.period) this.items.delete(k);
        if (this.items.size >= this.maxKeys) fail(429, 'RATE_LIMIT', 'Please try again later.');
      }
      this.items.set(key, entry = { since: now, count: 0 });
    }
    if (++entry.count > this.limit) fail(429, 'RATE_LIMIT', 'Too many requests; please wait.');
  }
}

export function shellHeaders(origin) {
  return {
    'Content-Security-Policy': `default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; connect-src 'self'; frame-src 'self'; object-src 'none'; base-uri 'none'; frame-ancestors 'none'; form-action 'self'`,
    'X-Content-Type-Options': 'nosniff', 'Referrer-Policy': 'no-referrer',
    'Permissions-Policy': 'camera=(), microphone=(), geolocation=(), payment=(), usb=(), serial=(), bluetooth=()',
    ...(origin.startsWith('https:') ? { 'Strict-Transport-Security': 'max-age=31536000' } : {}),
  };
}
export function contentCSP(origin) {
  const ws = origin.replace(/^http/, 'ws');
  return `sandbox allow-scripts allow-forms allow-downloads; default-src 'none'; script-src 'unsafe-inline' ${origin}/p/ ${origin}/runtime.js; style-src 'unsafe-inline' ${origin}/p/; img-src ${origin}/p/ data: blob:; font-src ${origin}/p/ data:; media-src ${origin}/p/ blob:; connect-src ${origin}/p/ ${origin}/v/ ${ws}/ws/; frame-src ${origin}/p/; form-action ${origin}/p/; object-src 'none'; base-uri 'none'; worker-src 'none'; frame-ancestors ${origin}`;
}
