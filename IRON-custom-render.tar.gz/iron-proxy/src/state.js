import { CookieJar } from 'tough-cookie';
import { token, fail } from './security.js';

export class State {
  constructor(config) {
    this.config = config; this.logins = new Map(); this.tabs = new Map(); this.caps = new Map();
    this.sweeper = setInterval(() => this.sweep(), 60_000); this.sweeper.unref();
  }
  login() {
    this.sweep();
    if (this.logins.size >= this.config.maxLogins) fail(429, 'LOGIN_LIMIT', 'Too many active browser sessions.');
    const user = { id: token(), csrf: token(), expires: Date.now() + this.config.sessionMs, tabs: new Set() };
    this.logins.set(user.id, user); return user;
  }
  createTab(user, privateMode = false) {
    if (user.tabs.size >= this.config.maxTabs) fail(429, 'TAB_LIMIT', 'Close a tab before opening another.');
    const tab = { id: token(), userId: user.id, channel: token(), private: !!privateMode, jar: new CookieJar(), storage: new Map(), caps: new Set(), sockets: new Set(), controllers: new Set(), url: '', cacheEnabled: true, expires: user.expires };
    this.tabs.set(tab.id, tab); user.tabs.add(tab.id); return tab;
  }
  cap(tab, url) {
    if (tab.caps.size >= 64) {
      const oldest = tab.caps.values().next().value;
      this.caps.delete(oldest); tab.caps.delete(oldest);
    }
    const cap = { id: token(), tab, origin: new URL(url).origin, url, expires: tab.expires };
    this.caps.set(cap.id, cap); tab.caps.add(cap.id); return cap;
  }
  getCap(id) {
    const cap = this.caps.get(id);
    if (!cap || cap.expires < Date.now() || !this.tabs.has(cap.tab.id)) fail(401, 'SESSION_EXPIRED', 'This tab session expired. Reload it from the address bar.');
    return cap;
  }
  getTab(user, id) {
    const tab = this.tabs.get(id);
    if (!tab || tab.userId !== user.id) fail(404, 'TAB_MISSING', 'Tab not found.');
    return tab;
  }
  resetNavigation(tab) {
    for (const c of tab.controllers) c.abort();
    for (const ws of tab.sockets) ws.close(1001, 'Navigation');
    for (const id of tab.caps) this.caps.delete(id);
    tab.controllers.clear(); tab.sockets.clear(); tab.caps.clear();
  }
  closeTab(tab) {
    this.resetNavigation(tab); this.logins.get(tab.userId)?.tabs.delete(tab.id);
    this.tabs.delete(tab.id); tab.storage.clear(); tab.jar.removeAllCookiesSync();
  }
  logout(user) { for (const id of [...user.tabs]) { const tab = this.tabs.get(id); if (tab) this.closeTab(tab); } this.logins.delete(user.id); }
  sweep() { for (const user of this.logins.values()) if (user.expires < Date.now()) this.logout(user); }
  close() { clearInterval(this.sweeper); for (const user of [...this.logins.values()]) this.logout(user); }
  snapshot(cap, url) {
    const store = cap.tab.storage.get(cap.origin) || { local: {}, session: {} };
    const cookies = cap.tab.jar.getCookiesSync(url, { http: false }).map(c => ({ key: c.key, value: c.value, domain: c.domain, path: c.path, hostOnly: c.hostOnly, secure: c.secure, expires: c.expiryTime() }));
    return { local: store.local, session: store.session, cookies };
  }
}

export class Scheduler {
  constructor(max = 24, perTab = 6, queueLimit = 128) { this.max = max; this.perTab = perTab; this.queueLimit = queueLimit; this.active = 0; this.counts = new Map(); this.queue = []; }
  acquire(key, signal) {
    if (signal?.aborted) return Promise.reject(new DOMException('Aborted', 'AbortError'));
    if (this.queue.length >= this.queueLimit) return Promise.reject(Object.assign(new Error('Network queue full'), { status: 503, code: 'QUEUE_FULL' }));
    return new Promise((resolve, reject) => {
      const item = { key, resolve, reject, signal };
      item.abort = () => { this.queue = this.queue.filter(x => x !== item); reject(new DOMException('Aborted', 'AbortError')); };
      signal?.addEventListener('abort', item.abort, { once: true });
      this.queue.push(item); this.drain();
    });
  }
  drain() {
    for (let i = 0; i < this.queue.length && this.active < this.max;) {
      const item = this.queue[i];
      if ((this.counts.get(item.key) || 0) >= this.perTab) { i++; continue; }
      this.queue.splice(i, 1); item.signal?.removeEventListener('abort', item.abort);
      this.active++; this.counts.set(item.key, (this.counts.get(item.key) || 0) + 1);
      let released = false;
      item.resolve(() => {
        if (released) return; released = true; this.active--;
        const count = this.counts.get(item.key) - 1;
        if (count) this.counts.set(item.key, count); else this.counts.delete(item.key);
        this.drain();
      });
    }
  }
}

export class ByteCache {
  constructor(maxBytes) { this.maxBytes = maxBytes; this.bytes = 0; this.items = new Map(); this.hits = 0; this.misses = 0; }
  get(key) {
    const entry = this.items.get(key);
    if (!entry || entry.expires < Date.now()) { if (entry) this.delete(key); this.misses++; return null; }
    this.items.delete(key); this.items.set(key, entry); this.hits++; return entry;
  }
  set(key, data, ttl) {
    this.delete(key); const size = data.body.byteLength;
    if (size > this.maxBytes || ttl <= 0) return;
    while (this.bytes + size > this.maxBytes) this.delete(this.items.keys().next().value);
    this.items.set(key, { ...data, size, expires: Date.now() + ttl }); this.bytes += size;
  }
  delete(key) { const entry = this.items.get(key); if (entry) this.bytes -= entry.size; this.items.delete(key); }
  clear() { this.items.clear(); this.bytes = 0; }
}
