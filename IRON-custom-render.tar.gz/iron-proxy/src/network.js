import { Agent, request } from 'undici';
import { Readable, Transform } from 'node:stream';
import { createGunzip, createInflate, createBrotliDecompress } from 'node:zlib';
import { safeLookup, validateTarget, fail } from './security.js';
import { Scheduler, ByteCache } from './state.js';

const FORWARD = new Set(['accept', 'accept-language', 'content-type', 'range', 'if-range', 'authorization']);
const SIMPLE_HEADERS = new Set(['accept', 'accept-language', 'content-language', 'content-type']);
const SIMPLE_TYPES = ['application/x-www-form-urlencoded', 'multipart/form-data', 'text/plain'];
export function corsAllowed(headers, origin) { return headers['access-control-allow-origin'] === '*' || headers['access-control-allow-origin'] === origin; }
export function corsNeeded(destination, mode) { return !destination || mode === 'cors'; }

export function decodedStream(body, headers) {
  const encoding = String(headers['content-encoding'] || '').toLowerCase();
  const decoder = encoding === 'gzip' ? createGunzip() : encoding === 'br' ? createBrotliDecompress() : encoding === 'deflate' ? createInflate() : null;
  if (encoding && encoding !== 'identity' && !decoder) { body.destroy(); fail(502, 'ENCODING_UNSUPPORTED', 'Unsupported upstream content encoding.'); }
  if (!decoder) return body;
  body.on('error', e => decoder.destroy(e)); decoder.on('close', () => body.destroy());
  return body.pipe(decoder);
}
export function byteLimit(max) {
  let size = 0;
  return new Transform({ transform(chunk, encoding, callback) { size += chunk.length; callback(size > max ? Object.assign(new Error('Resource exceeds configured size limit.'), { status: 413, code: 'SIZE_LIMIT' }) : null, chunk); } });
}
export async function collect(stream, max) {
  const chunks = []; let size = 0;
  for await (const chunk of stream) { size += chunk.length; if (size > max) { stream.destroy(); fail(413, 'SIZE_LIMIT', 'Resource exceeds configured size limit.'); } chunks.push(Buffer.from(chunk)); }
  return Buffer.concat(chunks, size);
}

export class Network {
  constructor(config, overrides = {}) {
    this.config = config;
    this.validate = overrides.validate || (url => validateTarget(url, config.origin));
    this.lookup = overrides.lookup || safeLookup;
    this.agent = new Agent({ connections: 4, pipelining: 1, maxOrigins: 64, keepAliveTimeout: 15_000, keepAliveMaxTimeout: 30_000, connect: { lookup: this.lookup, timeout: 10_000 } });
    this.scheduler = new Scheduler(config.concurrency, config.perTabConcurrency, config.queueLimit);
    this.cache = new ByteCache(config.cacheBytes);
    this.metrics = { upstreamRequests: 0, upstreamErrors: 0, redirects: 0, streamedBytes: 0 };
  }
  async open(url, options) {
    this.metrics.upstreamRequests++;
    try {
      const response = await request(this.validate(url), { dispatcher: this.agent, headersTimeout: 20_000, bodyTimeout: 20_000, maxRedirections: 0, ...options });
      // Rejected CORS/redirect bodies are intentionally destroyed. Keep their
      // asynchronous abort events handled; stream consumers still receive errors.
      response.body.on('error', () => {});
      return response;
    }
    catch (e) { this.metrics.upstreamErrors++; throw e; }
  }
  async preflight(url, cap, method, headers, signal) {
    const custom = Object.keys(headers).filter(k => k !== 'origin' && k !== 'accept-encoding' && (!SIMPLE_HEADERS.has(k) || k === 'content-type' && !SIMPLE_TYPES.includes(headers[k].split(';')[0].toLowerCase())));
    if (['GET', 'HEAD', 'POST'].includes(method) && !custom.length) return;
    const response = await this.open(url, { method: 'OPTIONS', headers: { origin: cap.origin, 'access-control-request-method': method, ...(custom.length ? { 'access-control-request-headers': custom.join(', ') } : {}) }, signal });
    response.body.destroy();
    const methods = String(response.headers['access-control-allow-methods'] || '').toUpperCase().split(/\s*,\s*/);
    const allowed = String(response.headers['access-control-allow-headers'] || '').toLowerCase().split(/\s*,\s*/);
    if (response.statusCode < 200 || response.statusCode >= 300 || !corsAllowed(response.headers, cap.origin) || !methods.includes(method) || custom.some(k => !allowed.includes(k) && !allowed.includes('*'))) fail(403, 'CORS_PREFLIGHT', 'The upstream website did not permit this cross-origin request.');
  }
  async fetch(cap, target, { method = 'GET', headers: incoming = {}, body, signal, destination = '', mode = 'cors', credentials = 'same-origin' } = {}) {
    let url = this.validate(target);
    const navigation = ['iframe', 'document'].includes(destination);
    let requestBody = body;
    for (let hop = 0; hop <= 10; hop++) {
      const sameOrigin = url.origin === cap.origin;
      const headers = { 'accept-encoding': 'gzip, br, deflate' };
      for (const [key, value] of Object.entries(incoming)) if (FORWARD.has(key) && typeof value === 'string') headers[key] = value;
      if (!sameOrigin) delete headers.authorization;
      if (credentials !== 'omit' && (sameOrigin || navigation)) {
        const cookie = cap.tab.jar.getCookieStringSync(url.href, { sameSiteContext: sameOrigin ? 'strict' : method === 'GET' && navigation ? 'lax' : 'none' });
        if (cookie) headers.cookie = cookie;
      }
      if (!['GET', 'HEAD'].includes(method) || !navigation && !sameOrigin) headers.origin = cap.origin;
      if (!sameOrigin && !navigation && corsNeeded(destination, mode)) await this.preflight(url, cap, method, headers, signal);
      const cacheKey = `${url.href}\n${headers.accept || ''}\n${headers['accept-language'] || ''}`;
      const cacheEligible = cap.tab.cacheEnabled && method === 'GET' && !headers.cookie && !headers.authorization && !navigation && !headers.range;
      const cached = cacheEligible ? this.cache.get(cacheKey) : null;
      const response = cached ? { statusCode: cached.statusCode, headers: cached.headers, body: Readable.from(cached.body) } : await this.open(url.href, { method, headers, body: requestBody, signal });
      if (!sameOrigin && !navigation && corsNeeded(destination, mode) && !corsAllowed(response.headers, cap.origin)) {
        response.body.destroy(); fail(403, 'CORS_BLOCKED', 'The upstream website does not permit this cross-origin read.');
      }
      if (credentials !== 'omit' && (sameOrigin || navigation)) {
        for (const cookie of [].concat(response.headers['set-cookie'] || []).slice(0, 64)) {
          if (typeof cookie !== 'string' || cookie.length > 4096) continue;
          try {
            const candidate = cap.tab.jar.cloneSync(); candidate.setCookieSync(cookie, url.href, { ignoreError: true });
            if (candidate.serializeSync().cookies.length <= 256) cap.tab.jar = candidate;
          } catch { /* Invalid upstream cookies are ignored as in browsers. */ }
        }
      }
      if ([301, 302, 303, 307, 308].includes(response.statusCode) && response.headers.location) {
        response.body.destroy();
        if (hop === 10) fail(508, 'REDIRECT_LOOP', 'Too many upstream redirects.');
        const next = this.validate(new URL(response.headers.location, url).href);
        if (([301, 302].includes(response.statusCode) && method === 'POST') || response.statusCode === 303 && method !== 'HEAD') { method = 'GET'; requestBody = undefined; incoming = { ...incoming }; delete incoming['content-type']; }
        if (next.origin !== url.origin) { incoming = { ...incoming }; delete incoming.authorization; }
        url = next; this.metrics.redirects++; continue;
      }
      return { ...response, url: url.href, cacheKey: cacheEligible && !cached ? cacheKey : null, cached: !!cached };
    }
  }
  maybeCache(response, buffer) {
    const headers = response.headers;
    const cc = String(headers['cache-control'] || '');
    const ttl = Number(cc.match(/(?:^|,)\s*max-age=(\d+)/i)?.[1] || 0);
    if (!response.cacheKey || response.statusCode !== 200 || buffer.length > 512 * 1024 || !/\bpublic\b/i.test(cc) || /\b(private|no-store|no-cache)\b/i.test(cc) || headers['set-cookie'] || headers.vary || !ttl) return;
    this.cache.set(response.cacheKey, { body: buffer, headers: { ...headers, 'content-encoding': 'identity' }, statusCode: response.statusCode }, Math.min(ttl, 300) * 1000);
  }
  async close() { this.cache.clear(); await this.agent.destroy(); }
}
