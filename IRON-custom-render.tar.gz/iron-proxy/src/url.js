export function encodeURL(value) { return Buffer.from(value, 'utf8').toString('base64url'); }
export function decodeURL(value) {
  if (!/^[A-Za-z0-9_-]+$/.test(value)) throw new Error('Invalid encoded URL');
  const result = Buffer.from(value, 'base64url').toString('utf8');
  if (encodeURL(result) !== value) throw new Error('Non-canonical encoded URL');
  return result;
}
export function proxyURL(value, base, context) {
  const raw = String(value).trim();
  if (!raw || raw.startsWith('#') || /^(data:|blob:|mailto:|tel:)/i.test(raw)) return raw;
  if (/^javascript:/i.test(raw)) return 'about:blank';
  try {
    const url = new URL(raw, base);
    if (url.origin === context.proxyOrigin && url.pathname.startsWith('/p/')) return url.href;
    if (!['http:', 'https:'].includes(url.protocol)) return 'about:blank';
    const hash = url.hash; url.hash = '';
    return `${context.proxyOrigin}/p/${context.cap}/${encodeURL(url.href)}${hash}`;
  } catch { return 'about:blank'; }
}
