import { readdir, readFile, writeFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import path from 'node:path';
import { spawnSync } from 'node:child_process';

// Run from the project root after verification. Keep credentials, dependencies,
// and internal browser screenshots out of the distributable.
const ignored = new Set(['node_modules', '.git']);
async function files(directory = '.') {
  const result = [];
  for (const entry of await readdir(directory, { withFileTypes: true })) {
    if (ignored.has(entry.name) || entry.name === '.env' || entry.name.startsWith('.env.') && entry.name !== '.env.example' || entry.name.endsWith('.local.json')) continue;
    const location = path.join(directory, entry.name);
    if (entry.isDirectory()) result.push(...await files(location));
    else if (!location.endsWith('.png') && !location.endsWith('.zip') && !location.endsWith('MANIFEST.sha256')) result.push(location);
  }
  return result.sort();
}
const paths = await files(); const manifest = [];
for (const file of paths) manifest.push(`${createHash('sha256').update(await readFile(file)).digest('hex')}  ${file}`);
await writeFile('MANIFEST.sha256', manifest.join('\n') + '\n');
const output = path.resolve('..', 'iron-proxy-v0.1.0.zip');
const result = spawnSync('zip', ['-q', output, ...paths, 'MANIFEST.sha256'], { stdio: 'inherit' });
if (result.status !== 0) throw new Error('zip packaging failed. Install zip or archive this folder using your file manager.');
console.log(`Packaged ${paths.length + 1} complete files: ${output}`);
