import { build } from 'esbuild';
import { mkdir, copyFile } from 'node:fs/promises';
await mkdir(new URL('../dist/', import.meta.url), { recursive: true });
await build({ entryPoints: ['web/app.js', 'web/runtime.js'], bundle: true, minify: true, sourcemap: false, outdir: 'dist', target: ['chrome110', 'firefox115', 'safari16.4'] });
for (const file of ['index.html', 'style.css']) await copyFile(`web/${file}`, `dist/${file}`);
console.log('Built IRON BROWSER and isolated content runtime.');
