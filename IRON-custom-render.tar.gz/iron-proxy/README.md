# IRON PROXY 0.1.0

**A runnable engineering alpha with an independent proxy engine, a browser shell, and Node transport.** Complete source, reproducible tests, raw benchmark results and a Render blueprint are included. This project does not bundle Ultraviolet, Rammerhead or Scramjet. It does not have a native rendering engine and does not claim to outperform them.

Start with [the architecture](docs/ARCHITECTURE.md), [verified results](docs/VERIFICATION.md), [compatibility matrix](docs/COMPATIBILITY.md), and [security design](docs/SECURITY.md). The first release implements a useful subset of the requested browser; remaining work is explicit in [the phase roadmap](docs/ROADMAP.md).

## What runs

- **IRON CORE:** parse5 HTML transforms, css-tree CSS transforms, scope-aware Acorn JavaScript edits, URL routing, runtime interception, cookie/storage partitioning, redirects and a bounded rewrite worker.
- **IRON NETWORK:** real HTTP(S) requests, reusable Undici connections, DNS/SSRF checks, bounded streams and queues, WS relay, controlled raw resource cache and authentication.
- **IRON BROWSER:** midnight/graphite desktop and mobile shell, isolated website area, tabs, private tabs, omnibox, back/forward/reload, bookmarks/history, downloads, low-memory suspension, settings and live diagnostics.
- **Real search:** a server-side Brave Search API adapter. A valid API key is needed. Without one, URL navigation works and query searches report the missing configuration; they never fabricate results.

## Run locally with Node

Requires Node 24.22.1 or a later supported 24.x patch. No Python is needed. A static host alone cannot run IRON NETWORK.

```sh
npm ci
npm run build
cp .env.example .env
node -e "console.log(require('crypto').randomBytes(24).toString('base64url'))"
```

Paste the generated password into IRON_PASSWORD in `.env`, then:

```sh
npm start
```

Open exactly `http://localhost:3000` and sign in with that password. PUBLIC_ORIGIN must exactly match the scheme, hostname and port you use in your browser. A localhost/127.0.0.1 mismatch deliberately fails Origin validation. The server listens on `0.0.0.0` and honors PORT. Keep `.env` out of Git.

No API key or default production password is included. The test fixture uses its own public test password and a dependency-injected loopback resolver; neither is a production setting.

## Deploy on Render from a Chromebook

You can upload the extracted project through GitHub's web interface and use Render's dashboard; installing Node or Python on your Chromebook is unnecessary for deployment.

1. Create a Git repository and upload the **contents** of the `iron-proxy` folder. `package.json`, `package-lock.json` and `render.yaml` must be at the repository root. Upload the actual files, not only the ZIP.
2. In Render, create a Blueprint from that repository or a Node Web Service using the settings below. The included blueprint selects the Free plan for evaluation and disables automatic deploys. Check your account's current availability/quotas. Render documents its Free tier as unsuitable for production and says idle instances spin down; use an appropriate production tier only after validation.
3. Set PUBLIC_ORIGIN to the exact HTTPS URL assigned to the service, without a path. Set IRON_PASSWORD to a fresh random secret of 16–256 characters. If the hostname is assigned only after creation, update PUBLIC_ORIGIN before retrying the first deployment. Keep one instance.
4. Optionally add BRAVE_SEARCH_API_KEY as a secret environment variable to enable real search. It is not needed to start the server or navigate a URL.
5. Deploy, confirm `/health` returns `{"ok":true,"version":"0.1.0"}`, open the assigned URL, and sign in. Test a simple public page before relying on complex sites.

| Setting | Value |
| --- | --- |
| Runtime | Node |
| Node version | 24.22.1 |
| Build | `npm ci --include=dev && npm run build && npm prune --omit=dev` |
| Start | `npm start` |
| Health endpoint | `/health` |
| NODE_ENV | `production` |
| PUBLIC_ORIGIN | Exact assigned HTTPS origin |
| IRON_PASSWORD | Your generated secret |
| BRAVE_SEARCH_API_KEY | Optional provider key |
| PORT | Supplied by Render; code binds `0.0.0.0:$PORT` |
| Instances | One |

Sessions, cookies and virtual site storage are in memory. Server restart, sleep or redeploy loses them. Bookmarks/history stay in the shell browser's local storage. WebSockets use the same HTTP service port and upgrade to WSS under HTTPS. SIGTERM closes sessions/sockets, terminates the worker and destroys network pools.

This archive has **not** been deployed to a Render account. Public DNS resolution in the build environment failed during an HTTPS smoke test, so public-site and deployed TLS behavior still need validation. Fixture tests establish real local network behavior, not a broad internet compatibility guarantee.

## Verification commands

```sh
npm test
npx playwright install chromium
npm run test:browser
npm run bench
npm run bench:rewrite
npm run bench:startup
```

`npm run check` builds and runs both test layers. Production Render builds do not download Chromium or run browser tests. Tests use real ephemeral HTTP/WS servers and a test-only resolver, without disabling production SSRF policy. The browser suite also checks that upstream resource requests never bypass IRON.

See [benchmark methodology](docs/BENCHMARKS.md) for independent engine adapters, a standalone public fixture server, hardware/network controls, process CPU/RSS sampling, and why the bundled results cannot establish superiority. The generic competitor adapter is complete, but no competitor-specific deployment/configuration has been verified.

## Everyday use

Enter an HTTP(S) URL or a search query in the omnibox. Click + for a separate tab session or Private + to omit local history/bookmarks. The star toggles a bookmark. The side rail opens history, bookmarks, downloads and diagnostics. Downloads are requested through IRON but saved by your host browser.

Settings include appearance, reduced motion, the configured search API, history controls, cache clearing, cookie/storage clearing and the maximum live page count. Suspending a tab retains its server-side site data but discards its document/JavaScript/form state; selecting it reloads the page.

Keyboard shortcuts while the shell has focus: Alt+L address bar; Alt+T new tab; Alt+Shift+T private tab; Alt+W close; Alt+R reload; Alt+Left/Right history; Alt+1…9 switch tabs. Native browser Ctrl/Cmd shortcuts remain native, and embedded content can consume keys while focused.

## What is intentionally not promised

Arbitrary modern site compatibility; Google/Microsoft login flows; CAPTCHA/anti-bot bypass; DRM; service/dedicated/shared workers; IndexedDB; WebRTC; device permissions; complete nested-frame behavior; full SPA history identity; perfect native Cookie/Storage/Request/Response semantics; anonymous browsing; multi-instance persistence; performance on a real 4 GB Chromebook. Read the matrix before choosing a workload.

The isolated frame is a rendering container inside a complete shell. Native browser sandboxing provides isolation. IRON's source transforms and runtime hooks coordinate supported navigation and APIs; they do not replace Chromium/WebKit/Gecko or completely virtualize arbitrary hostile JavaScript.

## Source map

| Path | Responsibility |
| --- | --- |
| `src/url.js` | Fast URL codec, mapping and double-rewrite guard |
| `src/core.js` | Parsed HTML/CSS/JavaScript transforms |
| `src/rewriter.js`, `src/rewrite-worker.js` | Lazy bounded parser worker |
| `src/network.js` | HTTP transport, preflight, redirects, streaming and cache policy |
| `src/security.js` | URL/DNS policy, authentication primitives and CSP |
| `src/state.js` | Tab/capability/cookie state, byte cache and admission scheduler |
| `src/server.js` | Authenticated control API, resource routes, search, WS and lifecycle |
| `web/runtime.js` | Isolated page API adapters and navigation messages |
| `web/app.js`, `web/index.html`, `web/style.css` | Browser shell and design system |
| `scripts/build.mjs` | Small frontend production bundles |
| `tests/` | Unit, transport and real-browser fixtures/tests |
| `bench/` | Navigation, rewriting, startup and process measurement tools |
| `artifacts/` | Recorded machine-readable verification evidence |
| `docs/` | Architecture, compatibility, security, methodology and remaining phases |

MIT-licensed original source. Installed dependencies retain their own licenses; see THIRD_PARTY_NOTICES.md. No proxy engine source was reused. Official implementation references are collected in docs/SOURCES.md.
