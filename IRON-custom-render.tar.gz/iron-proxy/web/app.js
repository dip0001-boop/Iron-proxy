const $ = id => document.getElementById(id);
const DEFAULTS = { theme: 'midnight', reduced: matchMedia('(prefers-reduced-motion: reduce)').matches, rememberHistory: true, liveTabs: 3, cache: true, search: 'brave' };
const readLocal = (key, fallback) => { try { return JSON.parse(localStorage.getItem(key)) ?? fallback; } catch { return fallback; } };
let settings = { ...DEFAULTS, ...readLocal('iron-settings', {}) };
let bookmarks = readLocal('iron-bookmarks', []);
let historyItems = readLocal('iron-history', []);
let downloads = [];
let csrf = ''; let providers = []; let tabs = []; let activeId = ''; let toastTimer;
const active = () => tabs.find(t => t.id === activeId);
const el = (tag, className, text) => { const node = document.createElement(tag); if (className) node.className = className; if (text !== undefined) node.textContent = text; return node; };
function toast(message) { $('toast').textContent = message; $('toast').classList.remove('hidden'); clearTimeout(toastTimer); toastTimer = setTimeout(() => $('toast').classList.add('hidden'), 4500); }
function attempt(fn) { return (...args) => Promise.resolve().then(() => fn(...args)).catch(e => toast(e.message)); }
async function api(url, method = 'GET', data) {
  const response = await fetch(url, { method, credentials: 'same-origin', headers: { ...(data !== undefined ? { 'content-type': 'application/json' } : {}), ...(csrf && method !== 'GET' ? { 'x-iron-csrf': csrf } : {}) }, body: data === undefined ? undefined : JSON.stringify(data) });
  const body = await response.json();
  if (!response.ok) throw new Error(body.message || body.error || 'Request failed.');
  return body;
}
function saveSettings() { localStorage.setItem('iron-settings', JSON.stringify(settings)); applySettings(); }
function applySettings() { document.body.dataset.theme = settings.theme; document.body.dataset.reduced = String(settings.reduced); }
applySettings();
$('home-date').textContent = new Intl.DateTimeFormat(undefined, { weekday: 'short', month: 'short', day: 'numeric' }).format(new Date()).toUpperCase();
const shortcuts = [ ['W', 'Wikipedia', 'The free encyclopedia', 'https://en.wikipedia.org/'], ['M', 'MDN Web Docs', 'Learn how the web works', 'https://developer.mozilla.org/'], ['N', 'NASA', 'Explore something bigger', 'https://www.nasa.gov/'], ['E', 'Example', 'A lightweight first page', 'https://example.com/'] ];
for (const [symbol, title, subtitle, url] of shortcuts) { const button = el('button', 'shortcut'); const text = el('span'); text.append(el('strong', '', title), el('small', '', subtitle)); button.append(el('span', 'shortcut-symbol', symbol), text); button.onclick = attempt(() => navigate(active(), url)); $('shortcuts').append(button); }
function recordHistory(tab) {
  if (tab.private || !settings.rememberHistory || !tab.url) return;
  historyItems = [{ url: tab.url, title: tab.title, date: new Date().toISOString() }, ...historyItems.filter(item => item.url !== tab.url)].slice(0, 300);
  localStorage.setItem('iron-history', JSON.stringify(historyItems));
}
function pushNavigation(tab, url, replace = false) {
  if (replace && tab.cursor >= 0) tab.stack[tab.cursor] = url;
  else if (tab.stack[tab.cursor] !== url) { tab.stack = tab.stack.slice(0, tab.cursor + 1); tab.stack.push(url); tab.cursor = tab.stack.length - 1; }
  tab.url = url;
}
function renderTabs() {
  $('tabs').replaceChildren();
  for (const tab of tabs) {
    const wrapper = el('div', `tab${tab.id === activeId ? ' active' : ''}${tab.private ? ' is-private' : ''}${tab.loading ? ' busy' : ''}`);
    const select = el('button', 'tab-select', tab.title || 'New tab'); select.setAttribute('role', 'tab'); select.setAttribute('aria-selected', String(tab.id === activeId)); select.title = tab.title || 'New tab'; select.onclick = attempt(() => activate(tab));
    const close = el('button', 'tab-close', '×'); close.setAttribute('aria-label', `Close ${tab.title || 'New tab'}`); close.onclick = attempt(() => closeTab(tab)); wrapper.append(select, close); $('tabs').append(wrapper);
  }
  const tab = active(); if (!tab) return;
  $('back').disabled = tab.cursor <= 0; $('forward').disabled = tab.cursor >= tab.stack.length - 1;
  if (document.activeElement !== $('address')) $('address').value = tab.view === 'home' ? '' : tab.view === 'search' ? tab.query : tab.url;
  $('bookmark').textContent = bookmarks.some(b => b.url === tab.url) ? '★' : '☆'; $('bookmark').disabled = tab.private || !tab.url || tab.view !== 'web';
  $('loading-line').classList.toggle('active', tab.loading);
  $('session-status').textContent = tab.private ? 'PRIVATE · HISTORY NOT SAVED' : 'ISOLATED TAB SESSION';
  $('status').textContent = tab.loading ? 'Loading…' : tab.warning || (tab.view === 'web' ? 'Isolated view · IRON CORE' : 'Ready');
}
function renderView() {
  const tab = active(); if (!tab) return;
  $('start-page').classList.toggle('hidden', tab.view !== 'home'); $('search-page').classList.toggle('hidden', tab.view !== 'search'); $('frames').classList.toggle('hidden', tab.view !== 'web');
  for (const t of tabs) t.frame?.classList.toggle('hidden', t.id !== activeId);
  if (tab.view === 'search') renderResults(tab);
  renderTabs();
}
function frameFor(tab) {
  if (tab.frame) return tab.frame;
  const frame = el('iframe', 'browser-frame'); frame.title = 'Isolated website content';
  frame.setAttribute('sandbox', 'allow-scripts allow-forms allow-downloads'); frame.referrerPolicy = 'no-referrer';
  frame.setAttribute('allow', "camera 'none'; microphone 'none'; geolocation 'none'; payment 'none'; usb 'none'; serial 'none'");
  frame.onload = () => { clearTimeout(tab.timer); tab.loading = false; if (activeId === tab.id) renderTabs(); };
  frame.classList.toggle('hidden', tab.id !== activeId); $('frames').append(frame); tab.frame = frame; return frame;
}
async function activate(tab) {
  activeId = tab.id; tab.lastActive = Date.now();
  if (tab.view === 'web' && !tab.frame) await navigate(tab, tab.url, { replace: true, preserve: true });
  renderView(); await trimTabs();
}
async function newTab(privateMode = false, url) {
  const remote = await api('/api/tabs', 'POST', { private: privateMode });
  const tab = { ...remote, view: 'home', title: 'New tab', url: '', stack: [], cursor: -1, serial: 0, lastActive: Date.now() };
  tabs.push(tab); await activate(tab); await api(`/api/tabs/${tab.id}/settings`, 'POST', { cacheEnabled: settings.cache });
  if (url) await navigate(tab, url); else $('address').focus(); return tab;
}
async function closeTab(tab) {
  clearTimeout(tab.timer); tab.serial++; tab.frame?.remove();
  await api(`/api/tabs/${tab.id}`, 'DELETE'); tabs = tabs.filter(t => t !== tab);
  if (!tabs.length) return newTab(); if (activeId === tab.id) await activate(tabs.at(-1)); else renderTabs();
}
async function trimTabs() {
  const live = tabs.filter(t => t.frame).sort((a, b) => b.lastActive - a.lastActive);
  for (const tab of live.slice(Math.max(1, Number(settings.liveTabs)))) {
    if (tab.id === activeId) continue;
    tab.frame.remove(); tab.frame = null; tab.loading = false; clearTimeout(tab.timer);
    await api(`/api/tabs/${tab.id}/suspend`, 'POST', {});
  }
}
async function navigate(tab, input, options = {}) {
  if (!tab) return;
  const url = new URL(input); if (!['http:', 'https:'].includes(url.protocol)) throw new Error('Only HTTP and HTTPS URLs are supported.');
  const serial = ++tab.serial; tab.loading = true; tab.warning = ''; tab.view = 'web';
  if (!options.preserve) pushNavigation(tab, url.href, options.replace); else tab.url = url.href;
  tab.title = url.hostname; renderView();
  try {
    const result = await api(`/api/tabs/${tab.id}/navigate`, 'POST', { url: url.href, sequence: serial });
    if (serial !== tab.serial || !tabs.includes(tab)) return;
    const frame = frameFor(tab); frame.src = result.src + url.hash; tab.lastActive = Date.now();
    clearTimeout(tab.timer); tab.timer = setTimeout(() => { tab.loading = false; tab.warning = 'Page load timed out. Reload to try again.'; if (tab.id === activeId) renderTabs(); }, 35_000);
    await trimTabs();
  } catch (error) { if (serial !== tab.serial || !tabs.includes(tab)) return; tab.loading = false; tab.warning = error.message; renderView(); throw error; }
}
async function traverse(delta) {
  const tab = active(); const next = tab.cursor + delta; if (next < 0 || next >= tab.stack.length) return;
  tab.cursor = next; await navigate(tab, tab.stack[next], { preserve: true });
}
function parseInput(value) {
  const text = value.trim(); if (!text) return null;
  if (/^https?:\/\//i.test(text)) return { url: text };
  if (/^[a-z][a-z\d+.-]*:/i.test(text)) throw new Error('Enter an HTTP(S) URL or a search query.');
  if (!/\s/.test(text) && /^(?:[a-z\d-]+\.)+[a-z\d-]+(?::\d+)?(?:[/?#].*)?$/i.test(text)) return { url: `https://${text}` };
  return { query: text };
}
async function omnibox(value) { const input = parseInput(value); if (!input) return; if (input.url) return navigate(active(), input.url); return search(active(), input.query); }
async function search(tab, query) {
  tab.serial++; tab.view = 'search'; tab.query = query; tab.title = query; tab.loading = true; tab.results = []; tab.searchError = ''; renderView();
  const serial = tab.serial;
  tab.frame?.remove(); tab.frame = null; clearTimeout(tab.timer);
  await api(`/api/tabs/${tab.id}/suspend`, 'POST', {});
  try { const data = await api(`/api/search?q=${encodeURIComponent(query)}&provider=${settings.search}`); if (serial === tab.serial) { tab.results = data.results; tab.provider = data.provider; } }
  catch (error) { if (serial === tab.serial) tab.searchError = error.message; }
  if (serial === tab.serial) { tab.loading = false; renderView(); }
}
function renderResults(tab) {
  $('result-title').textContent = tab.query; $('result-provider').textContent = tab.provider || 'WEB SEARCH'; $('result-status').textContent = tab.loading ? 'Searching…' : tab.searchError || `${tab.results?.length || 0} results from ${tab.provider || 'the provider'}`;
  $('results').replaceChildren();
  for (const result of tab.results || []) { const item = el('article', 'result'); const link = el('button', '', result.title); link.onclick = attempt(() => navigate(tab, result.url)); item.append(el('small', '', result.url), link, el('p', '', result.description)); $('results').append(item); }
}
async function home() { const tab = active(); tab.serial++; tab.view = 'home'; tab.title = 'New tab'; tab.loading = false; clearTimeout(tab.timer); tab.frame?.remove(); tab.frame = null; await api(`/api/tabs/${tab.id}/suspend`, 'POST', {}); renderView(); }
function panel(title) { $('panel-title').textContent = title; $('panel-body').replaceChildren(); if (!$('panel').open) $('panel').showModal(); return $('panel-body'); }
function button(label, callback, className = 'action') { const node = el('button', className, label); node.onclick = attempt(callback); return node; }
function showList(kind) {
  const names = { bookmarks: 'Bookmarks', history: 'History', downloads: 'Downloads' }; const body = panel(names[kind]);
  const items = kind === 'bookmarks' ? bookmarks : kind === 'history' ? historyItems : downloads;
  if (!items.length) body.append(el('p', 'panel-note', `No ${names[kind].toLowerCase()} yet.`));
  if (kind === 'downloads') body.append(el('p', 'panel-note', 'These are download requests. Your host browser controls saving and completion.'));
  for (const item of items) {
    const row = el('div', 'list-row'); const open = button(item.title || item.url, async () => { $('panel').close(); await navigate(active(), item.url); }, ''); open.append(el('small', '', item.url)); row.append(open);
    if (kind === 'bookmarks') row.append(button('Remove', () => { bookmarks = bookmarks.filter(x => x !== item); localStorage.setItem('iron-bookmarks', JSON.stringify(bookmarks)); showList(kind); renderTabs(); }));
    body.append(row);
  }
  if (kind === 'history') body.append(button('Clear browsing history', () => { historyItems = []; localStorage.removeItem('iron-history'); showList(kind); }));
}
function showSettings() {
  const body = panel('Settings');
  function group(title) { const node = el('section', 'panel-group'); node.append(el('h3', '', title)); body.append(node); return node; }
  function select(groupNode, label, key, options) {
    const row = el('label', 'setting'); row.append(el('span', '', label)); const control = el('select');
    for (const [value, title] of options) { const option = el('option', '', title); option.value = value; control.append(option); } control.value = settings[key];
    control.onchange = attempt(async () => { settings[key] = key === 'liveTabs' ? Number(control.value) : control.value; saveSettings(); await trimTabs(); }); row.append(control); groupNode.append(row);
  }
  function toggle(groupNode, label, key) {
    const row = el('label', 'setting'); row.append(el('span', '', label)); const control = el('input'); control.type = 'checkbox'; control.checked = settings[key];
    control.onchange = attempt(async () => { settings[key] = control.checked; saveSettings(); if (key === 'cache') for (const tab of tabs) await api(`/api/tabs/${tab.id}/settings`, 'POST', { cacheEnabled: settings.cache }); }); row.append(control); groupNode.append(row);
  }
  const appearance = group('Appearance'); select(appearance, 'Palette', 'theme', [['midnight', 'Midnight black'], ['graphite', 'Metallic graphite']]); toggle(appearance, 'Reduce motion', 'reduced');
  const searching = group('Search provider'); select(searching, 'Search API', 'search', [['brave', providers.includes('brave') ? 'Brave Search API' : 'Brave · API key needed']]); searching.append(el('p', 'panel-note', providers.length ? 'Real provider results open in this tab. API credentials remain on the server.' : 'Add BRAVE_SEARCH_API_KEY to your server environment. Until then, enter a website URL directly.'));
  const privacy = group('Privacy'); toggle(privacy, 'Save regular browsing history on this device', 'rememberHistory'); privacy.append(button('Clear saved history', () => { historyItems = []; localStorage.removeItem('iron-history'); toast('History cleared.'); })); privacy.append(el('p', 'panel-note', 'Private tabs omit local history and bookmarks. They do not hide activity from your network, upstream websites, or the server operator.'));
  const performance = group('Performance & cache'); select(performance, 'Maximum live page frames', 'liveTabs', [['1', '1 · lowest memory'], ['2', '2'], ['3', '3 · balanced'], ['6', '6']]); toggle(performance, 'Cache eligible public resources', 'cache'); performance.append(button('Clear shared public asset cache', async () => { await api('/api/cache/clear', 'POST', {}); toast('Public asset cache cleared.'); })); performance.append(el('p', 'panel-note', 'Suspended pages reload when selected. Unsubmitted form inputs and page JavaScript state are not retained.'));
  const sessions = group('Sessions');
  for (const tab of tabs) { const row = el('div', 'list-row'); row.append(el('span', '', `${tab.private ? 'Private · ' : ''}${tab.title}`)); row.append(button('Clear site data', async () => { await api(`/api/tabs/${tab.id}/clear`, 'POST', {}); tab.frame?.remove(); tab.frame = null; if (tab.view === 'web' && tab.id === activeId) await navigate(tab, tab.url, { preserve: true }); toast('Tab cookies and storage cleared.'); })); sessions.append(row); }
  body.append(button('Open diagnostics', showDiagnostics), button('Compatibility & limitations', showCompatibility));
}
async function showDiagnostics() {
  const body = panel('Diagnostics'); body.append(el('p', 'panel-note', 'Loading process metrics…')); const data = await api('/api/diagnostics'); body.replaceChildren();
  const grid = el('div', 'diagnostic-grid');
  for (const [label, value] of [['Server RSS', `${(data.memory.rss / 1048576).toFixed(1)} MB`], ['Active requests', String(data.activeRequests)], ['Raw asset cache', `${(data.cache.bytes / 1048576).toFixed(2)} MB`], ['Mean rewrite time', `${(data.rewrite.totalMs / (data.rewrite.count || 1)).toFixed(1)} ms`]]) { const card = el('div', 'diagnostic-card'); card.append(el('small', '', label), el('strong', '', value)); grid.append(card); }
  body.append(grid, el('p', 'panel-note', 'These are current server counters, not competitor benchmark results. CPU values are cumulative microseconds. Memory includes the rewrite worker.')); body.append(el('pre', 'diagnostic-json', JSON.stringify(data, null, 2)), button('Refresh', showDiagnostics));
}
function showCompatibility() {
  const body = panel('An honest engineering preview');
  for (const [title, text] of [
    ['Available in this build', 'HTTP(S), redirects, parser-based HTML/CSS/JS transforms, scoped Location rewrites, classic scripts and URL-based ES modules, fetch/XHR, WebSockets, forms, partitioned cookies/storage, tabs, history, bookmarks, and a Brave Search API adapter. See the delivered test report for what was verified.'],
    ['Partial compatibility', 'Dynamic DOM rewrites, import maps, cookies, history, and downloads follow a documented subset of browser behavior. OAuth and bot challenges may reject the changed origin. Downloads are managed by your host browser.'],
    ['Blocked or unsupported', 'Service workers, dedicated/shared workers, eval/new Function, native IndexedDB, DRM, WebRTC, device permissions, external popups, and full native cross-origin behavior. Cross-origin credentialed fetch is intentionally disabled.'],
    ['Security boundary', 'Each document has an opaque sandbox origin. The host browser still provides rendering and sandbox enforcement. This alpha has not had an independent security audit; use it for testing before sensitive account browsing.'],
    ['Performance claims', 'IRON has its own engine and a reproducible benchmark harness. No superiority over Ultraviolet, Rammerhead, or Scramjet has been established.'],
  ]) { body.append(el('h3', '', title), el('p', 'panel-note', text)); }
}
window.addEventListener('message', event => {
  if (event.origin !== 'null' || !event.data?.iron) return;
  const tab = tabs.find(t => t.frame?.contentWindow === event.source && t.channel === event.data.channel); if (!tab) return;
  const data = event.data;
  const safeURL = value => { try { const u = new URL(value); return ['https:', 'http:'].includes(u.protocol) && !u.username && !u.password ? u.href : null; } catch { return null; } };
  if (data.type === 'navigate' && safeURL(data.url)) attempt(() => navigate(tab, data.url, { replace: !!data.replace }))();
  if (data.type === 'open' && safeURL(data.url)) attempt(() => newTab(tab.private, data.url))();
  if (['ready', 'history'].includes(data.type) && safeURL(data.url)) { pushNavigation(tab, data.url, data.type === 'ready' ? !tab.contentNavigation : !!data.replace); tab.contentNavigation = false; tab.title = String(data.title || new URL(data.url).hostname).slice(0, 180); tab.loading = false; recordHistory(tab); if (tab.id === activeId) renderTabs(); }
  if (data.type === 'title') { tab.title = String(data.title || tab.title).slice(0, 180); renderTabs(); }
  if (data.type === 'loaded') { tab.loading = false; clearTimeout(tab.timer); if (tab.id === activeId) renderTabs(); }
  if (data.type === 'loading') { tab.loading = true; tab.contentNavigation = true; if (tab.id === activeId) renderTabs(); }
  if (data.type === 'warning') { tab.warning = String(data.message || '').slice(0, 150); if (tab.id === activeId) renderTabs(); }
  if (data.type === 'reload') attempt(() => navigate(tab, tab.url, { preserve: true }))();
  if (data.type === 'back' && tab.id === activeId) attempt(() => traverse(-1))();
  if (data.type === 'forward' && tab.id === activeId) attempt(() => traverse(1))();
  if (data.type === 'go' && tab.id === activeId && Number.isInteger(data.delta)) attempt(() => data.delta ? traverse(data.delta) : navigate(tab, tab.url, { preserve: true }))();
  if (data.type === 'download' && safeURL(data.url) && !tab.private) downloads.unshift({ title: data.title || 'Download requested', url: data.url });
});
async function boot(data) {
  csrf = data.csrf; providers = data.searchProviders; $('password').value = ''; $('login').classList.add('hidden'); $('browser').classList.remove('hidden');
  $('search-caption').textContent = providers.length ? 'Web search by Brave Search API' : 'Enter a URL · search API not configured';
  const existing = await api('/api/tabs');
  for (const old of existing.tabs) await api(`/api/tabs/${old.id}`, 'DELETE');
  tabs = []; await newTab();
}
$('login-form').onsubmit = async event => { event.preventDefault(); const submit = event.currentTarget.querySelector('button'); submit.disabled = true; $('login-error').textContent = ''; try { await boot(await api('/api/login', 'POST', { password: $('password').value })); } catch (e) { $('login-error').textContent = e.message; } finally { submit.disabled = false; } };
$('omnibox').onsubmit = event => { event.preventDefault(); const value = $('address').value; $('address').blur(); attempt(() => omnibox(value))(); };
$('home-search').onsubmit = event => { event.preventDefault(); attempt(() => omnibox($('home-query').value))(); };
$('new-tab').onclick = attempt(() => newTab()); $('new-private').onclick = attempt(() => newTab(true));
$('back').onclick = attempt(() => traverse(-1)); $('forward').onclick = attempt(() => traverse(1)); $('reload').onclick = attempt(() => active().view === 'web' ? navigate(active(), active().url, { preserve: true }) : active().view === 'search' ? search(active(), active().query) : home());
for (const id of ['home', 'rail-home', 'brand-home']) $(id).onclick = event => { event.preventDefault(); attempt(home)(); };
$('settings').onclick = showSettings; $('show-bookmarks').onclick = () => showList('bookmarks'); $('show-history').onclick = () => showList('history'); $('show-downloads').onclick = () => showList('downloads'); $('show-diagnostics').onclick = attempt(showDiagnostics); $('compatibility').onclick = showCompatibility;
$('close-panel').onclick = () => $('panel').close(); $('panel').addEventListener('click', event => { if (event.target === $('panel')) { const rect = $('panel').getBoundingClientRect(); if (event.clientX < rect.left || event.clientX > rect.right || event.clientY < rect.top || event.clientY > rect.bottom) $('panel').close(); } });
$('bookmark').onclick = () => { const tab = active(); if (!tab.url || tab.private) return; if (bookmarks.some(b => b.url === tab.url)) bookmarks = bookmarks.filter(b => b.url !== tab.url); else bookmarks.push({ title: tab.title, url: tab.url }); localStorage.setItem('iron-bookmarks', JSON.stringify(bookmarks)); renderTabs(); };
$('logout').onclick = attempt(async () => { await api('/api/logout', 'POST', {}); for (const tab of tabs) { tab.frame?.remove(); clearTimeout(tab.timer); } tabs = []; csrf = ''; $('browser').classList.add('hidden'); $('login').classList.remove('hidden'); });
document.addEventListener('keydown', event => {
  if (!event.altKey || event.ctrlKey || event.metaKey) return;
  const key = event.key.toLowerCase(); let action;
  if (key === 'l') action = () => { $('address').focus(); $('address').select(); };
  if (key === 't') action = () => newTab(event.shiftKey);
  if (key === 'w') action = () => closeTab(active());
  if (key === 'r') action = () => $('reload').click();
  if (key === 'arrowleft') action = () => traverse(-1);
  if (key === 'arrowright') action = () => traverse(1);
  if (/^[1-9]$/.test(key) && tabs[Number(key) - 1]) action = () => activate(tabs[Number(key) - 1]);
  if (action && csrf) { event.preventDefault(); attempt(action)(); }
});
api('/api/me').then(boot).catch(() => {});
