(() => {
  'use strict';
  const element = document.getElementById('iron-config');
  if (!element) return;
  const cfg = JSON.parse(element.textContent); element.remove();
  const nativeFetch = window.fetch.bind(window);
  const NativeRequest = window.Request;
  const NativeXHR = window.XMLHttpRequest;
  const NativeWebSocket = window.WebSocket;
  const nativeSetAttribute = Element.prototype.setAttribute;
  const innerHTML = Object.getOwnPropertyDescriptor(Element.prototype, 'innerHTML');
  const nativeAppend = Node.prototype.appendChild;
  const nativeInsert = Node.prototype.insertBefore;
  const nativeReplace = Node.prototype.replaceChild;
  let current = new URL(cfg.url); current.hash = window.location.hash; let pending = Promise.resolve();
  const b64 = value => { let s = ''; for (const b of new TextEncoder().encode(value)) s += String.fromCharCode(b); return btoa(s).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, ''); };
  function original(value) {
    try {
      const url = new URL(value, cfg.proxyOrigin);
      if (url.origin === cfg.proxyOrigin && url.pathname.startsWith('/p/')) {
        const encoded = url.pathname.split('/')[3];
        const bytes = Uint8Array.from(atob(encoded.replace(/-/g, '+').replace(/_/g, '/')), c => c.charCodeAt(0));
        return new TextDecoder().decode(bytes) + url.hash;
      }
    } catch {}
    return value;
  }
  function route(value, base = current.href) {
    const raw = String(value);
    if (/^(data:|blob:|mailto:|tel:|#)/i.test(raw)) return raw;
    const url = new URL(original(raw), base);
    if (!['http:', 'https:'].includes(url.protocol)) return 'about:blank';
    const hash = url.hash; url.hash = '';
    return `${cfg.proxyOrigin}/p/${cfg.cap}/${b64(url.href)}${hash}`;
  }
  function tell(type, extra = {}) { parent.postMessage({ iron: true, channel: cfg.channel, type, ...extra }, cfg.proxyOrigin); }
  function navigate(value, replace = false) {
    const url = new URL(original(String(value)), current.href);
    if (!['http:', 'https:'].includes(url.protocol)) throw new TypeError('IRON only navigates HTTP(S) URLs.');
    if (parent !== window && parent === top) tell('navigate', { url: url.href, replace });
    else if (replace) window.location.replace(route(url.href)); else window.location.assign(route(url.href));
  }
  function persist(data) {
    pending = pending.catch(() => {}).then(async () => {
      const response = await nativeFetch(`${cfg.proxyOrigin}/v/${cfg.cap}`, { method: 'POST', mode: 'cors', credentials: 'omit', headers: { 'content-type': 'application/json' }, body: JSON.stringify(data) });
      if (!response.ok) throw new Error('Cookie/storage update rejected.');
      return response.json();
    });
    pending.catch(error => tell('warning', { message: error.message }));
    return pending;
  }

  const locationView = {};
  for (const key of ['href', 'protocol', 'host', 'hostname', 'port', 'pathname', 'search', 'hash']) {
    Object.defineProperty(locationView, key, { enumerable: true, get: () => current[key], set: value => {
      const next = new URL(current.href); next[key] = value;
      if (key === 'hash') { current = next; window.location.hash = value; tell('history', { url: current.href, title: document.title }); }
      else navigate(next.href);
    } });
  }
  Object.defineProperty(locationView, 'origin', { get: () => current.origin });
  Object.assign(locationView, { assign: value => navigate(value), replace: value => navigate(value, true), reload: () => tell('reload'), toString: () => current.href });
  const iron = { moduleURL: (value, base) => /^[./]|^[a-zA-Z][\w+.-]*:/.test(String(value)) ? route(value, base) : value };
  Object.defineProperty(iron, 'location', { get: () => locationView, set: value => navigate(value) });
  Object.defineProperty(window, '__iron', { value: iron });
  for (const key of ['URL', 'documentURI', 'baseURI']) {
    try { Object.defineProperty(document, key, { get: () => key === 'baseURI' ? cfg.base : current.href }); } catch {}
  }
  window.Request = class IronRequest extends NativeRequest {
    constructor(input, init) { super(input instanceof NativeRequest ? input : new URL(original(String(input)), current.href), init); }
  };

  window.fetch = async function (input, init) {
    let request;
    if (input instanceof NativeRequest) request = new NativeRequest(input, init);
    else request = new NativeRequest(new URL(original(String(input)), current.href), init);
    const target = original(request.url);
    const headers = new Headers(request.headers); headers.set('x-iron-credentials', request.credentials === 'omit' ? 'omit' : 'same-origin');
    const body = ['GET', 'HEAD'].includes(request.method) ? undefined : await request.arrayBuffer();
    await pending.catch(() => {});
    const response = await nativeFetch(route(target), { method: request.method, headers, body, signal: request.signal, mode: 'cors', credentials: 'omit', redirect: 'follow', cache: 'no-store' });
    try { Object.defineProperty(response, 'url', { value: response.headers.get('x-iron-upstream-url') || target }); } catch {}
    return response;
  };
  window.XMLHttpRequest = class IronXHR extends NativeXHR {
    open(method, url, async = true, ...rest) {
      if (async === false) throw new DOMException('Synchronous XHR is not supported by IRON.', 'NotSupportedError');
      this.ironURL = new URL(original(String(url)), current.href).href;
      return super.open(method, route(this.ironURL), true, ...rest);
    }
    send(body) { pending.catch(() => {}).then(() => super.send(body)); }
    get responseURL() { return original(super.responseURL) || this.ironURL || ''; }
  };
  window.WebSocket = class IronWebSocket extends NativeWebSocket {
    constructor(value, protocols) {
      const url = new URL(String(value), current.href.replace(/^http/, 'ws'));
      if (!['ws:', 'wss:'].includes(url.protocol)) throw new SyntaxError('Invalid WebSocket URL');
      super(`${cfg.proxyOrigin.replace(/^http/, 'ws')}/ws/${cfg.cap}/${b64(url.href)}`, protocols);
      this.ironURL = url.href;
    }
    get url() { return this.ironURL || super.url; }
  };
  window.open = (url) => { if (url) tell('open', { url: new URL(original(String(url)), current.href).href }); return null; };
  for (const name of ['Worker', 'SharedWorker']) window[name] = class { constructor() { throw new DOMException(`${name} is not supported in IRON 0.1.`, 'NotSupportedError'); } };
  let historyState = null;
  for (const method of ['pushState', 'replaceState']) history[method] = (value, _unused, url) => {
    const next = new URL(url == null ? current.href : original(String(url)), current.href);
    if (next.origin !== current.origin) throw new DOMException('History cannot change upstream origin.', 'SecurityError');
    historyState = structuredClone(value); current = next;
    tell('history', { url: next.href, title: document.title, replace: method === 'replaceState' });
  };
  try { Object.defineProperty(history, 'state', { get: () => historyState }); } catch {}
  history.back = () => tell('back'); history.forward = () => tell('forward');
  history.go = delta => tell('go', { delta: Number(delta) || 0 });

  let cookies = cfg.state?.cookies || [];
  function cookieVisible(cookie) {
    const host = current.hostname;
    return (!cookie.expires || cookie.expires > Date.now()) && (!cookie.secure || current.protocol === 'https:') && (cookie.hostOnly ? host === cookie.domain : host === cookie.domain || host.endsWith('.' + cookie.domain)) && (current.pathname === cookie.path || current.pathname.startsWith(cookie.path.endsWith('/') ? cookie.path : cookie.path + '/'));
  }
  Object.defineProperty(document, 'cookie', {
    configurable: false,
    get: () => cookies.filter(cookieVisible).sort((a, b) => b.path.length - a.path.length).map(c => `${c.key}=${c.value}`).join('; '),
    set: value => {
      const str = String(value); const parts = str.split(';'); const i = parts[0].indexOf('='); if (i < 1) return;
      const cookie = { key: parts[0].slice(0, i).trim(), value: parts[0].slice(i + 1).trim(), domain: current.hostname, hostOnly: true, path: current.pathname.slice(0, current.pathname.lastIndexOf('/') + 1) || '/', expires: null, secure: false };
      for (const part of parts.slice(1)) {
        const [k, ...v] = part.trim().split('='); const val = v.join('=');
        if (k.toLowerCase() === 'domain') { cookie.domain = val.replace(/^\./, '').toLowerCase(); cookie.hostOnly = false; }
        if (k.toLowerCase() === 'path' && val.startsWith('/')) cookie.path = val;
        if (k.toLowerCase() === 'expires') cookie.expires = Date.parse(val);
        if (k.toLowerCase() === 'max-age') cookie.expires = Date.now() + Number(val) * 1000;
        if (k.toLowerCase() === 'secure') cookie.secure = true;
        if (k.toLowerCase() === 'httponly') return;
      }
      if (current.hostname !== cookie.domain && !current.hostname.endsWith('.' + cookie.domain)) return;
      cookies = cookies.filter(c => !(c.key === cookie.key && c.domain === cookie.domain && c.path === cookie.path)); cookies.push(cookie);
      persist({ type: 'cookie', value: str, url: current.href }).then(data => { cookies = data.cookies; }).catch(() => {});
    },
  });
  for (const [name, area] of [['localStorage', 'local'], ['sessionStorage', 'session']]) {
    let values = Object.assign(Object.create(null), cfg.state?.[area] || {});
    const commit = () => persist({ type: 'storage', area, values: { ...values } });
    const methods = {
      getItem: key => Object.hasOwn(values, String(key)) ? values[String(key)] : null,
      setItem: (key, value) => {
        const next = { ...values, [String(key)]: String(value) };
        if (new TextEncoder().encode(JSON.stringify(next)).length > cfg.storageLimit) throw new DOMException('Storage quota exceeded.', 'QuotaExceededError');
        values[String(key)] = String(value); commit();
      },
      removeItem: key => { delete values[String(key)]; commit(); }, clear: () => { values = Object.create(null); commit(); },
      key: i => Object.keys(values)[Number(i)] ?? null,
    };
    const storage = new Proxy(Object.create(null), {
      get: (_target, key) => key === 'length' ? Object.keys(values).length : Object.hasOwn(methods, key) ? methods[key] : values[key],
      set: (_target, key, value) => { methods.setItem(key, value); return true; },
      deleteProperty: (_target, key) => { methods.removeItem(key); return true; },
      ownKeys: () => Object.keys(values), getOwnPropertyDescriptor: (_target, key) => Object.hasOwn(values, key) ? { enumerable: true, configurable: true, value: values[key], writable: true } : undefined,
    });
    Object.defineProperty(window, name, { value: storage });
  }

  const attributes = new Set(['src', 'href', 'action', 'formaction', 'poster', 'data', 'background', 'xlink:href']);
  function srcset(value) {
    let i = 0; const output = [];
    while (i < value.length) {
      while (i < value.length && /[\s,]/.test(value[i])) i++;
      const start = i; while (i < value.length && !/\s/.test(value[i])) i++;
      let url = value.slice(start, i); if (!url) break;
      if (url.endsWith(',')) { output.push(route(url.replace(/,+$/, ''))); continue; }
      const desc = i; let depth = 0;
      while (i < value.length) { if (value[i] === '(') depth++; if (value[i] === ')') depth--; if (value[i] === ',' && !depth) break; i++; }
      output.push(route(url) + value.slice(desc, i)); i++;
    }
    return output.join(', ');
  }
  Element.prototype.setAttribute = function (name, value) {
    const key = String(name).toLowerCase();
    if (attributes.has(key)) value = route(value, cfg.base);
    if (key === 'srcset') value = srcset(String(value));
    if (key === 'target' || key === 'formtarget') value = '_self';
    if (key === 'srcdoc') throw new DOMException('srcdoc is unavailable in IRON.', 'NotSupportedError');
    return nativeSetAttribute.call(this, name, value);
  };
  for (const [constructor, keys] of [
    [HTMLAnchorElement, ['href']], [HTMLAreaElement, ['href']], [HTMLImageElement, ['src', 'srcset']],
    [HTMLScriptElement, ['src']], [HTMLLinkElement, ['href']], [HTMLIFrameElement, ['src']],
    [HTMLFormElement, ['action']], [HTMLInputElement, ['src', 'formAction']], [HTMLButtonElement, ['formAction']],
    [HTMLMediaElement, ['src']], [HTMLVideoElement, ['poster']], [HTMLSourceElement, ['src', 'srcset']],
  ]) for (const key of keys) {
    const descriptor = Object.getOwnPropertyDescriptor(constructor.prototype, key);
    if (!descriptor?.set || !descriptor.configurable) continue;
    Object.defineProperty(constructor.prototype, key, { ...descriptor,
      get() { const value = descriptor.get.call(this); return key === 'srcset' ? value : original(value); },
      set(value) { descriptor.set.call(this, key === 'srcset' ? srcset(String(value)) : route(value, cfg.base)); },
    });
  }
  function rewriteTree(root) {
    const nodes = root.nodeType === Node.ELEMENT_NODE ? [root, ...root.querySelectorAll('*')] : root.querySelectorAll ? [...root.querySelectorAll('*')] : [];
    for (const node of nodes) for (const attr of [...node.attributes]) {
      if (attributes.has(attr.name)) nativeSetAttribute.call(node, attr.name, route(attr.value, cfg.base));
      else if (attr.name === 'srcset') nativeSetAttribute.call(node, attr.name, srcset(attr.value));
      else if (attr.name === 'target') nativeSetAttribute.call(node, 'target', '_self');
      else if (attr.name === 'srcdoc') node.removeAttribute('srcdoc');
    }
    return root;
  }
  function rewriteFragment(value) { const template = document.createElement('template'); innerHTML.set.call(template, String(value)); rewriteTree(template.content); return innerHTML.get.call(template); }
  Object.defineProperty(Element.prototype, 'innerHTML', { ...innerHTML, set(value) { innerHTML.set.call(this, rewriteFragment(value)); } });
  const adjacent = Element.prototype.insertAdjacentHTML;
  Element.prototype.insertAdjacentHTML = function (position, value) { return adjacent.call(this, position, rewriteFragment(value)); };
  Node.prototype.appendChild = function (node) { return nativeAppend.call(this, rewriteTree(node)); };
  Node.prototype.insertBefore = function (node, reference) { return nativeInsert.call(this, rewriteTree(node), reference); };
  Node.prototype.replaceChild = function (node, old) { return nativeReplace.call(this, rewriteTree(node), old); };
  document.addEventListener('click', event => {
    const anchor = event.target.closest?.('a[href]');
    if (!anchor || event.defaultPrevented || event.button !== 0) return;
    if (anchor.hasAttribute('download')) { tell('download', { url: original(anchor.href), title: anchor.getAttribute('download') || 'Download requested' }); return; }
    const target = original(anchor.getAttribute('href'));
    if (/^(mailto:|tel:|javascript:)/i.test(target)) { event.preventDefault(); return; }
    event.preventDefault();
    if (target.startsWith('#')) { locationView.hash = target; return; }
    if (event.ctrlKey || event.metaKey) tell('open', { url: new URL(target, current.href).href }); else navigate(target);
  });
  document.addEventListener('submit', event => {
    const form = event.target;
    if (form instanceof HTMLFormElement) { form.action = form.getAttribute('action') || current.href; form.target = '_self'; tell('loading'); }
  }, true);
  function ready() { tell('ready', { url: current.href, title: document.title || current.hostname }); }
  document.addEventListener('DOMContentLoaded', ready, { once: true });
  window.addEventListener('load', () => tell('loaded', { url: current.href }));
  window.addEventListener('hashchange', () => { current.hash = window.location.hash; });
  new MutationObserver(() => tell('title', { title: document.title })).observe(document.querySelector('head') || document.documentElement, { childList: true, subtree: true, characterData: true });
})();
