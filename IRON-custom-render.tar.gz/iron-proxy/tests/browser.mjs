import assert from 'node:assert/strict';
import { chromium } from 'playwright';
import { readFile, writeFile, mkdir } from 'node:fs/promises';
import { startFixture, PASSWORD } from './fixture.js';

const fixture = await startFixture();
const launch = process.env.IRON_BROWSER_LAUNCH_FILE ? JSON.parse(await readFile(process.env.IRON_BROWSER_LAUNCH_FILE, 'utf8')) : { ...(process.env.CHROMIUM_EXECUTABLE_PATH ? { executablePath: process.env.CHROMIUM_EXECUTABLE_PATH } : {}), args: ['--no-sandbox'] };
if (launch.args?.some(x => /disable-web-security|disable-site-isolation|single-process/.test(x))) throw new Error('Browser tests require web security and site isolation.');
let browser; const results = []; const errors = [];
async function check(name, fn) { const start = performance.now(); try { await fn(); results.push({ name, pass: true, ms: performance.now() - start }); console.log('PASS', name); } catch (error) { results.push({ name, pass: false, error: error.message }); console.error('FAIL', name, error.message); throw error; } }
try {
  browser = await chromium.launch({ headless: true, ...launch });
  const context = await browser.newContext({ viewport: { width: 1440, height: 960 }, acceptDownloads: true });
  const page = await context.newPage(); page.on('pageerror', error => errors.push(error.message));
  const blockedExternal = [];
  await page.route('**/*', route => { const url = route.request().url(); if (url.startsWith(fixture.origin) || url.startsWith('data:') || url.startsWith('blob:')) return route.continue(); blockedExternal.push(url); return route.abort(); });
  await check('Login and functional browser home', async () => {
    await page.goto(fixture.origin); await page.locator('#password').fill(PASSWORD); await page.locator('#login-form button[type=submit]').click(); await page.locator('#browser').waitFor({ state: 'visible' }); await page.locator('.tab-select').waitFor(); assert.equal(await page.locator('.tab').count(), 1);
  });
  await mkdir('artifacts', { recursive: true });
  await page.screenshot({ path: 'artifacts/browser-home.png', fullPage: true });
  async function go(url) { await page.locator('#address').fill(url); await page.locator('#address').press('Enter'); }
  const contentFrame = async () => (await page.$('.browser-frame:not(.hidden)')).contentFrame();
  await check('HTML, stylesheet, inline and external scripts, modules and dynamic imports', async () => {
    await go(fixture.upstream + '/page'); await page.frameLocator('.browser-frame:not(.hidden)').locator('#styled').waitFor();
    const frame = await contentFrame();
    await frame.waitForFunction(() => document.body.dataset.dynamic === 'dynamic-ok');
    const actual = await frame.evaluate(() => ({ ...document.body.dataset, color: getComputedStyle(document.getElementById('styled')).color }));
    assert.equal(actual.inline, 'inline-ok'); assert.equal(actual.external, 'external-ok'); assert.equal(actual.module, 'module-ok'); assert.equal(actual.dynamic, 'dynamic-ok'); assert.equal(actual.location, fixture.upstream + '/page'); assert.equal(actual.meta, fixture.upstream + '/module.js'); assert.equal(actual.color, 'rgb(1, 101, 201)');
  });
  await check('Runtime fetch, XHR, cookies, storage, WebSocket and dynamic image', async () => {
    const frame = await contentFrame(); await frame.waitForFunction(() => document.body.dataset.fetch === 'fetch-ok' && document.body.dataset.ws === 'echo-me' && document.body.dataset.xhr === 'xhr-ok');
    const data = await frame.evaluate(() => ({ local: localStorage.getItem('key'), session: sessionStorage.getItem('session'), image: document.querySelector('#dynamic-image').complete && document.querySelector('#dynamic-image').naturalWidth, cookie: document.cookie }));
    assert.equal(data.local, 'alpha-value'); assert.equal(data.session, 'alpha-session'); assert.equal(data.image, 1); assert.ok(data.cookie.includes('script=yes'));
  });
  await check('Native parent access and upstream cross-origin reads are blocked', async () => { const frame = await contentFrame(); await frame.waitForFunction(() => document.body.dataset.corsBlocked === '403'); assert.equal(await frame.evaluate(() => document.body.dataset.isolation), 'blocked'); const result = await frame.evaluate(async () => { try { const r = await fetch('/echo'); return r.status; } catch { return 'failed'; } }); assert.equal(result, 200); });
  await check('Link navigation, back and forward are coordinated by the shell', async () => {
    await page.frameLocator('.browser-frame:not(.hidden)').locator('#next').click(); await page.frameLocator('.browser-frame:not(.hidden)').locator('#other').waitFor(); await page.waitForFunction(() => document.getElementById('address').value.endsWith('/other'));
    await page.locator('#back').click(); await page.frameLocator('.browser-frame:not(.hidden)').locator('#styled').waitFor(); await page.locator('#forward').click(); await page.frameLocator('.browser-frame:not(.hidden)').locator('#other').waitFor();
  });
  await check('Bookmarks and history use real navigated URLs', async () => { await page.locator('#bookmark').click(); await page.locator('#show-bookmarks').click(); assert.ok((await page.locator('#panel-body').innerText()).includes('/other')); await page.locator('#close-panel').click(); await page.locator('#show-history').click(); assert.ok((await page.locator('#panel-body').innerText()).includes('/page')); await page.locator('#close-panel').click(); });
  await check('Separate tabs do not share cookie or storage state', async () => { await page.locator('#new-tab').click(); await page.waitForFunction(() => document.querySelectorAll('.tab').length === 2); await go(fixture.upstream + '/other'); await page.frameLocator('.browser-frame:not(.hidden)').locator('#other').waitFor(); const frame = await contentFrame(); const data = await frame.evaluate(() => ({ storage: document.body.dataset.storage, cookie: document.cookie })); assert.equal(data.storage, 'empty'); assert.ok(!data.cookie.includes('script=yes')); });
  await check('Private tabs omit history and disable bookmarking', async () => { const before = await page.evaluate(() => localStorage.getItem('iron-history')); await page.locator('#new-private').click(); await page.waitForFunction(() => document.querySelectorAll('.tab').length === 3); await go(fixture.upstream + '/gzip'); await page.frameLocator('.browser-frame:not(.hidden)').locator('h1').waitFor(); assert.equal(await page.locator('#bookmark').isDisabled(), true); assert.equal(await page.evaluate(() => localStorage.getItem('iron-history')), before); });
  await check('POST form submissions load their real response inside the browser', async () => { await go(fixture.upstream + '/page'); await page.frameLocator('.browser-frame:not(.hidden)').locator('#submit').click(); await page.frameLocator('.browser-frame:not(.hidden)').locator('#form-result').waitFor(); assert.equal(await page.frameLocator('.browser-frame:not(.hidden)').locator('#form-result').innerText(), 'message=hello+iron'); });
  await check('Download delivers the expected file to the host browser', async () => { await go(fixture.upstream + '/page'); const downloadEvent = page.waitForEvent('download'); await page.frameLocator('.browser-frame:not(.hidden)').locator('#download').click(); const download = await downloadEvent; assert.equal(download.suggestedFilename(), 'fixture.txt'); const stream = await download.createReadStream(); const chunks = []; for await (const chunk of stream) chunks.push(chunk); assert.equal(Buffer.concat(chunks).toString(), 'IRON fixture download\n'); });
  await check('Low memory setting suspends inactive frames without deleting sessions', async () => { await page.locator('#settings').click(); await page.locator('select').nth(2).selectOption('1'); await page.waitForFunction(() => document.querySelectorAll('.browser-frame').length === 1); await page.locator('#close-panel').click(); await page.locator('.tab-select').first().click(); await page.frameLocator('.browser-frame:not(.hidden)').locator('#other').waitFor(); assert.equal(await page.frameLocator('.browser-frame:not(.hidden)').locator('body').getAttribute('data-storage'), 'alpha-value'); });
  await check('Search without a key reports configuration status without fake results', async () => { await page.locator('#address').fill('best gaming laptops'); await page.locator('#address').press('Enter'); await page.waitForFunction(() => document.getElementById('result-status').textContent.includes('BRAVE_SEARCH_API_KEY')); assert.equal(await page.locator('.result').count(), 0); });
  await check('Diagnostics and session cleanup are functional', async () => { await page.locator('#show-diagnostics').click(); await page.locator('.diagnostic-card').first().waitFor(); assert.ok((await page.locator('#panel-body').innerText()).includes('Server RSS')); await page.locator('#close-panel').click(); await page.locator('.tab-close').last().click(); await page.waitForFunction(() => document.querySelectorAll('.tab').length === 2); });
  await check('Mobile shell fits the viewport and shortcuts work', async () => { await page.setViewportSize({ width: 390, height: 844 }); await page.locator('#home').evaluate(node => node.click()); await page.locator('#start-page').waitFor({ state: 'visible' }); assert.ok(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth)); await page.screenshot({ path: 'artifacts/browser-mobile.png', fullPage: true }); await page.keyboard.press('Alt+l'); assert.equal(await page.locator('#address').evaluate(node => document.activeElement === node), true); });
  await check('All upstream subresources went through IRON and no page script crashed', async () => { assert.deepEqual(blockedExternal, []); assert.deepEqual(errors, []); });
  await context.close();
} catch (error) { console.error(error.stack); process.exitCode = 1; }
finally {
  await writeFile('artifacts/browser-results.json', JSON.stringify({ date: new Date().toISOString(), browser: browser?.version(), results, pageErrors: errors }, null, 2));
  await browser?.close(); await fixture.close();
}
