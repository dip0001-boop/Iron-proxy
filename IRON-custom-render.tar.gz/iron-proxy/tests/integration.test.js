import test, { before, after } from 'node:test';
import assert from 'node:assert/strict';
import { WebSocket } from 'ws';
import { startFixture, signIn } from './fixture.js';
import { encodeURL } from '../src/core.js';
let fixture; let login; let tab; let src; let cap;
before(async () => { fixture = await startFixture(); login = await signIn(fixture); tab = await (await login.call('/api/tabs', 'POST', {})).json(); const nav = await (await login.call(`/api/tabs/${tab.id}/navigate`, 'POST', { url: fixture.upstream + '/page' })).json(); src = nav.src; cap = new URL(src).pathname.split('/')[2]; });
after(async () => fixture?.close());
const resource = url => `${fixture.origin}/p/${cap}/${encodeURL(url)}`;
const navHeaders = { 'sec-fetch-dest': 'iframe', 'sec-fetch-mode': 'navigate' };

test('Health is public but diagnostics, navigation and cache controls require login', async () => { assert.equal((await fetch(fixture.origin + '/health')).status, 200); assert.equal((await fetch(fixture.origin + '/api/diagnostics')).status, 401); });
test('Authenticated control requests reject null origin and missing CSRF', async () => { const response = await fetch(fixture.origin + '/api/tabs', { method: 'POST', headers: { cookie: login.cookie, origin: 'null', 'content-type': 'application/json' }, body: '{}' }); assert.equal(response.status, 403); });
test('Real network transport transforms document and preserves CSP isolation', async () => { const response = await fetch(src, { headers: navHeaders }); const html = await response.text(); assert.equal(response.status, 200); assert.ok(html.includes('/runtime.js')); assert.ok(html.includes(encodeURL(fixture.upstream + '/style.css'))); assert.match(response.headers.get('content-security-policy'), /^sandbox allow-scripts allow-forms allow-downloads;/); assert.equal(response.headers.get('access-control-allow-origin'), 'null'); });
test('Upstream POST body and method survive transport', async () => { const response = await fetch(resource(fixture.upstream + '/echo'), { method: 'POST', headers: { 'content-type': 'application/json', origin: 'null' }, body: '{"works":true}' }); const body = await response.json(); assert.equal(body.method, 'POST'); assert.equal(body.body, '{"works":true}'); assert.equal(body.origin, fixture.upstream); });
test('Manual redirects handle cookies and final document URL', async () => { const response = await fetch(resource(fixture.upstream + '/redirect'), { headers: navHeaders }); assert.equal(response.status, 200); assert.equal(response.headers.get('x-iron-upstream-url'), fixture.upstream + '/page'); const echo = await (await fetch(resource(fixture.upstream + '/echo'))).json(); assert.ok(echo.cookie.includes('redirected=yes')); });
test('Redirect loop and private redirect are blocked', async () => { assert.equal((await fetch(resource(fixture.upstream + '/loop'), { headers: navHeaders })).status, 508); assert.equal((await fetch(resource(fixture.upstream + '/private-redirect'), { headers: navHeaders })).status, 403); });
test('CORS denies cross-origin reads, permits opt-in, and validates preflight', async () => { assert.equal((await fetch(resource(fixture.other + '/no-cors'))).status, 403); const allowed = await fetch(resource(fixture.other + '/cors')); assert.equal(allowed.status, 200); assert.deepEqual(await allowed.json(), { cors: true }); assert.equal((await fetch(resource(fixture.other + '/cors'), { method: 'PUT', headers: { 'content-type': 'application/json' }, body: '{}' })).status, 200); });
test('Cross-origin fetch cannot extract cookies through injected HTML config', async () => { await fetch(resource(fixture.upstream + '/set-cookie'), { headers: navHeaders }); const response = await fetch(resource(fixture.other + '/set-cookie')); assert.equal(response.status, 403); });
test('HttpOnly cookies are not included in injected state', async () => { const response = await fetch(resource(fixture.upstream + '/set-cookie'), { headers: navHeaders }); const text = await response.text(); assert.ok(!text.includes('alpha-secret')); assert.ok(text.includes('public-value')); });
test('Virtual storage is scoped by capability origin', async () => { const stateURL = `${fixture.origin}/v/${cap}`; const response = await fetch(stateURL, { method: 'POST', headers: { origin: 'null', 'content-type': 'application/json' }, body: JSON.stringify({ type: 'storage', area: 'local', values: { key: 'only-alpha' } }) }); assert.equal(response.status, 200); const cross = await fetch(resource(fixture.other + '/other'), { headers: navHeaders }); assert.ok(!(await cross.text()).includes('only-alpha')); });
test('Gzip documents decode and transform correctly', async () => { const response = await fetch(resource(fixture.upstream + '/gzip'), { headers: navHeaders }); assert.equal(response.status, 200); const text = await response.text(); assert.ok(text.includes('Compression works')); assert.ok(text.includes('/runtime.js')); });
test('Oversized and malformed scripts fail clearly', async () => { assert.equal((await fetch(resource(fixture.upstream + '/large'))).status, 413); assert.equal((await fetch(resource(fixture.upstream + '/malformed.js'))).status, 422); });
test('Binary downloads preserve content-disposition and bytes', async () => { const response = await fetch(resource(fixture.upstream + '/download')); assert.equal(response.headers.get('content-disposition'), 'attachment; filename="fixture.txt"'); assert.equal(await response.text(), 'IRON fixture download\n'); });
test('Uncredentialed public assets cache without caching authenticated documents', async () => { const headers = { 'x-iron-credentials': 'omit', 'sec-fetch-dest': 'style', 'sec-fetch-mode': 'no-cors' }; await (await fetch(resource(fixture.upstream + '/style.css'), { headers })).text(); const before = fixture.counts.get('/style.css'); await (await fetch(resource(fixture.upstream + '/style.css'), { headers })).text(); assert.equal(fixture.counts.get('/style.css'), before); assert.ok(fixture.application.network.cache.hits > 0); });
test('WebSocket relay preserves text and binary message types', async () => {
  const url = `${fixture.origin.replace(/^http/, 'ws')}/ws/${cap}/${encodeURL(fixture.upstream.replace(/^http/, 'ws') + '/socket')}`;
  const ws = new WebSocket(url, { origin: 'null' }); await new Promise((resolve, reject) => { ws.once('open', resolve); ws.once('error', reject); });
  const echo = new Promise(resolve => ws.once('message', (data, binary) => resolve({ data, binary }))); ws.send('hello'); const result = await echo; assert.equal(result.data.toString(), 'hello'); assert.equal(result.binary, false);
  const echo2 = new Promise(resolve => ws.once('message', (data, binary) => resolve({ data, binary }))); ws.send(Buffer.from([0, 1, 2])); const result2 = await echo2; assert.deepEqual([...result2.data], [0, 1, 2]); assert.equal(result2.binary, true); ws.close();
});
test('Missing search API key returns a truthful configuration error', async () => { const response = await login.call('/api/search?q=example'); assert.equal(response.status, 503); assert.equal((await response.json()).error, 'SEARCH_NOT_CONFIGURED'); });
test('Closing a tab invalidates capabilities and frees its state', async () => { const t = await (await login.call('/api/tabs', 'POST', { private: true })).json(); const n = await (await login.call(`/api/tabs/${t.id}/navigate`, 'POST', { url: fixture.upstream + '/other' })).json(); await login.call(`/api/tabs/${t.id}`, 'DELETE'); assert.equal((await fetch(n.src)).status, 401); assert.equal(fixture.application.state.tabs.has(t.id), false); });

test('Cross-origin POST navigation does not upgrade SameSite Strict cookies to first-party', async () => {
  const owner = fixture.application.state.tabs.get(tab.id);
  owner.jar.setCookieSync('strictsecret=blocked; SameSite=Strict; Path=/', fixture.other + '/');
  const response = await fetch(resource(fixture.other + '/echo'), { method: 'POST', headers: { ...navHeaders, 'content-type': 'text/plain' }, body: 'cross-origin-form' });
  assert.equal(response.status, 200); const data = await response.json(); assert.ok(!data.cookie.includes('strictsecret')); assert.equal(data.origin, fixture.upstream);
});
test('Stale shell navigations cannot revoke the newer document capability', async () => {
  const t = await (await login.call('/api/tabs', 'POST', {})).json();
  const latest = await (await login.call(`/api/tabs/${t.id}/navigate`, 'POST', { url: fixture.upstream + '/other', sequence: 3 })).json();
  const stale = await login.call(`/api/tabs/${t.id}/navigate`, 'POST', { url: fixture.upstream + '/page', sequence: 2 });
  assert.equal(stale.status, 409); assert.equal((await fetch(latest.src, { headers: navHeaders })).status, 200); await login.call(`/api/tabs/${t.id}`, 'DELETE');
});
