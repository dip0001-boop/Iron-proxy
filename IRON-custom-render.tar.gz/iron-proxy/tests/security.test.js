import test from 'node:test';
import assert from 'node:assert/strict';
import { validateTarget, isPublicAddress, contentCSP, RateLimiter, equal } from '../src/security.js';
import { State, ByteCache, Scheduler } from '../src/state.js';
import { readConfig } from '../src/config.js';

test('SSRF blocks IPv4, mapped IPv6, reserved space and URL parser tricks', () => {
  for (const address of ['127.0.0.1', '10.0.0.1', '172.16.0.1', '192.168.1.1', '169.254.169.254', '0.0.0.0', '100.64.0.1', '192.0.2.4', '224.0.0.1', '::1', '::ffff:127.0.0.1', 'fc00::1', 'fe80::1', '2001:db8::1']) assert.equal(isPublicAddress(address), false, address);
  for (const url of ['http://2130706433/', 'http://0x7f000001/', 'http://127.1/', 'http://[::ffff:127.0.0.1]/', 'http://localhost./', 'http://metadata.internal/', 'http://example.com:22/', 'file:///etc/passwd', 'https://user:pass@example.com/', 'https://iron.example/']) assert.throws(() => validateTarget(url, 'https://iron.example'), url);
  assert.equal(isPublicAddress('1.1.1.1'), true); assert.equal(isPublicAddress('2606:4700:4700::1111'), true);
});
test('Production configuration requires HTTPS and a strong minimum password length', () => { assert.throws(() => readConfig({})); assert.throws(() => readConfig({ IRON_PASSWORD: 'long-enough-password', NODE_ENV: 'production' })); });
test('Sandbox does not grant native same-origin access or top navigation', () => { const csp = contentCSP('https://iron.example'); assert.ok(csp.includes('sandbox allow-scripts allow-forms allow-downloads;')); assert.ok(!csp.includes('allow-same-origin')); assert.ok(!csp.includes('allow-top-navigation')); assert.ok(csp.includes("worker-src 'none'")); });
test('Constant-time comparison handles non-ASCII lengths safely', () => { assert.equal(equal('abcd', 'éééé'), false); assert.equal(equal('abcd', 'abcd'), true); });
test('Rate limiter rejects excess traffic and bounds keys', () => { const limiter = new RateLimiter(2, 60000, 1); limiter.take('a'); limiter.take('a'); assert.throws(() => limiter.take('a')); assert.throws(() => limiter.take('b')); });
test('Tab sessions partition cookies, origins and capabilities; disposal revokes access', () => {
  const state = new State({ maxLogins: 2, maxTabs: 3, sessionMs: 60000 });
  try { const user = state.login(); const a = state.createTab(user); const b = state.createTab(user, true); a.jar.setCookieSync('secret=one; Path=/; HttpOnly', 'https://a.example/'); const cap = state.cap(a, 'https://a.example/'); assert.equal(b.jar.getCookieStringSync('https://a.example/'), ''); assert.equal(a.jar.getCookieStringSync('https://b.example/'), ''); assert.deepEqual(state.snapshot(cap, cap.url).cookies, []); state.closeTab(a); assert.throws(() => state.getCap(cap.id)); assert.equal(state.tabs.size, 1); } finally { state.close(); }
});
test('Byte cache respects LRU and exact byte capacity', () => { const cache = new ByteCache(10); cache.set('a', { body: Buffer.alloc(6) }, 60000); cache.set('b', { body: Buffer.alloc(4) }, 60000); cache.get('a'); cache.set('c', { body: Buffer.alloc(4) }, 60000); assert.equal(cache.get('b'), null); assert.equal(cache.bytes, 10); cache.clear(); assert.equal(cache.bytes, 0); });
test('Scheduler enforces per-tab fairness, cancellation and idempotent release', async () => {
  const scheduler = new Scheduler(2, 1, 4); const releaseA = await scheduler.acquire('a'); let secondA = false;
  const pending = scheduler.acquire('a').then(release => { secondA = true; return release; }); const releaseB = await scheduler.acquire('b'); assert.equal(secondA, false); assert.equal(scheduler.active, 2);
  const controller = new AbortController(); const cancelled = scheduler.acquire('c', controller.signal); controller.abort(); await assert.rejects(cancelled, { name: 'AbortError' }); releaseA(); releaseA(); const releaseNext = await pending; releaseNext(); releaseB(); assert.equal(scheduler.active, 0); assert.equal(scheduler.queue.length, 0);
});

test('Connector DNS policy rejects mixed results and rechecks subsequent resolutions', async () => {
  const dns = (await import('node:dns')).default;
  const { safeLookup } = await import('../src/security.js'); const original = dns.lookup;
  try {
    let response = [{ address: '1.1.1.1', family: 4 }];
    dns.lookup = (_host, _options, callback) => callback(null, response);
    const lookup = () => new Promise((resolve, reject) => safeLookup('example.com', { all: true }, (error, addresses) => error ? reject(error) : resolve(addresses)));
    assert.deepEqual(await lookup(), response);
    response = [{ address: '1.1.1.1', family: 4 }, { address: '127.0.0.1', family: 4 }]; await assert.rejects(lookup(), { code: 'DNS_BLOCKED' });
    response = [{ address: '10.0.0.1', family: 4 }]; await assert.rejects(lookup(), { code: 'DNS_BLOCKED' });
  } finally { dns.lookup = original; }
});
