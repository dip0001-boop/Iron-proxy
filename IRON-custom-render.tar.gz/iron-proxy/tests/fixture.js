import http from 'node:http';
import { WebSocketServer } from 'ws';
import { gzipSync } from 'node:zlib';
import { Network } from '../src/network.js';
import { createApplication } from '../src/server.js';
import { readConfig } from '../src/config.js';

export const PASSWORD = 'iron-test-password-386q7-only';
export async function startFixture() {
  const counts = new Map(); let fixtureOrigin;
  const upstream = http.createServer(async (req, res) => {
    const url = new URL(req.url, 'http://' + req.headers.host);
    counts.set(url.pathname, (counts.get(url.pathname) || 0) + 1);
    const send = (type, data, status = 200, headers = {}) => { res.writeHead(status, { 'content-type': type, ...headers }); res.end(data); };
    if (url.pathname === '/redirect') { res.writeHead(302, { location: '/page', 'set-cookie': 'redirected=yes; Path=/; HttpOnly' }); return res.end(); }
    if (url.pathname === '/cross-redirect') { res.writeHead(302, { location: fixtureOrigin.replace('alpha.test', 'beta.test') + '/other' }); return res.end(); }
    if (url.pathname === '/private-redirect') { res.writeHead(302, { location: 'http://127.0.0.1/private' }); return res.end(); }
    if (url.pathname === '/loop') { res.writeHead(302, { location: '/loop' }); return res.end(); }
    if (url.pathname === '/echo') {
      const chunks = []; for await (const c of req) chunks.push(c);
      return send('application/json', JSON.stringify({ method: req.method, body: Buffer.concat(chunks).toString(), cookie: req.headers.cookie || '', authorization: req.headers.authorization || '', origin: req.headers.origin || '', query: url.search }));
    }
    if (url.pathname === '/cors') {
      if (req.method === 'OPTIONS') return send('text/plain', '', 204, { 'access-control-allow-origin': req.headers.origin, 'access-control-allow-methods': 'GET, POST, PUT', 'access-control-allow-headers': 'content-type, authorization' });
      return send('application/json', '{"cors":true}', 200, { 'access-control-allow-origin': '*' });
    }
    if (url.pathname === '/no-cors') return send('application/json', '{"secret":"beta secret"}');
    if (url.pathname === '/set-cookie') return send('text/html', '<h1>Cookie set</h1>', 200, { 'set-cookie': ['account=alpha-secret; Path=/; HttpOnly', 'visible=public-value; Path=/'] });
    if (url.pathname === '/other') return send('text/html', '<!doctype html><title>Other origin</title><h1 id="other">Other origin</h1><script>document.body.dataset.storage = localStorage.getItem("key") || "empty"; document.body.dataset.cookie=document.cookie;</script>');
    if (url.pathname === '/style.css') return send('text/css', ':root{--test:7} #styled{color:rgb(1, 101, 201);background-image:url("/pixel.svg")}', 200, { 'cache-control': 'public, max-age=60' });
    if (url.pathname === '/pixel.svg') return send('image/svg+xml', '<svg xmlns="http://www.w3.org/2000/svg" width="1" height="1"><rect width="1" height="1" fill="blue"/></svg>', 200, { 'cache-control': 'public, max-age=60' });
    if (url.pathname === '/module.js') return send('text/javascript', 'import {value} from "./dep.js"; document.body.dataset.module = value; const next = await import("./dynamic.js"); document.body.dataset.dynamic = next.value; document.body.dataset.meta = import.meta.url;');
    if (url.pathname === '/dep.js') return send('text/javascript', 'export const value = "module-ok";');
    if (url.pathname === '/dynamic.js') return send('text/javascript', 'export const value = "dynamic-ok";');
    if (url.pathname === '/external.js') return send('text/javascript', 'document.body.dataset.external = "external-ok"; document.body.dataset.location = location.href;');
    if (url.pathname === '/download') return send('application/octet-stream', Buffer.from('IRON fixture download\n'), 200, { 'content-disposition': 'attachment; filename="fixture.txt"' });
    if (url.pathname === '/form') {
      const chunks = []; for await (const chunk of req) chunks.push(chunk);
      return send('text/html', `<!doctype html><title>Form result</title><h1 id="form-result">${Buffer.concat(chunks).toString().replace(/[<&]/g, '') || url.search.replace(/[<&]/g, '')}</h1>`);
    }
    if (url.pathname === '/slow') { const timer = setTimeout(() => send('text/html', '<h1>Slow fixture</h1>'), 2000); res.on('close', () => clearTimeout(timer)); return; }
    if (url.pathname === '/gzip') return send('text/html; charset=utf-8', gzipSync('<!doctype html><title>Compressed</title><h1>Compression works</h1>'), 200, { 'content-encoding': 'gzip' });
    if (url.pathname === '/large') return send('text/javascript', Buffer.alloc(5 * 1024 * 1024, 32));
    if (url.pathname === '/malformed.js') return send('text/javascript', 'function { this is invalid');
    if (url.pathname === '/page') {
      return send('text/html', `<!doctype html><html><head><title>IRON fixture</title><link rel="stylesheet" href="/style.css"></head><body><h1 id="styled">IRON fixture</h1><a id="next" href="/other">Next page</a><a id="download" href="/download" download="fixture.txt">Download</a><form action="/form" method="post"><input name="message" value="hello iron"><button id="submit">Send form</button></form><script src="/external.js"></script><script type="module" src="/module.js"></script><script>
      document.body.dataset.inline = "inline-ok";
      document.cookie="script=yes; Path=/"; localStorage.setItem("key", "alpha-value"); sessionStorage.setItem("session", "alpha-session");
      fetch("/echo").then(r=>r.json()).then(data=>{ document.body.dataset.fetch=data.cookie.includes("script=yes") ? "fetch-ok" : "cookie-missing"; });
      const xhr=new XMLHttpRequest(); xhr.open("GET","/echo"); xhr.onload=()=>document.body.dataset.xhr="xhr-ok"; xhr.send();
      const ws=new WebSocket("${fixtureOrigin.replace(/^http/, 'ws')}/socket"); ws.onopen=()=>ws.send("echo-me"); ws.onmessage=e=>{document.body.dataset.ws=e.data; ws.close();};
      const img=document.createElement("img"); img.id="dynamic-image"; img.src="/pixel.svg"; document.body.appendChild(img);
      document.body.dataset.isolation=(()=>{try{return parent.document.title}catch{return "blocked"}})();
      fetch("${fixtureOrigin.replace('alpha.test','beta.test')}/no-cors").then(r=>document.body.dataset.corsBlocked=String(r.status));
      </script></body></html>`);
    }
    send('text/html', '<!doctype html><title>Fixture home</title><h1>Fixture home</h1>');
  });
  await new Promise(resolve => upstream.listen(0, '127.0.0.1', resolve));
  const port = upstream.address().port; fixtureOrigin = `http://alpha.test:${port}`;
  const wss = new WebSocketServer({ server: upstream, path: '/socket' }); wss.on('connection', ws => ws.on('message', (data, binary) => ws.send(data, { binary })));
  // Dependency injection is confined to tests. There is no environment switch that disables production SSRF checks.
  const validate = value => { const url = new URL(value); if (!['alpha.test', 'beta.test'].includes(url.hostname) || Number(url.port) !== port || !['http:', 'ws:'].includes(url.protocol) || url.username || url.password) throw Object.assign(new Error('Fixture target blocked'), { status: 403, code: 'FIXTURE_BLOCKED' }); return url; };
  const lookup = (_host, options, callback) => options?.all ? callback(null, [{ address: '127.0.0.1', family: 4 }]) : callback(null, '127.0.0.1', 4);
  const appPort = await new Promise(resolve => { const probe = http.createServer(); probe.listen(0, '127.0.0.1', () => { const n = probe.address().port; probe.close(() => resolve(n)); }); });
  const config = readConfig({ PORT: String(appPort), PUBLIC_ORIGIN: `http://127.0.0.1:${appPort}`, IRON_PASSWORD: PASSWORD });
  const network = new Network(config, { validate, lookup });
  const application = await createApplication(config, { network, validateWebSocket: validate });
  await new Promise(resolve => application.server.listen(appPort, '127.0.0.1', resolve));
  return {
    application, origin: config.origin, upstream: fixtureOrigin, other: fixtureOrigin.replace('alpha.test', 'beta.test'), counts,
    async close() { await application.close(); for (const ws of wss.clients) ws.terminate(); wss.close(); upstream.closeAllConnections(); await new Promise(resolve => upstream.close(resolve)); },
  };
}
export async function signIn(fixture) {
  const response = await fetch(fixture.origin + '/api/login', { method: 'POST', headers: { origin: fixture.origin, 'content-type': 'application/json' }, body: JSON.stringify({ password: PASSWORD }) });
  const body = await response.json(); const cookie = response.headers.get('set-cookie').split(';')[0];
  const call = async (pathname, method = 'GET', data) => fetch(fixture.origin + pathname, { method, headers: { origin: fixture.origin, cookie, 'x-iron-csrf': body.csrf, ...(data !== undefined ? { 'content-type': 'application/json' } : {}) }, body: data === undefined ? undefined : JSON.stringify(data) });
  return { cookie, csrf: body.csrf, call };
}
