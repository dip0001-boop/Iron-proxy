# IRON — $100/month commercial readiness checklist

This is a product goal, **not** the present value or readiness of this build.
Before accepting paying users:

## Security gates

- [ ] Isolate the untrusted compatibility content origin from the privileged
      browser shell with a distinct eTLD+1/domain and strict cookies; same-origin
      iframe execution can compromise the shell.
- [ ] Commission a security review of SSRF guards, DNS pinning, cache isolation,
      Wisp forwarding, auth, browser cross-origin behavior, and content script
      injection. Test with intentionally malicious sites, not just trusted demos.
- [ ] Replace shared access key with unique customer accounts, MFA, revocation,
      session limits, customer-specific quotas and secure password recovery.
- [ ] Define privacy, abuse response, retention and acceptable use policies.
- [ ] Audit dependency licenses and AGPL compliance; provide full source access
      as required for network interaction with AGPL-derived components.
- [ ] Ensure purchased access cannot turn the instance into an anonymous relay.

## Reliability and performance gates

- [ ] Run a 50–100-site reproducible compatibility suite (static HTML, auth,
      SPA, ES modules, workers, videos, websockets, large assets, redirects).
- [ ] Benchmark against UV, Rammerhead, Scramjet on equal resources and network.
      Measure navigation p50/p95, success rate, RAM, errors and concurrency.
- [ ] Add end-to-end browser tests in Chromium and mobile Chrome.
- [ ] Configure paid hosting, multiple instances where required, alerting,
      backup, deployment rollback and documented recovery procedures.
- [ ] Run 24-hour and 7-day stability/uptime tests before promising reliability.

## Commercial features

- [ ] Billing and subscription management with the customer's proper consent,
      identity and tax/legal obligations.
- [ ] Persistent bookmark/history sync **only with opt-in** and encryption.
- [ ] Transparent limitations: no promised bot detection evasion or DRM bypass.
- [ ] User support, service-status page, onboarding and cancellation process.

## Product positioning

A generic web proxy rarely justifies $100/month. Target a verifiable customer
problem such as managed browser testing, internal site compatibility diagnostics,
accountable enterprise access, or developer debugging—not claims of unlocking
any website. Validate willingness to pay with real potential customers first.
