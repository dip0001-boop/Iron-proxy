# IRON 0.6.0

- Production-safe default: unisolated Scramjet mode disabled unless explicitly opted in; native browsing stays available.
- Performance: bounded lazy rewrite worker; worker task timeouts, abort and queue limits.
- Transport correctness: drop upstream content validators after transforming the response.
- Better diagnostics: process CPU, event-loop delay, heap and rewrite worker statistics.
- Shell security: explicit CSP with no `unsafe-eval` in safe mode, permissions policy, HSTS in production and more transparent settings.
- Testing: security regression checks and an optional real-browser Playwright harness.
- Commercial readiness: measurable scorecard and explicit isolation requirements.

**Not fixed/claimed:** YouTube DRM, Google CAPTCHA, all GitHub workflows, full video/game support, true multiuser billing, strong origin separation in compatibility mode, or perfect security.
