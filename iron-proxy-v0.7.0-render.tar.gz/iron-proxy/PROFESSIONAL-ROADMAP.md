# IRON Professional Engineering Scorecard (v0.6.0)

Scores in the user-requested range are **targets**, not achieved ratings. An
honest score requires reproducible tests and independent security review.

| Area | Target | Objective release gate |
|---|---:|---|
| Security | 10/10 | Untrusted content on separate origin; authz and SSRF audit, pentest, dependency/SBOM review, abuse monitoring, isolated user identities; no critical/high findings |
| Networking architecture | 8.3/10 | 99.9% request completion under documented rate limits, correct Range/redirect/WS/stream backpressure handling, no unbounded queues |
| Browser interface | 8/10 | Responsive accessible layout and keyboard shortcuts, correct tab/back/history, downloads where supported, 4GB Chromebook real-device test |
| Website compatibility | 9/10 | >=90% feature-complete across curated 50-site benchmark; including GitHub, interactive apps, video playback; site-level pass criteria |
| Performance engineering | 9.4/10 | IRON >= competition on median and p95 browser navigation in repeated matched-device runs; memory ceiling and long-tail latency thresholds |
| Reliability/diagnostics | 7.4/10 | Automated uptime, error budget, alerting, per-request anonymized traces, 24-hour load soak, rollback verification |
| Commercial readiness | 8/10 | Multi-user accounts, isolated user data, payments, privacy/terms and support, legal license compliance, paid always-on hosting, backups and data deletion |

## Architecture-level blocker

Scramjet Compatibility mode is framed with `allow-scripts allow-same-origin`
from the same origin as the parent shell. That is **not suitable for sensitive
browsing or paying customers**. v0.6 disables it in production by default.
Set `IRON_ALLOW_UNISOLATED_COMPAT=1` only for explicit personal, non-sensitive
experimentation, and remove that flag before public launch.

A long-term fix requires a dedicated, different **site execution origin** with
separate cookies, postMessage validation, no shell API access, and independent
Service Worker scope. The current one-domain Render architecture does not
provide this. Simply turning the iframe sandbox off or claiming Chrome-like
identity would be a security regression.

## What v0.6 actually delivers

- Bounded rewrite worker for large HTML/CSS/JS, moving heavy parsing off the
  HTTP event loop (15-second timeout, ~96 MB V8 old-gen cap, 16 MiB queue cap).
- A security-off-by-default deployment policy for unisolated compatibility.
- Narrow shell CSP in secure mode, security response headers, plus explicit
  warnings when the experimental mode is enabled.
- No-forwarding of stale ETag and Last-Modified for transformed documents.
- Event-loop lag, CPU, worker depth/timeouts and memory diagnostics.
- Optional real-Chromium Playwright smoke harness for selected public sites.

## What's NOT verified or complete

- Full production integration cannot be tested in the source-building
  environment without npm package downloads. Render runs syntax+integration
  tests during build.
- YouTube, games, GitHub interaction and login compatibility remain unproven.
- Zero-day immunity, perfect security, or universal site compatibility are
  not achievable guarantees.
- IRON isn't ready to sell for $100/month. It still lacks billed multi-user
  tenancy, SLO, security audit and production-grade content origin separation.
- The experimental Scramjet integration has AGPL obligations; seek appropriate
  legal advice for commercial offering and provide required source availability.

## Browser compatibility measurement

In a Node.js GitHub Codespace with Chromium/Playwright installed, run:

```sh
npm install
npm install --no-save playwright
npx playwright install chromium
IRON_BASE_URL=https://iron-proxy.onrender.com IRON_ACCESS_KEY='<secret>' npm run test:browser
```

*Do not put your secret in your repo, logs, screenshots or chat.*

Browser harness measurements are navigation-smoke indicators only. For a
meaningful 9/10 claim: define site-specific interactions, user-facing load
milestones, and video/game functional pass conditions; repeat on matched
hardware, account state, network and engine versions.

## Render deployment

The archive includes a top-level `iron-proxy/` folder. With the archive in the
GitHub repository root:

Build command:

```sh
tar -xzf iron-proxy-v0.6.0-render.tar.gz && cd iron-proxy && npm install --omit=dev && npm run check && npm test
```

Start command:

```sh
cd iron-proxy && npm start
```

Set `IRON_ACCESS_KEY` (>=16 secret characters), `NODE_ENV=production`,
`IRON_PUBLIC_ORIGIN` if necessary, and optionally `BRAVE_SEARCH_API_KEY`.

The safe default disables Scramjet because it is not isolated. If you need to
compare compatibility for personal, non-sensitive testing, opt in explicitly
with `IRON_ALLOW_UNISOLATED_COMPAT=1` in Render **Environment**; doing so
reintroduces the known risk. Never use sensitive accounts with it.

Keep a v0.5 backup and check `/healthz` for `0.6.0` after deploying; restart
Chrome if an old Service Worker continues intercepting routes. Do not expose
this single-password service publicly as a paid, anonymous relay.
