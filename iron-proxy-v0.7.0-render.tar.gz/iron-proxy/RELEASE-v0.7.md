# IRON v0.7.0 — evidence-first engineering release

**STATUS: engineering alpha, not a commercial or independently audited browser.**

## Changes that actually shipped in the source

1. **Fair HTTP scheduling:** max 24 concurrent requests globally, max 10 per tab, max 96 queued overall; FIFO within each tab and rotating arbitration between tabs. Abandoned requests leave queues. This prevents a high-resource game page from monopolising all network slots.
2. **Asynchronous decompression:** gzip/deflate/Brotli processing no longer runs synchronously on Node's main thread. Maximum decoded document size remains 8 MB to limit decompression bombs.
3. **Cache correctness:** no upstream ETag/Last-Modified is reattached to rewritten JS/CSS; `Vary: *` is never cached; upstream user-agent and original referrer are included in the isolated cache key. Cache remains bounded and excludes HTML/private responses.
4. **Per-tab resource inspector:** authenticated hostname-only resource statistics (status, type, duration, aborted), 72-entry ring buffer, cleared with tab disposal. No paths, search terms, passwords, cookies or response bodies are stored.
5. **Better browser failure UX:** an overdue navigation produces a warning after 25 s rather than spinning silently, with details available from Network Laboratory.
6. **Browser testing harness:** Playwright can check real page content, a Wikipedia input interaction, GitHub basic links, and whether a media element's playback time advances. Tests report the facts observed, not invented cross-proxy scores.
7. **Optional isolated compatibility service (experimental):** a separate Render origin serves the Scramjet/Wisp engine, using a 90-second signed one-use authentication ticket and a lower-trust content bridge. The privileged shell CSP permits only that configured frame origin. This is **not** safe to declare production-ready until the complete two-service flow and security boundaries have been independently tested.
8. **Top-level dependency versions pinned.** There is still no committed transitive dependency lockfile. Generate and commit a lockfile before commercial use, then use `npm ci` and verify dependency licenses/vulnerabilities.

## Verification status

- Syntax and isolated-module unit tests: runnable without network in this source archive.
- HTTP integration tests: provided and must pass on Render with installed dependencies.
- Browser integration: **not verified in this build environment** (Chromium / npm dependency retrieval unavailable).
- Security pentest, external security audit, commercial billing tests: **not performed**.
- Scramjet two-origin handoff and third-party cookie behavior: **not yet verified**.
- YouTube, complex games, GitHub interactions, performance comparisons: **not yet verified**.

**Never assume the original 7 requested scores have been achieved.** Passing static tests is not proof of website compatibility, browser isolation, or security against a hostile site.

## Rollback

If the new release malfunctions, restore the previous v0.6 TAR.GZ and its original Render build command and redeploy, or roll back to the last known-good Render deployment. Do not leave `IRON_ALLOW_UNISOLATED_COMPAT=1` enabled on a public customer-facing service.
