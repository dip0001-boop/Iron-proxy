/**
 * IRON real-Chromium compatibility recorder.
 *
 * Install Playwright separately and run this against a private IRON instance:
 *   npm install --no-save playwright && npx playwright install chromium
 *   IRON_BASE_URL=https://example.onrender.com IRON_ACCESS_KEY=... npm run test:browser
 *
 * Unlike a synthetic "page loaded" rating, this checks interactive
 * functionality and records broken resources. Only anonymous public pages
 * are tested. No user passwords, page URLs, query strings or session caps
 * are printed. No test outcome is hard-coded as a pass.
 */
import { writeFile } from 'node:fs/promises';
const base = process.env.IRON_BASE_URL || 'http://127.0.0.1:10000';
const accessKey = process.env.IRON_ACCESS_KEY;
const mode = process.env.IRON_TEST_ENGINE === 'compat' ? 'compat' : 'native';
if (!accessKey) { console.error('IRON_ACCESS_KEY must be configured'); process.exit(2); }
let chromium;
try { ({ chromium } = await import('playwright')); }
catch { console.error('Playwright and Chromium must be installed for real-browser tests'); process.exit(2); }

const websites = [
  { name:'Wikipedia', url:'https://en.wikipedia.org/wiki/Main_Page', kind:'document' },
  { name:'GitHub', url:'https://github.com', kind:'app' },
  { name:'MDN', url:'https://developer.mozilla.org', kind:'document' },
  { name:'HTML5 video', url:'https://www.w3schools.com/html/html5_video.asp', kind:'media' }
];
const browser = await chromium.launch({ headless:true });
const rows = [];
const startSuite = new Date().toISOString();
try {
  const context = await browser.newContext({ viewport:{ width:1280, height:720 }, reducedMotion:'reduce' });
  const page = await context.newPage();
  let errors = 0;
  let failedRequests = 0;
  page.on('pageerror', () => { errors++; });
  page.on('requestfailed', () => { failedRequests++; });
  await page.goto(base, { waitUntil:'domcontentloaded', timeout:30_000 });
  if (await page.locator('#loginLayer:not(.hidden)').count()) {
    await page.locator('#password').fill(accessKey);
    await page.locator('#loginForm button[type=submit]').click();
  }
  await page.locator('#workspace:not(.hidden)').waitFor({ timeout:20_000 });
  if (mode === 'compat') {
    await page.evaluate(() => {
      const settings = JSON.parse(localStorage.getItem('iron-settings') || '{}');
      localStorage.setItem('iron-settings', JSON.stringify({ ...settings, engine:'compat' }));
    });
    await page.reload();
    await page.locator('#workspace:not(.hidden)').waitFor({ timeout:20_000 });
    const selected = await page.locator('#engineInfo').innerText();
    if (selected !== 'COMPAT') throw new Error('The server has disabled compatibility mode');
  }
  for (const site of websites) {
    const row = { site:site.name, engine:mode, document:false, interactive:false, mediaPlayback:null,
      resourceFailures:0, pageErrors:0, elapsedMs:0, outcome:'not-run' };
    rows.push(row);
    const before = performance.now();
    const previousErrors = errors;
    const previousFailures = failedRequests;
    try {
      await page.locator('#address').fill(site.url);
      await page.locator('#address').press('Enter');
      // First attempt a real document load; then allow asynchronous web apps
      // to initialise. Does not count a proxy error page as a working site.
      await page.waitForTimeout(5000);
      const frame = page.frames().find(f => /\/p\/|\/scram\//.test(f.url()));
      if (!frame) { row.outcome='no-frame'; continue; }
      const title = await frame.locator('title').first().textContent({timeout:6000}).catch(()=>'');
      const body = await frame.locator('body').first().innerText({timeout:6000}).catch(()=>'');
      const proxyError = /IRON NETWORK.*(?:error|failed)|IRON CORE could not|Destination blocked/i.test(body.slice(0,500));
      row.document = body.length >= 100 && !proxyError;
      if (!row.document) { row.outcome='incomplete-document'; continue; }
      if (site.name === 'Wikipedia') {
        // Functional check: an interactive input is usable, not just present.
        const field = frame.locator('input[name="search"]').first();
        if (await field.count()) {
          await field.fill('astronomy');
          row.interactive = (await field.inputValue()) === 'astronomy';
        }
      } else if (site.name === 'GitHub') {
        // Basic page application criterion; not proof login or repository
        // interaction works. The separate resource failure count matters.
        row.interactive = (await frame.locator('a[href]').count()) >= 10 &&
          /GitHub/i.test(title + ' ' + body.slice(0,1000));
      } else if (site.name === 'MDN') {
        row.interactive = (await frame.locator('a[href]').count()) >= 10;
      } else {
        const video = frame.locator('video').first();
        if (await video.count()) {
          row.interactive = true;
          row.mediaPlayback = await video.evaluate(async element => {
            try {
              element.muted = true;
              await Promise.race([element.play(), new Promise((_, reject) => setTimeout(() => reject(new Error('play-timeout')), 5000))]);
              const t = element.currentTime;
              await new Promise(resolve => setTimeout(resolve, 2200));
              const works = element.currentTime > t;
              element.pause();
              return works;
            } catch { return false; }
          });
        }
      }
      row.outcome = row.interactive ? 'partial-or-better' : 'loaded-no-functional-proof';
    } catch(error) { row.outcome = 'test-error:' + (error?.name || 'Error'); }
    finally {
      row.elapsedMs = Math.round(performance.now() - before);
      row.resourceFailures = failedRequests - previousFailures;
      row.pageErrors = errors - previousErrors;
      console.log(JSON.stringify(row));
    }
  }
  await context.close();
} finally { await browser.close(); }
const report = {
  suite:'IRON anonymous web compatibility', at:startSuite, engine:mode,
  note:'Interactive criteria are site-specific and incomplete. This is not a security audit or comparative benchmark.',
  documentRate: rows.length ? rows.filter(r => r.document).length / rows.length : 0,
  interactionRate: rows.length ? rows.filter(r => r.interactive).length / rows.length : 0,
  results:rows
};
if (process.env.IRON_TEST_REPORT) await writeFile(process.env.IRON_TEST_REPORT, JSON.stringify(report,null,2) + '\n');
console.log('\n' + JSON.stringify({ engine:mode, documents:report.documentRate, basicInteractions:report.interactionRate, websites:rows.length },null,2));
