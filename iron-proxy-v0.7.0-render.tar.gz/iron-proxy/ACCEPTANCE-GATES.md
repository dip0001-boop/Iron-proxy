# Professional IRON acceptance gates — NOT yet achieved

The requested numbers (10/10 security, 8.3/10 networking, 8/10 browser features, 9/10 compatibility, 9.4/10 performance, 7.4/10 reliability, 8/10 commercial readiness) are desired outcomes, **not** measured results. IRON cannot receive arbitrary numerical credit for implementing code. Use these concrete gates before considering production.

## Security target: 10/10

No engineering team can prove absolute 10/10 security. Practical gate: independent penetration test of shell, Native and separately hosted content engine; ZERO open critical/high findings; origin isolation verified in Chrome/Firefox/Safari; tab and user session cross-access tests; SSRF (all public/private ranges, DNS rebinding, redirects and WebSocket) negative tests; CSRF/CSWSH, XSS, clickjacking, supply-chain scanning and secret-rotation checks; logging/privacy review. **Current: not cleared.**

## Network target: 8.3/10

At least 99.9% successful requests to a stable synthetic endpoint under representative concurrency; bounded memory, graceful cancellation, no socket leaks, no private-network access, successful Range/WebSocket/redirect tests and failover/rollback drills. **Current: code features + fixture tests, live soak not run.**

## Browser UX target: 8/10

Chromebook/mobile usability study, accessibility keyboard/contrast/ARIA checks, tab/navigation correctness, verified downloads, session privacy, bookmark persistence, real search API, native/isolated engine controls, navigation failure feedback and measured UI responsiveness. **Current: partial.**

## Compatibility target: 9/10

A stable public test list of 50+ varied sites, measured in **Chromium** using meaningful functionality checks (search, navigation, forms, authenticated sandbox test, embedded games, video), with >=90% of interaction scenarios successful. Document any bot challenges and DRM as distinct from bugs; do not claim to defeat them. **Current: not measured; known GitHub/video/game failures.**

## Performance target: 9.4/10

Reproducible 30-minute runs against identical deployments and workloads of IRON, standalone Scramjet, Rammerhead and Ultraviolet. Collect median and p95 navigation, bytes, CPU, peak RSS, first-content latency, throughput, and per-tab fairness, with low-end Chromebook UI response times. Re-run 5 trials each. **Current: no comparative results.**

## Reliability target: 7.4/10

Documented error budgets, actionable traces, uptime monitoring, tests on Render's actual instance size, 60-minute soak at target concurrency, restart/rollback drills, health-check behavior, and no unhandled promise rejections. **Current: partial.**

## Commercial readiness target: 8/10

Separate customer accounts, credential recovery, revocable persistent sessions, billing and refunds, abuse prevention, privacy terms, third-party AGPL obligations assessed, trained support, backups, operational billing tests, scalability, cost and revenue analysis, legal eligibility and tax advice. **Current: not suitable for paying customers.**

**No score is granted by this document.** It defines evidence that must exist before scores are discussed.
