/** Real Scramjet 2.x integration, kept separate from IRON CORE's native engine.
 * Do not claim this third-party compatibility layer is our own rewriter.
 */
let pending;
function loadScript(src) {
  return new Promise((resolve, reject) => {
    const element = document.createElement('script');
    element.src = src;
    element.onload = resolve;
    element.onerror = () => reject(new Error('Failed to load proxy runtime ' + src));
    document.head.append(element);
  });
}
async function boot() {
  if (!('serviceWorker' in navigator)) throw new Error('This browser does not support Service Workers');
  const registration = await navigator.serviceWorker.register('/sw.js', { scope: '/', updateViaCache: 'none' });
  await navigator.serviceWorker.ready;
  if (!navigator.serviceWorker.controller) {
    await Promise.race([
      new Promise(resolve => navigator.serviceWorker.addEventListener('controllerchange', resolve, { once: true })),
      new Promise((_, reject) => setTimeout(() => reject(new Error('Service Worker activation timed out')), 15000))
    ]);
  }
  const serviceworker = navigator.serviceWorker.controller || registration.active;
  if (!serviceworker) throw new Error('Compatibility Service Worker not active');
  await loadScript('/scram/scramjet.js');
  await loadScript('/controller/controller.api.js');
  await loadScript('/utils/scramjet-utils.js');
  const { default: LibcurlClient } = await import('/libcurl/index.mjs');
  const scheme = location.protocol === 'https:' ? 'wss:' : 'ws:';
  const transport = new LibcurlClient({ wisp: `${scheme}//${location.host}/wisp/` });
  const controller = new window.$scramjetController.Controller({
    serviceworker,
    transport,
    config: {
      scramjetPath: '/scram/scramjet.js',
      wasmPath: '/scram/scramjet.wasm',
      injectPath: '/controller/controller.inject.js'
    }
  });
  await controller.wait();
  // Service Workers are suspended by Chrome when idle. Refresh the message
  // port regularly until the upstream worker-revival problem is fixed.
  const ping = setInterval(() => navigator.serviceWorker.controller?.postMessage('keepalive'), 15000);
  window.addEventListener('pagehide', () => clearInterval(ping), { once: true });
  return { controller, utils: window.$scramjetUtils };
}
export function scramjetEngine() {
  if (!pending) pending = boot().catch(e => { pending = null; throw e; });
  return pending;
}
export async function createScramjetFrame(element, onUrl, onEscape) {
  const { controller, utils } = await scramjetEngine();
  const session = controller.createFrame(element, {
    plugins: [
      new utils.HttpCachePlugin(),
      new utils.UrlWatcherPlugin(url => onUrl(String(url))),
      new utils.CatchEscapedLinksPlugin(url => {
        onEscape(String(url));
        return new URL(location.href);
      })
    ]
  });
  return {
    go: url => session.go(url),
    back: () => session.back(),
    forward: () => session.forward(),
    reload: () => session.reload(),
    dispose() {
      // Scramjet controller 0.0.14 doesn't auto-prune frames.
      const i = controller.frames.indexOf(session);
      if (i !== -1) controller.frames.splice(i, 1);
      element.remove();
    }
  };
}
