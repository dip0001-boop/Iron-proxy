/** Browser-shell adapter for the independent lower-trust content origin. */
export async function createIsolatedFrame(element, onUrl, onEscape, cap, onError = () => {}) {
  const response = await fetch('/api/isolated-ticket', { method:'POST',
    headers:{'Content-Type':'application/json','X-IRON-Client':'1'}, body:JSON.stringify({cap}) });
  if (!response.ok) throw new Error('Isolated content session unavailable');
  const data = await response.json();
  const origin = new URL(data.origin).origin;
  if (!data.url.startsWith(origin + '/bridge.html#')) throw new Error('Invalid content service response');
  let closed = false;
  let ready = false;
  let pendingUrl = '';
  function send(action, extra={}) {
    if (!ready || closed || !element.contentWindow) return;
    element.contentWindow.postMessage({ type:'iron:bridge-command', action, ...extra }, origin);
  }
  const listener = event => {
    if (closed || event.source !== element.contentWindow || event.origin !== origin || !event.data) return;
    const {type,url} = event.data;
    if (type === 'iron:bridge-ready') { ready=true; if (pendingUrl) send('go',{url:pendingUrl}); }
    else if (type === 'iron:bridge-location' && typeof url==='string') onUrl(url);
    else if (type === 'iron:bridge-popup' && typeof url==='string') onEscape(url);
    else if (type === 'iron:bridge-error') onError('The isolated content service could not initialise.');
  };
  window.addEventListener('message',listener);
  element.src=data.url;
  return {
    go(url) {pendingUrl=url;send('go',{url});},
    back() {send('back');}, forward() {send('forward');}, reload() {send('reload');},
    dispose() {closed=true;window.removeEventListener('message',listener);element.src='about:blank';element.remove();}
  };
}
