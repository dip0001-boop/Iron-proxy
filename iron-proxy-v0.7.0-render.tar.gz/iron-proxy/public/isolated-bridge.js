/**
 * Lower-trust content-side controller. Runs at a different origin from the
 * privileged IRON Browser shell. NEVER sends auth tickets or cookies to parent.
 */
const status = document.getElementById('status');
const ticket = location.hash.slice(1);
// Strip sensitive one-time ticket before any third-party document is loaded.
try { history.replaceState(null, '', '/bridge.html'); } catch {}
let parentOrigin = null;
let session = null;
let lastNavigated = '';
const post = (type, detail={}) => {
  if (parentOrigin) parent.postMessage({ type, ...detail }, parentOrigin);
};
function safeUrl(candidate) {
  try { const url=new URL(candidate); return ['http:','https:'].includes(url.protocol) ? url.href : null; }
  catch { return null; }
}
async function boot() {
  if (!ticket || ticket.length > 700) throw new Error('The isolated session ticket is missing');
  const response = await fetch('/api/bridge-auth', { method:'POST', credentials:'include',
    headers:{'Content-Type':'application/json'}, body:JSON.stringify({ticket}) });
  if (!response.ok) throw new Error('Isolated session authentication failed');
  const data = await response.json();
  parentOrigin = data.parentOrigin;
  const check = await fetch('/api/bridge-session', { credentials:'include' });
  if (!check.ok) throw new Error('This browser did not retain its partitioned content cookie');
  const { createScramjetFrame } = await import('/scramjet-client.js');
  const iframe = document.createElement('iframe');
  iframe.id='site';
  iframe.setAttribute('sandbox','allow-scripts allow-same-origin allow-forms allow-downloads allow-pointer-lock');
  iframe.setAttribute('referrerpolicy','no-referrer');
  iframe.setAttribute('allow','autoplay; fullscreen; picture-in-picture');
  iframe.setAttribute('allowfullscreen','');
  document.body.appendChild(iframe);
  session = await createScramjetFrame(iframe,
    url => {const clean=safeUrl(url);if(clean){lastNavigated=clean;post('iron:bridge-location',{url:clean});}},
    url => {const clean=safeUrl(url);if(clean)post('iron:bridge-popup',{url:clean});});
  status.classList.add('hidden');
  window.addEventListener('message',event=>{
    if(event.source!==parent || event.origin!==parentOrigin || !event.data || event.data.type!=='iron:bridge-command')return;
    const cmd=event.data.action;
    if(cmd==='go'){const url=safeUrl(event.data.url);if(url){lastNavigated=url;session.go(url);}}
    else if(cmd==='reload')session.reload();
    else if(cmd==='back')session.back();
    else if(cmd==='forward')session.forward();
  });
  post('iron:bridge-ready');
}
boot().catch(()=>{
  status.textContent='The isolated content engine could not start. Confirm the content service, shared key and cross-site cookie support.';
  post('iron:bridge-error');
});
