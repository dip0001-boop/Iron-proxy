/* IRON Compatibility Service Worker (Scramjet 2.x integration).
 * Scramjet is third-party, AGPL-3.0-only; see THIRD_PARTY.md.
 */
importScripts('/controller/controller.sw.js');
self.addEventListener('fetch', event => {
  if (self.$scramjetController.shouldRoute(event)) {
    event.respondWith(self.$scramjetController.route(event));
  }
});
self.addEventListener('install', () => self.skipWaiting());
self.addEventListener('activate', event => event.waitUntil(self.clients.claim()));
