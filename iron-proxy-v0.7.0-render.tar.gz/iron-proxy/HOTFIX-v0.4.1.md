# IRON PROXY v0.4.1 — Browser-frame hotfix

## Root cause under investigation

The v0.4 browser shell sent `Cross-Origin-Embedder-Policy: require-corp` and
`Cross-Origin-Opener-Policy: same-origin`. Cross-origin isolation requires
embedded documents to opt into the policy. IRON Native uses an opaque-origin
iframe, and neither Native nor Scramjet was setting the required iframe
document COEP policy. This can block frame navigation and display a
`refused to connect` error even though `/healthz` responds successfully.

The v0.4.1 hotfix removes these two headers **from the shell responses only**,
leaving the existing CSP, X-Frame-Options on the top-level shell, sandbox,
login, transport restrictions, and proxy network policies unchanged.

This is a targeted fix for frame compatibility. It does not remove
site-wide authentication or guarantee YouTube playback, games, or CAPTCHA
compatibility. The two proxies have other known limitations.

## Render deployment

Upload `iron-proxy-v0.4.1-render.tar.gz` to repository root.

Build:

```bash
tar -xzf iron-proxy-v0.4.1-render.tar.gz && cd iron-proxy && npm install --omit=dev && npm run check && npm test
```

Start: `cd iron-proxy && npm start`

Keep existing `IRON_ACCESS_KEY`. `/healthz` should report `0.4.1`.

After deploying, hard-refresh IRON with Ctrl+Shift+R, create a *new* Native
tab, and load `https://example.com`. Then test Scramjet in a separate new
tab. If a stale Service Worker continues to interfere, use Chrome Site
Settings to clear this site's data; that also clears locally saved history,
bookmarks and settings and signs you out.

## Test coverage

The added regression test checks that the browser shell no longer emits the
restrictive cross-origin-isolation headers. Node syntax checks and this test
can run without dependencies; the full suite is run during the Render build.
Browser-level live iframe loading still requires your deployment test.
