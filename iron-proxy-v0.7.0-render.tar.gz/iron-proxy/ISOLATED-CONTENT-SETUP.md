# Optional isolated compatibility prototype (experimental)

This is a **two-service** design, not a one-site proxy trick. The browser shell and the lower-trust Scramjet content must use different HTTPS origins. Only use test accounts. Do not deploy to paying users until an independent review and Chromium integration tests pass.

## Primary IRON Browser service

Run the existing service as before:

- Build: `tar -xzf iron-proxy-v0.7.0-render.tar.gz && cd iron-proxy && npm install --omit=dev && npm run check && npm test`
- Start: `cd iron-proxy && npm start`
- Health: `/healthz` should show v0.7.0.
- `NODE_ENV=production`
- `IRON_ACCESS_KEY=<existing private secret>`
- `IRON_PUBLIC_ORIGIN=https://iron-proxy.onrender.com`
- `IRON_CONTENT_ORIGIN=https://iron-content.onrender.com` (replace with actual second Render URL)
- `IRON_CONTENT_SHARED_KEY=<new independent random 32+ character secret>`
- **Do not set** `IRON_ALLOW_UNISOLATED_COMPAT=1`.

## Independent IRON Content service

Create a SECOND Render Web Service on the same private GitHub repository, using a different name such as `iron-content`. This service does not have the browser's access key, search key, or private user data. Its distinct public domain must match the value above.

- Build: `tar -xzf iron-proxy-v0.7.0-render.tar.gz && cd iron-proxy && npm install --omit=dev && npm run check && npm test`
- Start: `cd iron-proxy && npm run start:content`
- Health: `/healthz` should report `IRON CONTENT` and v0.7.0.
- `NODE_ENV=production`
- `IRON_PARENT_ORIGIN=https://iron-proxy.onrender.com`
- `IRON_CONTENT_ORIGIN=https://iron-content.onrender.com`
- `IRON_CONTENT_SHARED_KEY=<exact same independent shared secret as primary>`
- **Do not add** `IRON_ACCESS_KEY` or `BRAVE_SEARCH_API_KEY` to content service.

Do not use the same domain, subdomain or local origin for both services. Both must be reachable by Chromium over HTTPS. Restart BOTH services when configuration changes. Use the browser's Settings to select `Scramjet Compatibility (separate content origin)` in a **new tab**.

## Security design

- The privileged shell signs a tab-bound, expiring nonce ticket. Its login cookie stays only on the shell host.
- The browser places the ticket in the **fragment** of the content iframe address (not transmitted by the HTTP request). The content bridge immediately clears the fragment, redeems it once, and receives an HttpOnly, Secure, SameSite=None, Partitioned cookie for the content domain.
- The content server exposes no browsing history, bookmarks, browser credentials, or management APIs. It exposes only its own Scramjet runtime/Wisp transport and a constrained login bridge. All WebSocket destinations are restricted by the Wisp configuration.
- Shell-to-content commands use explicit origin checking and `postMessage` with an exact target origin.
- Each content tab is sandboxed and can't top-navigate the privileged browser window.

**Known limitations**: third-party/partitioned cookie support differs by browser; cookie and WebSocket propagation are not proven; the content origin is itself lower-trust and can be compromised by visited sites; sessions are in-memory and do not support multiple Render instances; the standalone Scramjet engine and its license must be audited. A successful login or a working game cannot establish full security.

## Required real-browser validation

1. Confirm shell `/healthz` and content `/healthz` both healthy, no extra environment secrets exposed to content.
2. Navigate to Wikipedia through isolated mode; ensure resulting frame origin is the **content service**, not the shell.
3. From a hostile test page, attempt to read the shell DOM, cookies, and `/api/session`; all must fail by browser origin isolation.
4. Try forged or replayed bridge tickets, incorrect parent origins, bad WS origins, private IPs and internal network destinations.
5. Test that third-party cookie settings, Content-Security-Policy, Service Worker registration and WebSocket connections work in Chromium, Firefox and Safari where supported.
6. Test logout/expiry behavior, multiple tabs and 30-minute session soak. The code does not yet remotely invalidate content sessions on main-shell logout.

## Production blocking issues

Do not sell this service or advertise perfect security. Require multi-user auth, persisted revocable sessions, billing/abuse controls, a legal review of third-party licenses, operational monitoring, independent penetration tests, a lockfile/SBOM, and a restore/incident plan.
