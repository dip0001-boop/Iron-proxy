# IRON PROXY v0.7.0 — Engineering Alpha

This is a proxy-powered **browser shell**, not a native rendering engine. The native engine is original code; optional Scramjet and its associated third-party transport have their own licenses.

## Releases and setup

- **Read `RELEASE-v0.7.md` first** for implemented features, verified tests, and limitations.
- Standard Render deployment: `tar -xzf iron-proxy-v0.7.0-render.tar.gz && cd iron-proxy && npm install --omit=dev && npm run check && npm test`; start `cd iron-proxy && npm start`.
- Environment: set `NODE_ENV=production`, a private `IRON_ACCESS_KEY` of at least 16 characters; optionally `BRAVE_SEARCH_API_KEY`.
- Run `/healthz` to check the active release; test Wikipedia, GitHub and a basic HTML5 video in the browser.
- **Optional separate-origin compatibility service** is documented in `ISOLATED-CONTENT-SETUP.md` (experimental, not independently audited).

## Quality and tests

- `npm run check` — JavaScript syntax checks
- `npm test` — HTTP integration, session isolation, SSRF, caching, rewrite, socket, scheduler, ticket and regression tests
- `npm run bench` — IRON Native HTTP latency sampler (does not compare other engines)
- `npm run test:browser` — optional Playwright browser interaction check; see `scripts/compatibility-harness.mjs`

The codebase is not guaranteed to load YouTube, DRM video, complex games, GitHub sign-in or CAPTCHA-protected search. These restrictions require real tests and cannot be solved by spoofing a user agent. For commercial readiness, consult `PROFESSIONAL-ROADMAP.md` and `COMMERCIAL-READINESS.md`.
