# IRON PROXY 0.4.0 — Actual engine upgrade

## What changed

Unlike 0.3, this release introduces a second **real interception engine** rather than extending only HTML rewriting:

- **Scramjet 2.x**, pinned published browser rewriting code, its Service Worker controller and Rust/WASM rewriter
- **Wisp** as WebSocket-based TCP transport, with private/loopback IP blocking, no direct-IP or UDP connections, web-only port whitelist, and per-session WebSocket limits
- **Libcurl transport** for upstream HTTP behavior on supported websites
- **Per-frame Scramjet sessions** with URL watching, resource caching, and escaped-link handling
- **UI engine indicator** and choice between `Scramjet Compatibility` and `IRON Native`
- **IRM compatibility tests** that verify shipped npm runtime assets in the Render build

## Important compatibility and security limits

- This is a third-party engine integration. **IRON CORE Native remains original, but Compatibility Mode is Scramjet**, not a newly written competitor.
- Compatibility Mode uses `allow-same-origin` + `allow-scripts` for its iframe, as Scramjet requires. This is **not a trustworthy security boundary against a malicious website**. The lightweight native mode retains an opaque sandbox. Don't use Compatibility Mode for banking, email, or sensitive accounts. Do not expose the deployment as an anonymous open relay.
- Existing Scramjet engine versions are alpha and can be fragile. YouTube and games still require actual deployment/browser testing. DRM, anti-bot challenges and Google CAPTCHA cannot be guaranteed.
- Scramjet currently shares a controller cookie jar across frames. **Private tabs are forced to IRON Native**; do not assume Compatibility Mode sessions are per-tab isolated.
- Render's datacenter IP may trigger Google CAPTCHA or video-site challenges independent of rewriting.
- This archive does **not** bundle third-party runtime binaries; Render installs dependencies normally from npm.

## Upgrade your existing Render service

1. Upload `iron-proxy-v0.4.0-render.tar.gz` to the root of your existing GitHub repository.
2. In Render, set **Build Command** to:

   `tar -xzf iron-proxy-v0.4.0-render.tar.gz && cd iron-proxy && npm install --omit=dev && npm run check && npm test`

3. Keep **Start Command** unchanged: `cd iron-proxy && npm start`.
4. Keep the `IRON_ACCESS_KEY` environment variable; no need to create another service.
5. Check `/healthz` returns version `0.4.0`. Open a new tab to use the selected engine.
6. In Settings choose `Scramjet Compatibility` or `IRON Native`. The setting affects **new tabs**.

If the build fails while installing published packages or if `advanced.test.js` reports missing runtime assets, share the relevant build logs. The older IRON remains running unless Render successfully promotes the new deployment.

## Verification status

- JavaScript syntax checks ran locally.
- Dependency-free static tests ran locally.
- npm dependency installation and full integration tests could not be run locally in this offline environment; they are deliberately included in the Render build.
- No claim is made that YouTube, games, or Google are now fully compatible until tested.
