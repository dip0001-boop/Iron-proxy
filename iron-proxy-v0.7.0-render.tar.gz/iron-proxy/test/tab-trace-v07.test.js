import { test } from 'node:test';
import assert from 'node:assert/strict';
import { recordTabRequest, getTabTrace, clearTabTrace } from '../src/tab-trace.js';
test('tab traces retain only hostname and bounded metrics', () => {
  const tab = {};
  for (let i = 0; i < 100; i++) recordTabRequest(tab, { hostname: 'github.com', status: 404, kind: 'rewritten', milliseconds: i });
  const rows = getTabTrace(tab);
  assert.equal(rows.length, 72);
  assert.equal(rows[0].ms, 28);
  assert.deepEqual(Object.keys(rows[0]).sort(), ['aborted','host','kind','ms','status']);
  assert.equal(JSON.stringify(rows).includes('/private?key='), false);
  clearTabTrace(tab);
  assert.equal(getTabTrace(tab).length, 0);
});
