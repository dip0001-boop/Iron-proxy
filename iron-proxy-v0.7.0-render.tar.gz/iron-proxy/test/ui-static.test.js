import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';

const html = await readFile(new URL('../public/index.html', import.meta.url), 'utf8');
const js = await readFile(new URL('../public/app.js', import.meta.url), 'utf8');
test('browser shell has tabs, omnibox, bookmarks and menu controls',()=>{
  for(const id of ['tabStrip','newTabButton','addressForm','address','bookmarkCurrent','bookmarkShortcuts','browserMenu','privacyButton','progress','frames','panel','menuLogout','menuPrivate']) {
    assert.ok(html.includes('id="'+id+'"'),id+' exists');
  }
  assert.match(js, /renderBookmarksBar/);
  assert.match(js, /function openPrivateTab/);
  assert.match(js, /function reopenClosed/);
});
