import { test } from 'node:test';
import assert from 'node:assert/strict';
import { assetCacheKey, shouldCacheAsset } from '../src/cache.js';

test('asset key separates upstream user-agent, authorization and cookie contexts', () => {
  const base = assetCacheKey('a', 'https://example.org/static.js', { accept: '*/*', 'user-agent': 'UA-A' }, 'sid=a');
  assert.notEqual(base, assetCacheKey('a', 'https://example.org/static.js', { accept: '*/*', 'user-agent': 'UA-B' }, 'sid=a'));
  assert.notEqual(base, assetCacheKey('a', 'https://example.org/static.js', { accept: '*/*', 'user-agent': 'UA-A' }, 'sid=b'));
  assert.notEqual(base, assetCacheKey('a', 'https://example.org/static.js', { accept: '*/*', 'user-agent': 'UA-A' }, 'sid=a', 'https://other-site.example/'));
  assert.notEqual(base, assetCacheKey('b', 'https://example.org/static.js', { accept: '*/*', 'user-agent': 'UA-A' }, 'sid=a'));
});
test('assets marked Vary:* are never cached', () => {
  const input = { method: 'GET', status: 200, type: 'text/javascript', responseHeaders: { 'cache-control': 'public, max-age=120', vary: '*' }, requestHeaders: {} };
  assert.equal(shouldCacheAsset(input), 0);
  assert.equal(shouldCacheAsset({ ...input, responseHeaders: { ...input.responseHeaders, vary: 'Accept-Language' } }), 120);
});
