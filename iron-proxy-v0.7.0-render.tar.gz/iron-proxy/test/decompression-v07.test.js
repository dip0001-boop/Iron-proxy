import { test } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
test('large encoded proxy responses use async decompression', () => {
  const network=readFileSync(new URL('../src/network.js', import.meta.url), 'utf8');
  assert.match(network,/promisify\(gunzip\)/);
  assert.match(network,/await decoded\(/);
  assert.doesNotMatch(network,/gunzipSync|inflateSync|brotliDecompressSync/);
});
