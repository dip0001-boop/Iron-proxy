import test from 'node:test';
import assert from 'node:assert/strict';
import { compatibilityAllowed, shellHeaders, runtimeWarnings } from '../src/policy.js';
import { readFile } from 'node:fs/promises';

test('unisolated compatibility is off by default on production deployments', () => {
  assert.equal(compatibilityAllowed({ NODE_ENV: 'production' }), false);
  assert.equal(compatibilityAllowed({ NODE_ENV: 'production', IRON_ALLOW_UNISOLATED_COMPAT: 'true' }), false);
  assert.equal(compatibilityAllowed({ NODE_ENV: 'production', IRON_ALLOW_UNISOLATED_COMPAT: '1' }), true);
  assert.equal(compatibilityAllowed({ NODE_ENV: 'test' }), true);
});

test('shell CSP forbids unsafe eval in secure mode; never enables COEP require-corp', () => {
  const secure = shellHeaders({ production: true, compatibility: false });
  assert.ok(!secure['Content-Security-Policy'].includes("'unsafe-eval'"));
  assert.match(secure['Content-Security-Policy'], /object-src 'none'/);
  assert.equal(secure['X-Frame-Options'], 'DENY');
  assert.equal(secure['Referrer-Policy'], 'no-referrer');
  assert.ok(secure['Strict-Transport-Security']);
  assert.equal(secure['Cross-Origin-Embedder-Policy'], undefined);
  const dev = shellHeaders({ production: false, compatibility: true });
  assert.ok(dev['Content-Security-Policy'].includes("'unsafe-eval'"));
  assert.equal(dev['Strict-Transport-Security'], undefined);
});

test('security posture never describes unisolated advanced mode as secure', () => {
  assert.match(runtimeWarnings({ compatibility: true }).join(' '), /unsafe for sensitive logins/);
  assert.match(runtimeWarnings({ compatibility: false }).join(' '), /disabled/);
});

test('large HTML/JS rewrites run in worker with bounded queue and time limit', async () => {
  const code = await readFile(new URL('../src/rewrite-pool.js', import.meta.url), 'utf8');
  const workerCode = await readFile(new URL('../src/rewrite-worker.js', import.meta.url), 'utf8');
  assert.match(code, /MAX_WAITING_BYTES/);
  assert.match(code, /maxOldGenerationSizeMb/);
  assert.match(code, /TASK_TIMEOUT/);
  assert.match(code, /signal\?\.addEventListener\('abort'/);
  assert.match(workerCode, /rewriteHtml/);
  assert.match(workerCode, /rewriteJavaScript/);
});
