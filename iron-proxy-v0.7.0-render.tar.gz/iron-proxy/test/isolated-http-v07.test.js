import test from 'node:test';
import assert from 'node:assert/strict';
import { spawn } from 'node:child_process';
import http from 'node:http';
import { setTimeout as delay } from 'node:timers/promises';
import { createBridgeTicket } from '../src/isolated-auth.js';

const SHARED = 'integration-test-content-secret-abcdefghijklmnopqrstuvwxyz-0123456789';
const ORIGIN = 'https://content-test.example';
const PARENT = 'https://shell-test.example';
async function freePort() {
  const server = http.createServer((req,res)=>res.end());
  await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
  const port = server.address().port;
  await new Promise(resolve=>server.close(resolve));
  return port;
}
test('isolated content origin permits one-time, signed sessions only', { timeout:30000 }, async()=>{
  const port=await freePort();
  const base=`http://127.0.0.1:${port}`;
  const child=spawn(process.execPath,['src/content-server.js'],{
    cwd:process.cwd(),
    env:{...process.env, PORT:String(port), NODE_ENV:'test', IRON_CONTENT_SHARED_KEY:SHARED,
      IRON_PARENT_ORIGIN:PARENT, IRON_CONTENT_ORIGIN:ORIGIN}, stdio:'ignore'
  });
  try {
    let ready=false;
    for(let i=0;i<100;i++){try{const r=await fetch(base+'/healthz');if(r.ok){ready=true;break;}}catch{} await delay(90);}
    assert.ok(ready,'content service started');
    const publicBridge=await fetch(base+'/bridge.html');
    assert.equal(publicBridge.status,200);
    assert.match(publicBridge.headers.get('content-security-policy'), /frame-ancestors https:\/\/shell-test\.example/);
    const notAuthenticated=await fetch(base+'/api/bridge-session');
    assert.equal(notAuthenticated.status,401);
    assert.equal((await fetch(base+'/scramjet-client.js')).status,401);
    const tab='f'.repeat(48);
    const ticket=createBridgeTicket(SHARED,tab);
    const auth=()=>fetch(base+'/api/bridge-auth',{method:'POST',headers:{Origin:ORIGIN,'Content-Type':'application/json'},body:JSON.stringify({ticket})});
    const crossSite=await fetch(base+'/api/bridge-auth',{method:'POST',headers:{Origin:'https://evil.example','Content-Type':'application/json'},body:JSON.stringify({ticket})});
    assert.equal(crossSite.status,403,'cross-origin POST rejected');
    const first=await auth();
    assert.equal(first.status,200);
    const cookie=first.headers.get('set-cookie');
    assert.match(cookie,/HttpOnly; Secure; SameSite=None; Partitioned/);
    assert.equal((await auth()).status,403,'ticket replay rejected');
    const loggedIn=await fetch(base+'/api/bridge-session',{headers:{Cookie:cookie.split(';')[0]}});
    assert.equal(loggedIn.status,200);
    for(const endpoint of ['/api/tabs','/api/session','/api/search'])
      assert.equal((await fetch(base+endpoint,{headers:{Cookie:cookie.split(';')[0]}})).status,404,'content service has no privileged shell API');
  } finally {child.kill('SIGTERM');}
});
