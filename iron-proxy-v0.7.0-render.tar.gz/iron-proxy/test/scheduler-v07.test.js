import { test } from 'node:test';
import assert from 'node:assert/strict';
import { scheduled, schedulerStats } from '../src/scheduler.js';

const pause = () => new Promise(resolve => setImmediate(resolve));
function deferred() {
  let resolve;
  const promise = new Promise(r => { resolve = r; });
  return { promise, resolve };
}
test('fair scheduler isolates busy tabs and makes progress for another tab', async () => {
  const blockers = Array.from({ length: 10 }, deferred);
  const busy = blockers.map((blocker, i) => scheduled(() => blocker.promise, null, 'tab-busy'));
  await pause();
  assert.equal(schedulerStats().activeRequests, 10);
  let extraStarted = false;
  const extra = scheduled(async () => { extraStarted = true; }, null, 'tab-busy');
  await pause();
  assert.equal(extraStarted, false, 'the busy tab cannot exceed its ten slots');
  let otherStarted = false;
  await scheduled(async () => { otherStarted = true; }, null, 'tab-other');
  assert.equal(otherStarted, true, 'independent tab should be scheduled');
  assert.equal(schedulerStats().queuedRequests, 1);
  blockers[0].resolve();
  await busy[0]; await extra;
  assert.equal(extraStarted, true);
  blockers.slice(1).forEach(blocker => blocker.resolve());
  await Promise.all(busy);
  assert.equal(schedulerStats().activeRequests, 0);
});

test('aborted queued requests are removed and do not consume capacity', async () => {
  const blockers = Array.from({ length: 10 }, deferred);
  const busy = blockers.map(blocker => scheduled(() => blocker.promise, null, 'tab-cancel'));
  await pause();
  const controller = new AbortController();
  const queued = scheduled(async () => assert.fail('cancelled job must not run'), controller.signal, 'tab-cancel');
  await pause();
  assert.equal(schedulerStats().queuedRequests, 1);
  controller.abort();
  await assert.rejects(queued, e => e.name === 'AbortError');
  assert.equal(schedulerStats().queuedRequests, 0);
  blockers.forEach(blocker => blocker.resolve());
  await Promise.all(busy);
});
