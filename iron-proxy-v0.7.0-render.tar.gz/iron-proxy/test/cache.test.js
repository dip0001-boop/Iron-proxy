import test from 'node:test';
import assert from 'node:assert/strict';
import { assetCacheKey, shouldCacheAsset, readAsset, saveAsset, clearAssetCache, assetCacheStats } from '../src/cache.js';

test('static cache is isolated by tab and upstream cookie context', () => {
  clearAssetCache();
  const key = assetCacheKey('one', 'https://assets.example/app.js', { accept: 'text/javascript' }, 'a=1');
  assert.notEqual(key, assetCacheKey('two', 'https://assets.example/app.js', { accept: 'text/javascript' }, 'a=1'));
  assert.notEqual(key, assetCacheKey('one', 'https://assets.example/app.js', { accept: 'text/javascript' }, 'a=2'));
  assert.equal(readAsset(key), null);
  assert.equal(saveAsset(key, Buffer.from('JS BODY'), { 'Content-Type':'text/javascript' }, 120), true);
  assert.equal(readAsset(key).body.toString(), 'JS BODY');
  assert.equal(assetCacheStats().cacheEntries, 1);
  clearAssetCache(); assert.equal(readAsset(key),null);
});

test('cache only admits explicitly public, unpersonalized static assets', () => {
  const base = { method:'GET', status:200, type:'image/png', responseHeaders:{'cache-control':'public, max-age=120'}, requestHeaders:{} };
  assert.equal(shouldCacheAsset(base),120);
  assert.equal(shouldCacheAsset({...base,type:'text/html'}),0);
  assert.equal(shouldCacheAsset({...base,hasUpstreamCookies:true}),0);
  assert.equal(shouldCacheAsset({...base,requestHeaders:{authorization:'Bearer x'}}),0);
  assert.equal(shouldCacheAsset({...base,requestHeaders:{range:'bytes=0-10'}}),0);
  assert.equal(shouldCacheAsset({...base,responseHeaders:{'cache-control':'private, max-age=120'}}),0);
});

test('cache expires entries', () => {
  clearAssetCache();
  assert.equal(saveAsset('key',Buffer.from('AB'),{},10,10_000),true);
  assert.equal(readAsset('key',15_000).body.toString(),'AB');
  assert.equal(readAsset('key',21_000),null);
});
