import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { shellHeaders } from '../src/policy.js';

const server = await readFile(new URL('../src/server.js', import.meta.url), 'utf8');

test('browser shell uses narrow CSP but does not require cross-origin embedding isolation', () => {
  const headers = shellHeaders({ production: true, compatibility: false });
  assert.match(headers['Content-Security-Policy'], /frame-src 'self' blob:/);
  assert.equal(headers['X-Frame-Options'], 'DENY');
  assert.equal(headers['Cross-Origin-Embedder-Policy'], undefined);
  assert.equal(headers['Cross-Origin-Opener-Policy'], undefined);
  assert.match(server, /shellHeaders\(\{ production: isProd, compatibility: COMPAT_ENABLED, contentOrigin: ISOLATED_ENABLED \? CONTENT_ORIGIN : null \}\)/);
});
