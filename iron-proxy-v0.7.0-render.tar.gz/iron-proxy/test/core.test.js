import test from 'node:test';
import assert from 'node:assert/strict';
import { isPublicIp, validateTarget, browserProxyPath, decodeBrowserPath } from '../src/security.js';
import { mapUrl, rewriteHtml, rewriteCss } from '../src/rewriter.js';
const cap = 'a'.repeat(48);

test('SSRF guard blocks loopback, private, metadata and unsafe protocols', () => {
  for (const target of ['http://localhost/', 'http://127.0.0.1/', 'http://10.0.0.1/', 'http://169.254.169.254/', 'http://[::1]/', 'http://192.168.0.10/', 'http://1.1.1.1:3000/', 'file:///etc/passwd', 'http://admin:pw@example.com/']) {
    assert.throws(() => validateTarget(target), target);
  }
  assert.equal(isPublicIp('8.8.8.8'), true);
  assert.equal(isPublicIp('10.0.0.1'), false);
  assert.equal(validateTarget('https://example.com/a').href, 'https://example.com/a');
});

test('URLs roundtrip through the IRON route', () => {
  const remote = 'https://example.com/a/b?test=hello';
  const pathname = browserProxyPath(cap, remote);
  const result = decodeBrowserPath(new URL(pathname, 'https://iron.invalid').pathname, '?test=hello');
  assert.equal(result.cap, cap);
  assert.equal(result.target.href, remote);
});

test('HTML rewriting targets assets, links, forms and respects remote base', () => {
  const html = '<!doctype html><html><head><base href="https://example.com/folder/"><style>.a{background:url(/img.png)}</style></head><body><a href="next">next</a><img src="/pic.jpg"><form action="/submit"></form></body></html>';
  const rewritten = rewriteHtml(html, 'https://example.com/original', cap);
  assert.match(rewritten, /data-iron-bootstrap/);
  assert.match(rewritten, new RegExp(`/p/${cap}/https/example.com/folder/next`));
  assert.match(rewritten, new RegExp(`/p/${cap}/https/example.com/pic.jpg`));
  assert.match(rewritten, new RegExp(`/p/${cap}/https/example.com/submit`));
  assert.match(rewritten, new RegExp(`/p/${cap}/https/example.com/img.png`));
});

test('CSS rewriting only changes URL nodes', () => {
  const result = rewriteCss('.a{background:url("/hero.png");color:red}', 'https://example.com/page', cap);
  assert.match(result, /https\/example.com\/hero.png/);
  assert.match(result, /color:red/);
  assert.equal(mapUrl('data:image/png;base64,abc', 'https://example.com', cap), 'data:image/png;base64,abc');
});

test('JavaScript AST rewriting handles modules without rewriting ordinary string data', async () => {
  const { rewriteJavaScript } = await import('../src/javascript.js');
  const original = 'import helper from "/helper.mjs"; export {other} from "https://cdn.example.org/other.js"; const text="/ordinary.txt"; await import("/next.mjs");';
  const result = rewriteJavaScript(original, 'https://example.com/app.mjs', cap);
  assert.match(result, new RegExp(`/p/${cap}/https/example.com/helper.mjs`));
  assert.match(result, new RegExp(`/p/${cap}/https/cdn.example.org/other.js`));
  assert.match(result, new RegExp(`/p/${cap}/https/example.com/next.mjs`));
  assert.match(result, /"\/ordinary.txt"/);
  assert.equal(rewriteJavaScript('const = broken javascript', 'https://example.com/', cap), 'const = broken javascript');
});

test('WebSocket routes validate the original upstream destination and block private IPs', async () => {
  const { decodeSocketPath } = await import('../src/security.js');
  const route = decodeSocketPath(`/ws/${cap}/wss/echo.example.com/events`, '?room=123');
  assert.equal(route.target.href, 'wss://echo.example.com/events?room=123');
  assert.equal(route.cap, cap);
  assert.throws(() => decodeSocketPath(`/ws/${cap}/ws/127.0.0.1/socket`));
});

test('bootstrap is syntactically valid and safely encodes malicious HTML text', async () => {
  const { bootScript } = await import('../src/compat.js');
  const result = bootScript({cap,remote:'https://example.com/',ticket:'b'.repeat(32),storage:{local:{x:'</script><img src=x onerror=alert(1)>'},session:{}},cookies:''});
  assert.doesNotMatch(result, /<\/script>/i);
  assert.doesNotThrow(() => new Function(result));
});


test('HTML SRI is removed only for resources that are transformed', () => {
  const html = '<html><head><script src="/app.js" integrity="sha256-before"></script><link rel="stylesheet" href="/style.css" integrity="sha256-before"></head><body><h1>ok</h1></body></html>';
  const transformed = rewriteHtml(html, 'https://example.com/', cap);
  assert.doesNotMatch(transformed, /integrity=/);
  assert.match(transformed, /data-iron-bootstrap/);
});

test('bundler new URL asset resolution uses the original module origin', async () => {
  const { rewriteJavaScript } = await import('../src/javascript.js');
  const input = 'const sprite = new URL("./textures/hero.png", import.meta.url); const ordinary = "hello";';
  const transformed = rewriteJavaScript(input, 'https://game.example.com/static/app.js', cap);
  assert.match(transformed, new RegExp(`/p/${cap}/https/game.example.com/static/textures/hero.png`));
  assert.match(transformed, /"hello"/);
});
