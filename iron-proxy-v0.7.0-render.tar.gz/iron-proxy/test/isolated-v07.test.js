import { test } from 'node:test';
import assert from 'node:assert/strict';
import { createBridgeTicket, verifyBridgeTicket, validBridgeOrigin } from '../src/isolated-auth.js';
import { readFileSync } from 'node:fs';
const key='IRON testing shared key should be very long, separate from all access keys';
const cap='a'.repeat(48);
test('isolated engine tickets are authenticated, one-use, and short-lived', () => {
  const timestamp=1_700_000_000_000;
  const ticket=createBridgeTicket(key,cap,timestamp);
  const seen=new Map();
  assert.equal(verifyBridgeTicket(key,ticket,seen,timestamp+200)?.tabId,cap);
  assert.equal(verifyBridgeTicket(key,ticket,seen,timestamp+200),null,'replay rejected');
  assert.equal(verifyBridgeTicket(key+'x',ticket,new Map(),timestamp),null,'wrong key rejected');
  assert.equal(verifyBridgeTicket(key,ticket,new Map(),timestamp+91_000),null,'expired ticket rejected');
  assert.equal(verifyBridgeTicket(key,ticket+'x',new Map(),timestamp),null,'signature manipulation rejected');
});
test('isolated origin must be exact HTTPS origin', () => {
  assert.equal(validBridgeOrigin('https://iron-content.onrender.com'),true);
  for (const bad of ['http://example.com','https://example.com/path','https://example.com/','javascript:alert(1)','https://user:pass@example.com']) assert.equal(validBridgeOrigin(bad),false);
});
test('content service has no shell password, management routes or broad frame ancestor permissions', () => {
  const src=readFileSync(new URL('../src/content-server.js',import.meta.url),'utf8');
  assert.doesNotMatch(src,/process\.env\.IRON_ACCESS_KEY/);
  assert.match(src,/frame-ancestors/);
  assert.match(src,/SameSite=None; Partitioned/);
  assert.match(src,/verifyBridgeTicket/);
});
test('privileged shell CSP only permits the configured content frame origin', async () => {
  const { shellHeaders } = await import('../src/policy.js');
  const isolated = shellHeaders({production:true,compatibility:false,contentOrigin:'https://iron-content.onrender.com'});
  assert.match(isolated['Content-Security-Policy'], /frame-src 'self' blob: https:\/\/iron-content\.onrender\.com/);
  assert.doesNotMatch(isolated['Content-Security-Policy'], /script-src[^;]*'unsafe-eval'/);
  const safe = shellHeaders({ production:true, compatibility:false });
  assert.doesNotMatch(safe['Content-Security-Policy'], /iron-content\.onrender\.com/);
});
