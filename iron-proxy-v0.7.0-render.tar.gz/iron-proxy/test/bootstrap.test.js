// Dependency-free smoke checks that can run even without npm packages.
import test from 'node:test';
import assert from 'node:assert/strict';
import { bootScript } from '../src/compat.js';

test('bootScript emits syntactically valid client code', () => {
  const script = bootScript({cap:'a'.repeat(48),remote:'https://example.com/',ticket:'b'.repeat(32),cookies:'hello=world',storage:{local:{level:'2'},session:{}}});
  assert.doesNotThrow(() => new Function(script));
  assert.match(script,/class IronWebSocket extends NativeWS/);
});
test('bootScript encodes hostile script-end text as a JS escape', () => {
  const script = bootScript({cap:'a'.repeat(48),remote:'https://example.com/',ticket:'b'.repeat(32),cookies:'',storage:{local:{test:'</script><img src=x>'},session:{}}});
  assert.doesNotMatch(script, /<\/script>/i);
  assert.match(script,/\\u003c/);
});
