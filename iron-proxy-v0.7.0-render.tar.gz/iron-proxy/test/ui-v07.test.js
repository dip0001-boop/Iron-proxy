import { test } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
test('browser reports slow site loads and exposes fair queue data', () => {
  const js = readFileSync(new URL('../public/app.js', import.meta.url), 'utf8');
  assert.match(js, /25000/);
  assert.match(js, /LONG PAGE LOAD/);
  assert.match(js, /maxConcurrentPerTab/);
});
test('no stale release version appears in browser shell', () => {
  const html = readFileSync(new URL('../public/index.html', import.meta.url), 'utf8');
  assert.doesNotMatch(html, /0\.6(?:\.0)?/);
  assert.match(html, /0\.7\.0/);
});
