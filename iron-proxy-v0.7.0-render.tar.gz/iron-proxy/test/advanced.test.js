import test from 'node:test';
import assert from 'node:assert/strict';
import http from 'node:http';
import { readFile } from 'node:fs/promises';

test('Scramjet runtime ships actual JavaScript and wasm assets', { timeout: 12000 }, async () => {
  const { serveAdvancedAsset } = await import('../src/advanced.js');
  const server = http.createServer(async (req,res) => {
    const path = new URL(req.url, 'http://localhost').pathname;
    if (!await serveAdvancedAsset(path, req, res)) res.writeHead(404).end('missing');
  });
  await new Promise(resolve => server.listen(0,'127.0.0.1',resolve));
  try {
    const base = `http://127.0.0.1:${server.address().port}`;
    for(const resource of ['/scram/scramjet.js','/scram/scramjet.wasm','/controller/controller.api.js','/controller/controller.sw.js','/controller/controller.inject.js','/utils/scramjet-utils.js','/libcurl/index.mjs']) {
      const response = await fetch(base + resource);
      assert.equal(response.status, 200, `${resource}: must be served by installed package`);
      assert.ok((await response.arrayBuffer()).byteLength > 10, `${resource}: must contain data`);
    }
    assert.equal((await fetch(base + '/controller/../src/advanced.js')).status, 404);
    assert.equal((await fetch(base + '/scram/this-does-not-exist.js')).status, 404);
  } finally { await new Promise(resolve => server.close(resolve)); }
});

test('untrusted remote websocket origin is denied before opening a tunnel', async () => {
  const { routeWisp } = await import('../src/advanced.js');
  let rejected = false;
  const socket = { destroy(){ rejected = true; } };
  assert.equal(routeWisp({url:'/wisp/', headers:{host:'iron.test',origin:'https://attacker.test'}},socket,Buffer.alloc(0),()=>true),true);
  assert.equal(rejected,true);
});

test('real service-worker script routes through Scramjet controller', async () => {
  const sw = await readFile(new URL('../public/sw.js',import.meta.url),'utf8');
  assert.match(sw,/importScripts\('\/controller\/controller\.sw\.js'\)/);
  assert.match(sw,/shouldRoute\(event\)/);
  assert.match(sw,/route\(event\)/);
});
