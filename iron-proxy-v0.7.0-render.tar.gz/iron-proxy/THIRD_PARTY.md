# Third-party technology and attribution

IRON Native (`src/network.js`, `src/rewriter.js`, `src/javascript.js`) is the original IRON implementation. It is **not** Scramjet, Rammerhead, or Ultraviolet.

IRON Compatibility Mode is powered by the real Scramjet 2.x runtime, its controller and the Wisp transport. We do not rename or claim ownership of these components. The runtime is installed from npm during `npm install` and served unmodified from its published package files. Packages and pinned versions are in `package.json`.

* Scramjet: https://github.com/MercuryWorkshop/scramjet — AGPL-3.0-only
* Scramjet controller and utilities: distributed by Mercury Workshop; verify each published package license
* libcurl transport: Mercury Workshop; verify its published package license and transitive libcurl notices
* wisp-js: https://github.com/MercuryWorkshop/wisp-js — LGPL-3.0
* Ultraviolet: https://github.com/titaniumnetwork-dev/Ultraviolet — studied as a reference, not bundled
* Rammerhead: https://github.com/binary-person/rammerhead — studied as a reference, not bundled

If you distribute or network-deploy modified AGPL-licensed code, meet the license's source availability obligations. You should provide the exact source for any modifications to the Scramjet component. Do not remove their notices. For safety, a separate content-origin service is recommended before using Compatibility Mode to open untrusted sites with sensitive accounts.
