/**
 * Fair, cancellation-aware scheduler for a memory-constrained shared proxy.
 * Bounded global and per-tab concurrency; pending queues rotate by owner so a
 * single high-fanout page cannot indefinitely starve other browsing tabs.
 * No personal URLs, addresses, or headers are retained here.
 */
const MAX_ACTIVE = 24;
const MAX_PER_TAB = 10;
const MAX_WAITING = 96;
const MAX_WAITING_PER_TAB = 32;
let active = 0;
let cancelled = 0;
let rejected = 0;
const activeByOwner = new Map();
const queues = new Map();
let queuedCount = 0;
let roundRobin = [];
let cursor = 0;

function exception(message, statusCode, name = 'Error') {
  return Object.assign(new Error(message), { name, statusCode });
}
function cancelException() { return exception('Request cancelled', 499, 'AbortError'); }
function capacityException() { rejected++; return exception('Network queue capacity reached', 503); }
function ownerCount(owner) { return activeByOwner.get(owner) || 0; }
function stopListening(entry) {
  if (entry.signal && entry.abortListener) entry.signal.removeEventListener('abort', entry.abortListener);
}
function forgetOwner(owner) {
  const queue = queues.get(owner);
  if (queue?.length) return;
  queues.delete(owner);
  const index = roundRobin.indexOf(owner);
  if (index >= 0) {
    roundRobin.splice(index, 1);
    if (cursor > index) cursor--;
    if (cursor >= roundRobin.length) cursor = 0;
  }
}
function nextWaiter() {
  for (let visited = 0; visited < roundRobin.length;) {
    if (!roundRobin.length) return null;
    const index = cursor % roundRobin.length;
    const owner = roundRobin[index];
    cursor = (index + 1) % roundRobin.length;
    visited++;
    if (ownerCount(owner) >= MAX_PER_TAB) continue;
    const queue = queues.get(owner);
    if (!queue?.length) { forgetOwner(owner); visited--; continue; }
    const waiter = queue.shift();
    queuedCount--;
    forgetOwner(owner);
    if (waiter.signal?.aborted) {
      cancelled++;
      stopListening(waiter);
      waiter.reject(cancelException());
      continue;
    }
    return waiter;
  }
  return null;
}
function pump() {
  while (active < MAX_ACTIVE && queuedCount > 0) {
    const entry = nextWaiter();
    if (!entry) break;
    stopListening(entry);
    active++;
    activeByOwner.set(entry.owner, ownerCount(entry.owner) + 1);
    entry.resolve();
  }
}
export async function scheduled(run, signal = null, owner = 'default') {
  if (signal?.aborted) throw cancelException();
  owner = typeof owner === 'string' && owner.length <= 100 ? owner : 'default';
  if (active >= MAX_ACTIVE || ownerCount(owner) >= MAX_PER_TAB || queuedCount > 0) {
    if (queuedCount >= MAX_WAITING || (queues.get(owner)?.length || 0) >= MAX_WAITING_PER_TAB) throw capacityException();
    await new Promise((resolve, reject) => {
      const entry = { resolve, reject, owner, signal, abortListener: null };
      entry.abortListener = () => {
        const queue = queues.get(owner);
        const index = queue?.indexOf(entry) ?? -1;
        if (index === -1) return;
        queue.splice(index, 1);
        queuedCount--; cancelled++;
        stopListening(entry);
        forgetOwner(owner);
        reject(cancelException());
      };
      if (signal) signal.addEventListener('abort', entry.abortListener, { once: true });
      if (signal?.aborted) { stopListening(entry); reject(cancelException()); return; }
      if (!queues.has(owner)) { queues.set(owner, []); roundRobin.push(owner); }
      queues.get(owner).push(entry);
      queuedCount++;
      pump();
    });
  } else {
    active++;
    activeByOwner.set(owner, ownerCount(owner) + 1);
  }
  try { return await run(); }
  finally {
    active--;
    const remainder = ownerCount(owner) - 1;
    if (remainder <= 0) activeByOwner.delete(owner);
    else activeByOwner.set(owner, remainder);
    pump();
  }
}
export function schedulerStats() {
  return {
    activeRequests: active,
    queuedRequests: queuedCount,
    busyTabs: activeByOwner.size,
    cancelledQueuedRequests: cancelled,
    rejectedQueuedRequests: rejected,
    maxConcurrentRequests: MAX_ACTIVE,
    maxConcurrentPerTab: MAX_PER_TAB
  };
}
