/** Safe, descriptive in-frame failure pages for native IRON navigation. */
function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
}
export function siteErrorHtml(status, code, detail) {
  const cleanCode = escapeHtml(String(code).slice(0,64));
  const cleanDetail = escapeHtml(String(detail).slice(0,200));
  return `<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>IRON · Navigation failed</title><style>*{box-sizing:border-box}body{margin:0;background:#0a1220;color:#e8f1ff;font:15px/1.6 system-ui,-apple-system,sans-serif;min-height:100vh;display:grid;place-items:center;padding:20px}.card{width:min(620px,100%);border:1px solid #344b66;border-radius:18px;background:#142238;padding:30px;box-shadow:0 22px 70px #0006}.mark{color:#70b8ff;font-size:28px;font-weight:900}h1{font-size:24px;line-height:1.2;margin:12px 0}p{color:#adc0d7}code{color:#9fd0ff;background:#0d1a2d;border-radius:6px;padding:3px 7px;font-size:12px}.buttons{display:flex;gap:10px;flex-wrap:wrap;margin-top:20px}button{border:1px solid #4d84b8;border-radius:9px;padding:10px 16px;background:#215789;color:#fff;font-weight:700;cursor:pointer}.secondary{background:#1e2f45}</style></head><body><main class="card"><div class="mark">◈ IRON NETWORK</div><h1>This page couldn't load</h1><p>${cleanDetail}</p><p><code>${Number(status) || 502} · ${cleanCode}</code></p><p>The server is still running. This failure may be specific to the website or one of IRON's rewriting limitations.</p><div class="buttons"><button onclick="location.reload()">Retry page</button></div></main></body></html>`;
}
export function siteErrorResponse(res, status, code, detail) {
  if (res.headersSent || res.destroyed) return false;
  res.writeHead(status, {
    'Content-Type':'text/html; charset=utf-8',
    'Cache-Control':'no-store',
    'Access-Control-Allow-Origin':'*',
    'X-Iron-Error':String(code).replace(/[^A-Z_]/g,'').slice(0,64),
    'X-Content-Type-Options':'nosniff'
  });
  res.end(siteErrorHtml(status,code,detail));
  return true;
}
