/** Low-overhead, URL-free event-loop and memory diagnostics. */
import { monitorEventLoopDelay } from 'node:perf_hooks';
const loop = monitorEventLoopDelay({ resolution: 50 });
loop.enable();
let previousCPU = process.cpuUsage();
let previousTime = process.hrtime.bigint();
let latestCPU = null;
function milliseconds(nanoseconds) { return Number.isFinite(nanoseconds) ? +(nanoseconds / 1e6).toFixed(2) : null; }
export function runtimeHealth() {
  const now = process.hrtime.bigint();
  const elapsedUs = Number(now - previousTime) / 1000;
  const total = process.cpuUsage();
  const usedUs = (total.user - previousCPU.user) + (total.system - previousCPU.system);
  if (elapsedUs > 100_000) {
    // CPU percentage of one full core, not a whole machine. Exceeds 100
    // on processes with multiple busy threads.
    latestCPU = +Math.max(0, 100 * usedUs / elapsedUs).toFixed(1);
    previousCPU = total; previousTime = now;
  }
  const rss = process.memoryUsage();
  return {
    heapUsedMB: +(rss.heapUsed / 1048576).toFixed(1),
    residentMemoryMB: +(rss.rss / 1048576).toFixed(1),
    eventLoopMeanMs: milliseconds(loop.mean),
    eventLoopP95Ms: milliseconds(loop.percentile(95)),
    cpuOneCorePercent: latestCPU
  };
}
