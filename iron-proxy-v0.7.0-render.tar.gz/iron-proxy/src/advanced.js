/**
 * IRON COMPAT: optional, transparently attributed Scramjet 2.x runtime.
 * IRON's original native proxy is in network.js / rewriter.js.
 * The third-party browser rewrite engine is served unchanged from npm packages.
 * Package versions are locked in package.json, not downloaded at runtime.
 */
import { createRequire } from 'node:module';
import path from 'node:path';
import { readFile, stat } from 'node:fs/promises';
import { scramjetPath } from '@mercuryworkshop/scramjet/path';
import { server as wisp, logging } from '@mercuryworkshop/wisp-js/server';

const require = createRequire(import.meta.url);
const moduleDirectory = (specifier) => path.dirname(require.resolve(specifier));
const mounts = [
  ['/scram/', scramjetPath],
  ['/controller/', moduleDirectory('@mercuryworkshop/scramjet-controller')],
  ['/utils/', moduleDirectory('@mercuryworkshop/scramjet-utils')],
  ['/libcurl/', moduleDirectory('@mercuryworkshop/libcurl-transport')]
];
const mime = {
  '.js': 'text/javascript; charset=utf-8', '.mjs': 'text/javascript; charset=utf-8',
  '.wasm': 'application/wasm', '.json': 'application/json; charset=utf-8',
  '.css': 'text/css; charset=utf-8', '.map': 'application/json; charset=utf-8'
};

// Host configuration limits the transport to web browsing, not arbitrary TCP.
// Wisp-js rejects direct IPs, private/loopback IPs and disallowed ports.
wisp.options.allow_direct_ip = false;
wisp.options.allow_private_ips = false;
wisp.options.allow_loopback_ips = false;
wisp.options.allow_udp_streams = false;
wisp.options.allow_tcp_streams = true;
wisp.options.port_whitelist = [80, 443];
wisp.options.stream_limit_total = 48;
wisp.options.stream_limit_per_host = 12;
wisp.options.parse_real_ip = false;
wisp.options.hostname_blacklist = [
  /^metadata\.google\.internal\.?$/i,
  /^(?:localhost|localhost\.localdomain|[^.]+\.localhost)\.?$/i,
  /^(?:[^.]+\.)*(?:internal|local|home|lan)\.?$/i
];
try { logging.set_level(logging.WARN); } catch { /* optional log-level API */ }

/** Serve ONLY files under known installed package directories. */
export async function serveAdvancedAsset(pathname, req, res) {
  const mount = mounts.find(([urlPrefix]) => pathname.startsWith(urlPrefix));
  if (!mount) return false;
  if (req.method !== 'GET' && req.method !== 'HEAD') {
    res.writeHead(405, { Allow: 'GET, HEAD' }).end(); return true;
  }
  const [prefix, dirname] = mount;
  let file;
  try {
    const raw = pathname.slice(prefix.length);
    const segments = raw.split('/').map(x => decodeURIComponent(x));
    if (!segments.length || segments.some(s => !s || s === '.' || s === '..' || s.includes('\\') || s.includes('\0') || s.includes('/'))) throw new Error('Bad path');
    const root = path.resolve(dirname);
    file = path.resolve(root, ...segments);
    if (!file.startsWith(root + path.sep)) throw new Error('Outside root');
    if (!(await stat(file)).isFile()) throw new Error('Not file');
    const data = await readFile(file);
    const headers = {
      'Content-Type': mime[path.extname(file)] || 'application/octet-stream',
      'X-Content-Type-Options': 'nosniff',
      'Cache-Control': 'private, max-age=3600',
      'Cross-Origin-Resource-Policy': 'same-origin'
    };
    res.writeHead(200, headers);
    res.end(req.method === 'HEAD' ? undefined : data);
  } catch {
    res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' }).end('Runtime asset not found');
  }
  return true;
}

const connections = new Map();
export function routeWisp(req, socket, head, isAuthenticated) {
  let pathname;
  try { pathname = new URL(req.url, 'http://localhost.invalid').pathname; }
  catch { socket.destroy(); return false; }
  if (pathname !== '/wisp/') return false;
  const requestOrigin = req.headers.origin || '';
  // Disallow cross-site WebSocket hijacking and anonymous relay use.
  let validOrigin = false;
  try {
    const o = new URL(requestOrigin);
    validOrigin = (o.protocol === 'https:' || o.protocol === 'http:') && o.host === req.headers.host;
  } catch { /* reject */ }
  if (!isAuthenticated(req) || !validOrigin) { socket.destroy(); return true; }
  const identity = String(req.headers.cookie || '').match(/(?:^|;\s*)(?:iron_session|iron_content_session)=([^;]+)/)?.[1] || ''; 
  const count = connections.get(identity) || 0;
  if (count >= 4) { socket.destroy(); return true; }
  connections.set(identity, count + 1);
  let released = false;
  const release = () => {
    if (released) return;
    released = true;
    const left = (connections.get(identity) || 1) - 1;
    if (left <= 0) connections.delete(identity); else connections.set(identity, left);
  };
  socket.once('close', release);
  socket.once('error', release);
  req.url = pathname;
  try { wisp.routeRequest(req, socket, head); }
  catch { release(); socket.destroy(); }
  return true;
}

export function advancedStats() {
  return { wispConnections: [...connections.values()].reduce((a,b) => a+b,0) };
}
