/** Short-lived signed navigation tickets shared between the privileged shell
 * and an independent, less-trusted content service. HMAC key is never sent to
 * the browser. A ticket can be consumed only once and expires within 90 s.
 */
import { createHmac, randomBytes, timingSafeEqual } from 'node:crypto';
const TTL = 90_000;
function validKey(key) { return typeof key === 'string' && Buffer.byteLength(key) >= 32; }
function mac(key, payload) { return createHmac('sha256', key).update(payload).digest('base64url'); }
export function createBridgeTicket(key, tabId, now = Date.now()) {
  if (!validKey(key)) throw new Error('IRON_CONTENT_SHARED_KEY needs 32+ characters');
  if (!/^[a-f0-9]{48}$/.test(tabId)) throw new Error('Invalid tab identifier');
  const payload = Buffer.from(JSON.stringify({ tabId, expires:now+TTL, nonce:randomBytes(16).toString('hex') })).toString('base64url');
  return payload + '.' + mac(key,payload);
}
export function verifyBridgeTicket(key, ticket, seen, now = Date.now()) {
  if (!validKey(key) || typeof ticket !== 'string' || ticket.length > 700) return null;
  const parts = ticket.split('.');
  if (parts.length !== 2 || !/^[\w-]+$/.test(parts[0]) || !/^[\w-]+$/.test(parts[1])) return null;
  const received = Buffer.from(parts[1], 'base64url');
  const expected = Buffer.from(mac(key,parts[0]), 'base64url');
  if (received.length !== expected.length || !timingSafeEqual(received,expected)) return null;
  try {
    const data = JSON.parse(Buffer.from(parts[0], 'base64url').toString('utf8'));
    if (!/^[a-f0-9]{48}$/.test(data.tabId) || !/^[a-f0-9]{32}$/.test(data.nonce)) return null;
    if (!Number.isSafeInteger(data.expires) || data.expires <= now || data.expires > now+TTL) return null;
    const existing = seen.get(data.nonce);
    if (existing && existing > now) return null;
    seen.set(data.nonce, data.expires);
    // Bounded nonce memory (especially important if the service is public).
    if (seen.size > 2000) for (const [nonce, expires] of seen) if (expires <= now || seen.size > 1800) seen.delete(nonce);
    return { tabId:data.tabId, expires:data.expires };
  } catch { return null; }
}
export function validBridgeOrigin(value) {
  try {
    const u = new URL(value);
    return u.origin === value && u.protocol === 'https:' && !u.username && !u.password;
  } catch { return false; }
}
