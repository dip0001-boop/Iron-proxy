/** Authenticated, rate-limited external origin health probe, not an open relay. */
import { Agent, request } from 'undici';
import { pinnedPublicLookup, validateTarget } from './security.js';

const probeAgent = new Agent({
  connections: 2,
  keepAliveTimeout: 5000,
  connect: { timeout: 4000, lookup: pinnedPublicLookup },
  headersTimeout: 5000,
  bodyTimeout: 5000
});

export async function probeSite(raw) {
  const url = validateTarget(raw);
  const start = performance.now();
  const abort = new AbortController();
  const timeout = setTimeout(() => abort.abort(), 6500);
  try {
    const r = await request(url, {
      dispatcher: probeAgent, method: 'HEAD', maxRedirections: 0,
      headers: { accept: 'text/html, */*', 'accept-encoding': 'identity' },
      signal: abort.signal
    });
    r.body.on('error', () => {});
    r.body.destroy();
    const milliseconds = Math.round(performance.now() - start);
    const redirected = r.statusCode >= 300 && r.statusCode < 400 && !!r.headers.location;
    let redirect = null;
    if (redirected) {
      try { redirect = validateTarget(new URL(String(r.headers.location), url.href).href).origin; }
      catch { redirect = '(blocked destination)'; }
    }
    return {
      reachable: true, status: r.statusCode, milliseconds,
      responseType: String(r.headers['content-type'] || '').split(';')[0].slice(0,80),
      redirectOrigin: redirect,
      explanation: r.statusCode === 405 ? 'HEAD not supported; the site may still work with GET' :
        r.statusCode === 403 || r.statusCode === 429 ? 'The destination denied or rate-limited the request' :
        r.statusCode >= 500 ? 'The destination returned a server error' :
        redirected ? 'The destination returned a redirect' : 'Destination responded'
    };
  } catch (error) {
    const e = String(error?.code || error?.cause?.code || error?.name || 'CONNECT_ERROR');
    return { reachable: false, milliseconds: Math.round(performance.now() - start),
      error: ['UND_ERR_CONNECT_TIMEOUT','UND_ERR_HEADERS_TIMEOUT','AbortError'].includes(e) ? 'TIMEOUT' :
        /cert|tls|ssl/i.test(e) ? 'TLS_ERROR' : 'CONNECTION_FAILED',
      explanation: 'IRON could not complete the connection check. This does not prove the website is down.' };
  } finally { clearTimeout(timeout); }
}
export async function closeProbe() { await probeAgent.close(); }
