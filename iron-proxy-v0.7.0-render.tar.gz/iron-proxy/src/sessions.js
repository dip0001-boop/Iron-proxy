import { randomBytes, timingSafeEqual } from 'node:crypto';
import { CookieJar } from 'tough-cookie';

export const randomSecret = (bytes = 24) => randomBytes(bytes).toString('hex');
export function equalSecret(a, b) {
  if (typeof a !== 'string' || typeof b !== 'string') return false;
  const ab = Buffer.from(a); const bb = Buffer.from(b);
  return ab.length === bb.length && timingSafeEqual(ab, bb);
}

const LOGIN_TTL = 12 * 60 * 60 * 1000;
const TAB_TTL = 2 * 60 * 60 * 1000;
const sessions = new Map();
const caps = new Map();

export function createLogin() {
  const token = randomSecret(32);
  sessions.set(token, { created: Date.now(), tabs: new Set() });
  return token;
}
export function getLogin(token) {
  const s = sessions.get(token);
  if (!s) return null;
  if (Date.now() - s.created > LOGIN_TTL) { logout(token); return null; }
  return s;
}
export function logout(token) {
  const s = sessions.get(token);
  if (!s) return;
  for (const cap of [...s.tabs]) deleteTab(cap, token);
  sessions.delete(token);
}
export function createTab(token) {
  const session = getLogin(token);
  if (!session) throw new Error('Login required');
  if (session.tabs.size >= 12) throw new Error('Maximum 12 tabs');
  const cap = randomSecret();
  const tab = { cap, owner: token, cookies: new CookieJar(), created: Date.now(), accessed: Date.now(), requests: 0, storage: new Map(), tickets: new Map(), sockets: new Set() };
  caps.set(cap, tab);
  session.tabs.add(cap);
  return { id: cap, cap };
}
export function getCap(cap) {
  const tab = caps.get(cap);
  if (!tab) return null;
  if (Date.now() - tab.accessed > TAB_TTL || !getLogin(tab.owner)) {
    deleteTab(cap);
    return null;
  }
  tab.accessed = Date.now();
  return tab;
}
export function deleteTab(cap, token) {
  const tab = caps.get(cap);
  if (!tab || (token && tab.owner !== token)) return false;
  for (const socket of tab.sockets) { try { socket.terminate(); } catch {} }
  tab.sockets.clear();
  tab.tickets.clear();
  tab.storage.clear();
  caps.delete(cap);
  sessions.get(tab.owner)?.tabs.delete(cap);
  return true;
}
export function clearTabs(token) {
  const session = getLogin(token);
  if (!session) return;
  for (const cap of [...session.tabs]) deleteTab(cap, token);
}
export function diagnostics() {
  return { logins: sessions.size, activeTabs: caps.size, uptimeSeconds: Math.round(process.uptime()), memoryMB: Math.round(process.memoryUsage().rss / 1048576) };
}
export function cleanup() {
  for (const token of [...sessions.keys()]) getLogin(token);
  for (const cap of [...caps.keys()]) getCap(cap);
}

// Short-lived document-scoped ticket: a webpage cannot write another original
// origin's virtual state merely by possessing its tab capability URL.
export function documentState(tab, url) {
  const now = Date.now();
  for (const [key, val] of tab.tickets) if (val.expires < now) tab.tickets.delete(key);
  if (tab.tickets.size >= 40) tab.tickets.delete(tab.tickets.keys().next().value);
  const ticket = randomSecret(16);
  tab.tickets.set(ticket, { origin: url.origin, url: url.href, expires: now + 30 * 60_000 });
  let data = tab.storage.get(url.origin);
  if (!data) { data = { local: new Map(), session: new Map() }; tab.storage.set(url.origin, data); }
  return { ticket, storage: { local: Object.fromEntries(data.local), session: Object.fromEntries(data.session) } };
}
export async function writeDocumentState(tab, ticket, payload) {
  const doc = tab.tickets.get(ticket);
  if (!doc || doc.expires < Date.now()) return false;
  if (!payload || typeof payload !== 'object') return false;
  if (payload.kind === 'cookie') {
    const value = payload.value;
    if (typeof value !== 'string' || value.length > 4000) return false;
    // Script-written cookies cannot create HttpOnly cookies.
    const safe = value.split(';').filter(part => !/^\s*httponly\s*$/i.test(part)).join(';');
    try { await tab.cookies.setCookie(safe, doc.url, { ignoreError: true }); } catch { return false; }
    return true;
  }
  if (!['local', 'session'].includes(payload.kind)) return false;
  let perOrigin = tab.storage.get(doc.origin);
  if (!perOrigin) { perOrigin = { local:new Map(), session:new Map() }; tab.storage.set(doc.origin, perOrigin); }
  const target = perOrigin[payload.kind];
  if (payload.op === 'clear') { target.clear(); return true; }
  if (typeof payload.key !== 'string' || payload.key.length > 1024) return false;
  if (payload.op === 'remove') { target.delete(payload.key); return true; }
  if (payload.op !== 'set' || typeof payload.value !== 'string' || payload.value.length > 64_000) return false;
  const total = [...target.entries()].filter(([key]) => key !== payload.key).reduce((n,[k,v]) => n + k.length + v.length, 0);
  if (total + payload.key.length + payload.value.length > 200_000) return false;
  target.set(payload.key, payload.value);
  return true;
}
