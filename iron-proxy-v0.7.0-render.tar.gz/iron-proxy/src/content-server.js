/**
 * IRON CONTENT EDGE — runs on a DIFFERENT origin / Render service.
 * This service has NO access to IRON_ACCESS_KEY, shell cookies, tab history,
 * search API keys, or shell management endpoints.
 * All embedded sites may compromise the content origin, so grant that origin
 * no other privileges. The shared ticket-signing key is server-side only.
 */
import http from 'node:http';
import { readFile } from 'node:fs/promises';
import { randomBytes } from 'node:crypto';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { serveAdvancedAsset, routeWisp } from './advanced.js';
import { verifyBridgeTicket, validBridgeOrigin } from './isolated-auth.js';
const PORT = Number(process.env.PORT || 10000);
const KEY = process.env.IRON_CONTENT_SHARED_KEY;
const PARENT = process.env.IRON_PARENT_ORIGIN;
const SELF = process.env.IRON_CONTENT_ORIGIN;
if (!KEY || Buffer.byteLength(KEY)<32 || !validBridgeOrigin(PARENT) || !validBridgeOrigin(SELF) || PARENT === SELF) {
  console.error('IRON Content requires 32+ byte shared key and distinct HTTPS parent/content origin settings');
  process.exit(1);
}
const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)),'../public');
const seen = new Map();
const sessions = new Map();
const limit = new Map();
const COOKIE = 'iron_content_session';
const MAX_SESSION_MS = 60 * 60 * 1000;
const headers = { 'X-Content-Type-Options':'nosniff', 'Referrer-Policy':'no-referrer', 'Cache-Control':'no-store' };
function response(res, status, object) {res.writeHead(status,{...headers,'Content-Type':'application/json'});res.end(JSON.stringify(object));}
function cookie(req) {const m=String(req.headers.cookie||'').match(/(?:^|;\s*)iron_content_session=([a-f0-9]{64})(?:;|$)/);return m?.[1];}
function authenticated(req) {const id=cookie(req);const expiry=sessions.get(id);return !!expiry && expiry>Date.now();}
const server=http.createServer(async(req,res)=>{
  try {
    const url = new URL(req.url, 'https://internal.invalid');
    if(url.pathname==='/healthz')return response(res,200,{ok:true,name:'IRON CONTENT',version:'0.7.0'});
    if(url.pathname==='/bridge.html' && req.method==='GET') {
      const html=await readFile(path.join(ROOT,'isolated-bridge.html'));
      res.writeHead(200,{...headers,'Content-Type':'text/html; charset=utf-8',
        'Content-Security-Policy':"default-src 'self'; script-src 'self' blob: 'wasm-unsafe-eval' 'unsafe-eval'; connect-src 'self' ws: wss:; worker-src 'self' blob:; frame-src 'self' blob:; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob:; object-src 'none'; base-uri 'none'; frame-ancestors "+PARENT});
      return res.end(html);
    }
    if(url.pathname==='/isolated-bridge.js' && req.method==='GET') {
      const js=await readFile(path.join(ROOT,'isolated-bridge.js'));
      res.writeHead(200,{...headers,'Content-Type':'text/javascript; charset=utf-8'});
      return res.end(js);
    }
    if(url.pathname==='/api/bridge-auth' && req.method==='POST') {
      if(req.headers.origin!==SELF)return response(res,403,{error:'Origin rejected'});
      const ip=req.socket.remoteAddress||'unknown';const count=limit.get(ip)||{n:0,until:Date.now()+60_000};
      if(count.until<Date.now()){count.n=0;count.until=Date.now()+60_000;}count.n++;limit.set(ip,count);
      if(count.n>60)return response(res,429,{error:'Too many attempts'});
      let total=0,chunks=[];
      for await(const chunk of req){total+=chunk.length;if(total>1500)return response(res,413,{error:'Too large'});chunks.push(chunk);}
      let token;try{token=JSON.parse(Buffer.concat(chunks).toString('utf8')).ticket;}catch{return response(res,400,{error:'Invalid JSON'});}
      const info=verifyBridgeTicket(KEY,token,seen);
      if(!info)return response(res,403,{error:'Invalid or expired ticket'});
      const id=randomBytes(32).toString('hex'); sessions.set(id,Date.now()+MAX_SESSION_MS);
      // Partitioned cookie supports isolated third-party frames in Chromium;
      // browsers without partitioned-cookie support may not support this mode.
      res.setHeader('Set-Cookie',`${COOKIE}=${id}; Path=/; HttpOnly; Secure; SameSite=None; Partitioned; Max-Age=3600`);
      return response(res,200,{ok:true,parentOrigin:PARENT});
    }
    if(url.pathname==='/api/bridge-session')return response(res,authenticated(req)?200:401,{ok:authenticated(req)});
    if(['/sw.js','/scramjet-client.js'].includes(url.pathname)) {
      if(!authenticated(req))return response(res,401,{error:'Session required'});
      const name=url.pathname==='/sw.js'?'sw.js':'scramjet-client.js';
      const data=await readFile(path.join(ROOT,name));
      res.writeHead(200,{...headers,'Content-Type':'text/javascript; charset=utf-8',...(name==='sw.js'?{'Service-Worker-Allowed':'/'}:{})});
      return res.end(data);
    }
    if(['/scram/','/controller/','/utils/','/libcurl/'].some(s=>url.pathname.startsWith(s))){
      if(!authenticated(req))return response(res,401,{error:'Session required'});
      return await serveAdvancedAsset(url.pathname,req,res);
    }
    return response(res,404,{error:'Not found'});
  }catch {if(!res.headersSent)response(res,500,{error:'Internal content error'});else res.destroy();}
});
server.on('upgrade',(req,socket,head)=>{
  if(routeWisp(req,socket,head,r=>authenticated(r)))return;
  socket.destroy();
});
server.headersTimeout=15_000;
server.requestTimeout=35_000;
server.keepAliveTimeout=5000;
server.maxConnections=128;
server.listen(PORT,'0.0.0.0',()=>console.log(`IRON CONTENT 0.7.0 on ${PORT}`));
const sweep=setInterval(()=>{for(const [k,v] of sessions)if(v<=Date.now())sessions.delete(k);for(const [k,v] of seen)if(v<=Date.now())seen.delete(k);for(const [k,v] of limit)if(v.until<=Date.now())limit.delete(k);},60_000);
sweep.unref();
const terminate=()=>{clearInterval(sweep);server.close(()=>process.exit(0));};
process.on('SIGTERM',terminate);process.on('SIGINT',terminate);
