/**
 * IRON operational telemetry. Deliberately holds NO URLs, IPs, request
 * headers, cookies or personal browsing history. Bounded in process memory.
 */
const INTERVALS = [100, 250, 500, 1000, 2500, 5000, 10000, 30000];
const buckets = Array(INTERVALS.length + 1).fill(0);
const recent = [];
const MAX_RECENT = 60;
const totals = { requests: 0, successes: 0, upstreamErrors: 0, rateLimited: 0, bytesStreamed: 0, bytesRewritten: 0, rewrittenDocuments: 0, aborted: 0 };
let lastFailure = 'none';

export function observeRequest({ durationMs = 0, status = 500, kind = 'other', bytes = 0, aborted = false } = {}) {
  const ms = Math.max(0, Math.round(Number(durationMs) || 0));
  buckets[INTERVALS.findIndex(x => ms <= x) === -1 ? INTERVALS.length : INTERVALS.findIndex(x => ms <= x)]++;
  totals.requests++;
  if (status >= 200 && status < 400) totals.successes++;
  if (status >= 500) totals.upstreamErrors++;
  if (status === 429) totals.rateLimited++;
  if (aborted) totals.aborted++;
  if (kind === 'rewritten') { totals.rewrittenDocuments++; totals.bytesRewritten += Math.max(0, Number(bytes) || 0); }
  if (kind === 'streamed') totals.bytesStreamed += Math.max(0, Number(bytes) || 0);
  if (status >= 400) lastFailure = `HTTP ${status}`;
  // The ring buffer stores only latency and status category, never page names.
  recent.push({ ms, ok: status < 400 });
  if (recent.length > MAX_RECENT) recent.shift();
}
export function telemetrySnapshot() {
  const times = recent.map(x => x.ms).sort((a,b) => a-b);
  const pick = p => times.length ? times[Math.max(0, Math.ceil(times.length * p) - 1)] : null;
  return {
    ...totals,
    sampleSize: times.length,
    medianMs: pick(.5),
    p95Ms: pick(.95),
    lastFailure,
    latencyBuckets: [...buckets],
    // This is request duration, not full end-to-end webpage load time.
    measure: 'Server-side proxied request duration; last 60 requests for percentiles'
  };
}

/** For dependency-free tests only. Never exposed over HTTP. */
export function resetTelemetryForTests() {
  for (const key of Object.keys(totals)) totals[key] = 0;
  buckets.fill(0); recent.length = 0; lastFailure = 'none';
}
