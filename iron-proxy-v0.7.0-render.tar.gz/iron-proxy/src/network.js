import { Agent, request } from 'undici';
import { pipeline } from 'node:stream/promises';
import { Transform } from 'node:stream';
import { observeRequest } from './metrics.js';
import { siteErrorResponse } from './errors.js';
import { assetCacheKey, shouldCacheAsset, readAsset, saveAsset } from './cache.js';
import { gunzip, inflate, brotliDecompress } from 'node:zlib';
import { promisify } from 'node:util';
import { pinnedPublicLookup, validateTarget, browserProxyPath, decodeBrowserPath } from './security.js';
import { rewriteDocument } from './rewrite-pool.js';
import { documentState } from './sessions.js';
import { scheduled } from './scheduler.js';
import { recordTabRequest } from './tab-trace.js';

const agent = new Agent({
  connections: 8,
  pipelining: 1,
  keepAliveTimeout: 10_000,
  connect: { timeout: 8_000, lookup: pinnedPublicLookup },
  headersTimeout: 15_000,
  bodyTimeout: 90_000
});
const MAX_REWRITE = 8_000_000;
const asyncGunzip = promisify(gunzip);
const asyncInflate = promisify(inflate);
const asyncBrotli = promisify(brotliDecompress);
const MAX_UPLOAD = 8_000_000;
const passHeaders = new Set(['accept','accept-language','range','if-range','if-none-match','if-modified-since','content-type','authorization','x-requested-with','user-agent']);
const permittedMethods = new Set(['GET','HEAD','POST','PUT','PATCH','DELETE']);

// Undici's BodyReadable can emit UND_ERR_ABORTED asynchronously after destroy().
// When we intentionally discard a redirect or HEAD body, it is not piped to a
// destination stream, so register a listener BEFORE destroying it. Otherwise
// Node treats the emitted error as uncaught and terminates the entire server.
function discardUpstreamBody(body) {
  if (!body || body.destroyed) return;
  body.on('error', () => {});
  body.destroy();
}

// Restore the actual original-page Referer when a request comes from an
// IRON proxied document. Do not invent a browser identity or forge traffic.
// The client-provided referer must refer to THIS tab's routed document.
export function originalReferrer(req, tab) {
  try {
    const ref = new URL(String(req.headers.referer || ''));
    if (ref.host !== req.headers.host) return null;
    const route = decodeBrowserPath(ref.pathname, ref.search);
    return route.cap === tab.cap ? route.target : null;
  } catch { return null; }
}

function upstreamHeaders(req, url, jarCookie, referrer) {
  const headers = { 'accept-encoding': 'identity' };
  for (const [name, value] of Object.entries(req.headers)) {
    if (passHeaders.has(name) && typeof value === 'string') headers[name] = value;
  }
  if (jarCookie) headers.cookie = jarCookie;
  if (referrer) headers.referer = referrer.href;
  // Origin must reflect the requesting document, not always the destination.
  // This matters for real cross-origin form posts and normal site CSRF rules.
  if (['POST', 'PUT', 'PATCH', 'DELETE'].includes(req.method)) headers.origin = referrer?.origin || url.origin;
  return headers;
}

function limitedUpload(source) {
  let total = 0;
  const limiter = new Transform({
    transform(chunk, _, next) {
      total += chunk.length;
      if (total > MAX_UPLOAD) {
        const error = new Error('Upload exceeds 8 MB limit');
        error.statusCode = 413;
        next(error);
      } else next(null, chunk);
    }
  });
  // A failed upload may emit after Undici aborts its read. Always handle it.
  limiter.on('error', () => {});
  source.pipe(limiter);
  source.once('error', error => limiter.destroy(error));
  return limiter;
}

async function toLimitedBuffer(body, max = MAX_REWRITE) {
  let size = 0;
  const chunks = [];
  for await (const chunk of body) {
    size += chunk.length;
    if (size > max) {
      discardUpstreamBody(body);
      const e = new Error('Document exceeds safe rewrite limit'); e.statusCode = 413; throw e;
    }
    chunks.push(chunk);
  }
  return Buffer.concat(chunks);
}

async function decoded(buffer, encoding) {
  if (!encoding || encoding === 'identity') return buffer;
  // Decompression runs in libuv's worker pool instead of blocking the HTTP
  // event loop. maxOutputLength still prevents compression bombs.
  if (encoding === 'gzip') return asyncGunzip(buffer, { maxOutputLength: MAX_REWRITE });
  if (encoding === 'deflate') return asyncInflate(buffer, { maxOutputLength: MAX_REWRITE });
  if (encoding === 'br') return asyncBrotli(buffer, { maxOutputLength: MAX_REWRITE });
  throw new Error('Unsupported compressed upstream content');
}

function writeStandard(res, status) {
  res.statusCode = status;
  res.setHeader('Referrer-Policy', 'no-referrer');
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('Cache-Control', 'private, no-store');
  // Sandboxed iframe has an opaque origin. Requests from it require CORS.
  // No credentials are exposed to it: remote cookies live only in tab jars.
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Cross-Origin-Resource-Policy', 'cross-origin');
  res.setHeader('Access-Control-Expose-Headers', 'Content-Length, Content-Range, Accept-Ranges, ETag, Last-Modified');
}

export async function proxyRequest(req, res, tab, target) {
  // A navigation closed before it starts should not remain in the queue.
  const queueAbort = new AbortController();
  const onClosed = () => { if (!res.writableFinished) queueAbort.abort(); };
  res.once('close', onClosed);
  try { return await scheduled(() => executeRequest(req, res, tab, target), queueAbort.signal, tab.cap); }
  catch (error) {
    if (error.name === 'AbortError' || res.destroyed) return;
    siteErrorResponse(res, error.statusCode || 503, 'NETWORK_OVERLOADED',
      'IRON NETWORK is at capacity. Please retry after active requests finish.');
  } finally { res.removeListener('close', onClosed); }
}

async function executeRequest(req, res, tab, target) {
  if (!permittedMethods.has(req.method)) {
    res.writeHead(405, { Allow: 'GET, HEAD, POST, PUT, PATCH, DELETE' }).end('Method not allowed'); return;
  }
  const hasUpload = ['POST','PUT','PATCH','DELETE'].includes(req.method);
  if (hasUpload && Number(req.headers['content-length'] || 0) > MAX_UPLOAD) {
    siteErrorResponse(res, 413, 'UPLOAD_TOO_LARGE', 'Uploads must not exceed 8 MB.'); return;
  }
  const start = performance.now();
  let observed = false;
  let byteCount = 0;
  let resultKind = 'other';
  const observe = (aborted = false) => {
    if (observed) return;
    observed = true;
    const elapsed = performance.now() - start;
    observeRequest({ durationMs: elapsed, status: res.statusCode,
      kind: resultKind, bytes: byteCount, aborted });
    recordTabRequest(tab, { hostname: target.hostname, status: res.statusCode, kind: resultKind, milliseconds: elapsed, aborted });
  };
  res.once('finish', () => observe());
  res.once('close', () => observe(!res.writableFinished));
  const url = validateTarget(target.href);
  const cookie = await tab.cookies.getCookieString(url.href);
  const referrer = originalReferrer(req, tab);
  const cacheKey = assetCacheKey(tab.cap, url.href, req.headers, cookie, referrer?.href || '');
  const cacheCandidate = req.method === 'GET' && !req.headers.range && !req.headers.authorization &&
    !req.headers['if-none-match'] && !req.headers['if-modified-since'] && !req.headers['if-range'];
  if (cacheCandidate) {
    const cacheHit = readAsset(cacheKey);
    if (cacheHit) {
      res.statusCode = cacheHit.status;
      writeStandard(res, cacheHit.status);
      for (const [key, value] of Object.entries(cacheHit.headers)) res.setHeader(key, value);
      res.setHeader('X-Iron-Cache', 'HIT');
      resultKind = 'cache'; byteCount = cacheHit.body.length;
      res.end(cacheHit.body);
      return;
    }
  }
  const control = new AbortController();
  const abortIfClosed = () => { if (!res.writableFinished) control.abort(); };
  res.once('close', abortIfClosed);
  let upstream;
  try {
    upstream = await request(url, {
      dispatcher: agent,
      method: req.method,
      headers: upstreamHeaders(req, url, cookie, referrer),
      body: hasUpload ? limitedUpload(req) : undefined,
      maxRedirections: 0,
      headersTimeout: 15_000,
      bodyTimeout: 90_000,
      signal: control.signal
    });
  } catch (e) {
    res.removeListener('close', abortIfClosed);
    if (res.destroyed) return;
    const large = e.statusCode === 413 || /upload exceeds/i.test(String(e?.message || e?.cause?.message || ''));
    siteErrorResponse(res, large ? 413 : 502, large ? 'UPLOAD_TOO_LARGE' : 'UPSTREAM_CONNECT_FAILED',
      large ? 'The request body exceeds the upload limit.' : 'IRON NETWORK could not reach the destination. Check its address or use Diagnostics to test connectivity.');
    return;
  }
  // Attach before intentional body cancellation or pipeline shutdown.
  upstream.body?.on('error', () => {});
  // Store upstream cookies in the tab's private server-side jar.
  const setCookies = upstream.headers['set-cookie'];
  for (const item of (Array.isArray(setCookies) ? setCookies : setCookies ? [setCookies] : []).slice(0, 40)) {
    if ((tab.cookieWrites || 0) >= 2000) break;
    tab.cookieWrites = (tab.cookieWrites || 0) + 1;
    try { await tab.cookies.setCookie(item, url.href, { ignoreError: true }); } catch {}
  }

  const type = String(upstream.headers['content-type'] || 'application/octet-stream');
  const status = upstream.statusCode;
  const publicCacheTtl = cacheCandidate ? shouldCacheAsset({
    method: req.method, status, type,
    responseHeaders: upstream.headers, requestHeaders: req.headers,
    hasUpstreamCookies: !!setCookies
  }) : 0;
  writeStandard(res, status);
  // Never forward upstream cookies, CSP, frame policy, HSTS or auth challenges
  // to the proxy's own origin.
  res.setHeader('Content-Type', type);
  if (upstream.headers['content-disposition']) res.setHeader('Content-Disposition', String(upstream.headers['content-disposition']));
  if (upstream.headers['accept-ranges']) res.setHeader('Accept-Ranges', String(upstream.headers['accept-ranges']));
  if (upstream.headers['content-range']) res.setHeader('Content-Range', String(upstream.headers['content-range']));
  if (upstream.headers['etag']) res.setHeader('ETag', String(upstream.headers['etag']));
  if (upstream.headers['last-modified']) res.setHeader('Last-Modified', String(upstream.headers['last-modified']));
  if (upstream.headers['vary']) res.setHeader('Vary', String(upstream.headers['vary']));

  if (status >= 300 && status < 400 && upstream.headers.location) {
    let dest;
    try {
      dest = validateTarget(new URL(String(upstream.headers.location), url.href).href);
    } catch {
      discardUpstreamBody(upstream.body);
      res.statusCode = 403;
      res.removeHeader('Content-Type');
      res.setHeader('Content-Type', 'text/plain; charset=utf-8');
      res.end('IRON NETWORK blocked an unsafe redirect.');
      return;
    }
    res.setHeader('Location', browserProxyPath(tab.cap, dest.href));
    discardUpstreamBody(upstream.body);
    res.end();
    return;
  }
  const html = /(?:^|\s|;)text\/html(?:;|$)/i.test(type);
  const css = /(?:^|\s|;)text\/css(?:;|$)/i.test(type);
  const javascript = /(?:javascript|ecmascript)/i.test(type) && !/json/i.test(type);
  const transform = req.method !== 'HEAD' && status >= 200 && status !== 204 && status !== 206 && status !== 304 && !(status >= 300 && status < 400) && (html || css || javascript);
  if (transform) {
    try {
      const raw = await toLimitedBuffer(upstream.body);
      const text = (await decoded(raw, String(upstream.headers['content-encoding'] || '').toLowerCase())).toString('utf8');
      let result;
      if (html) {
        const doc = documentState(tab, url);
        const allCookies = await tab.cookies.getCookies(url.href);
        const visibleCookies = allCookies.filter(cookie => !cookie.httpOnly).map(cookie => cookie.key + '=' + cookie.value).join('; ');
        result = await rewriteDocument('html', text, url.href, tab.cap, { ...doc, cookies: visibleCookies }, control.signal);
      } else if (css) result = await rewriteDocument('css', text, url.href, tab.cap, {}, control.signal);
      else result = await rewriteDocument('js', text, url.href, tab.cap, {}, control.signal);
      // The output bytes differ from upstream: forwarding validators would be incorrect.
      res.removeHeader('ETag');
      res.removeHeader('Last-Modified');
      res.removeHeader('Content-Range');
      res.setHeader('X-Iron-Transform', html ? 'html' : css ? 'css' : 'js');
      resultKind = 'rewritten'; byteCount = Buffer.byteLength(result);
      if (publicCacheTtl && !html) saveAsset(cacheKey, Buffer.from(result), {
        'Content-Type': type, 'Vary': String(upstream.headers.vary || '')
      }, publicCacheTtl);
      res.end(result);
    } catch (e) {
      if (!res.headersSent) {
        // The headers may already be set, but have not been sent. Avoid stale
        // content-disposition/encoding values when replacing the response.
        res.removeHeader('Content-Encoding');
        res.removeHeader('Content-Length');
        res.removeHeader('Content-Disposition');
        siteErrorResponse(res, e.statusCode || 502, e.statusCode === 413 ? 'REWRITE_LIMIT' : 'REWRITE_ERROR',
          e.statusCode === 413 ? 'This document exceeds the Native rewrite budget. Try another page or inspect the Network laboratory.' : 'IRON CORE could not safely transform this document.');
      } else res.destroy(e);
    }
  } else if (req.method === 'HEAD' || status === 204 || status === 304) {
    discardUpstreamBody(upstream.body);
    res.end();
  } else {
    if (upstream.headers['content-encoding']) res.setHeader('Content-Encoding', String(upstream.headers['content-encoding']));
    if (upstream.headers['content-length']) res.setHeader('Content-Length', String(upstream.headers['content-length']));
    resultKind = 'streamed';
    const buffers = [];
    let canCache = !!publicCacheTtl;
    const meter = new Transform({ transform(chunk, encoding, done) {
      byteCount += chunk.length;
      if (canCache && byteCount <= 512 * 1024) buffers.push(Buffer.from(chunk));
      else { canCache = false; buffers.length = 0; }
      done(null, chunk);
    } });
    try {
      await pipeline(upstream.body, meter, res);
      if (canCache && buffers.length) {
        const headers = {};
        for (const key of ['Content-Type','Content-Encoding','Content-Length','ETag','Last-Modified','Vary']) {
          const value = res.getHeader(key);
          if (typeof value === 'string') headers[key] = value;
        }
        saveAsset(cacheKey, Buffer.concat(buffers), headers, publicCacheTtl);
      }
    } catch { if (!res.destroyed) res.destroy(); }
  }
}

export async function closeTransport() { await agent.close(); }
