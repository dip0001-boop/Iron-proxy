// Dedicated, memory-capped worker for expensive structural rewriting.
import { parentPort } from 'node:worker_threads';
import { rewriteHtml, rewriteCss } from './rewriter.js';
import { rewriteJavaScript } from './javascript.js';

parentPort.on('message', ({ id, kind, text, url, cap, options }) => {
  try {
    const output = kind === 'html' ? rewriteHtml(text, url, cap, options) :
      kind === 'css' ? rewriteCss(text, url, cap) :
      kind === 'js' ? rewriteJavaScript(text, url, cap) : null;
    if (typeof output !== 'string') throw new Error('Unknown rewrite kind');
    parentPort.postMessage({ id, result: output });
  } catch (error) {
    parentPort.postMessage({ id, error: { message: 'Document transformation failed', statusCode: error.statusCode || 502 } });
  }
});
