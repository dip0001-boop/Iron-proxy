// The bootstrap executes inside the UNTRUSTED sandboxed site frame.
// This is a compatibility layer, not a browser security boundary.
// Keep config encoded safely for insertion into a <script> text node.
export function bootScript(config) {
  const serialized = JSON.stringify(config).replace(/</g, '\\u003c').replace(/\u2028/g, '\\u2028').replace(/\u2029/g, '\\u2029');
  return `(${ironBootstrap.toString()})(${serialized});`;
}

function ironBootstrap(config) {
  'use strict';
  const prefix = '/p/' + config.cap + '/';
  const wsPrefix = '/ws/' + config.cap + '/';
  const original = () => {
    const match = location.pathname.match(/^\/p\/[a-f0-9]{48}\/(https?)\/([^/]+)(\/.*)?$/);
    return match ? `${match[1]}://${match[2]}${match[3] || '/'}${location.search}${location.hash}` : config.remote;
  };
  function map(input, base = original()) {
    if (input === null || input === undefined) return input;
    if (typeof input !== 'string' && !(input instanceof URL)) return input;
    const str = String(input);
    if (/^(data:|blob:|javascript:|about:|mailto:|tel:|#)/i.test(str) || str.startsWith('/p/')) return input;
    try {
      const u = new URL(str, base);
      if (u.protocol !== 'http:' && u.protocol !== 'https:') return input;
      return prefix + u.protocol.slice(0, -1) + '/' + u.host + u.pathname + u.search + u.hash;
    } catch { return input; }
  }
  function mapSocket(input) {
    const s = String(input);
    try {
      const src = new URL(original());
      const u = new URL(s, src.href);
      if (u.protocol === 'http:') u.protocol = 'ws:';
      if (u.protocol === 'https:') u.protocol = 'wss:';
      if (u.protocol !== 'ws:' && u.protocol !== 'wss:') return s;
      return (location.protocol === 'https:' ? 'wss://' : 'ws://') + location.host + wsPrefix + u.protocol.slice(0,-1) + '/' + u.host + u.pathname + u.search;
    } catch { return s; }
  }
  // Exposed only inside this untrusted frame, never on the privileged shell.
  window.__iron = Object.freeze({ map, module: map, original, mapSocket });
  function notify() {
    try { parent.postMessage({ type: 'iron:location', url: original() }, '*'); } catch {}
  }
  function reportTitle() {
    try { parent.postMessage({ type:'iron:title', url:original(), title:String(document.title || '').slice(0,100) }, '*'); } catch {}
  }
  addEventListener('DOMContentLoaded', () => {
    notify(); reportTitle();
    const title = document.querySelector('title');
    if (title && window.MutationObserver) {
      const observer = new MutationObserver(reportTitle);
      observer.observe(title, { childList:true, subtree:true, characterData:true });
      addEventListener('pagehide', () => observer.disconnect(), { once:true });
    }
  });
  addEventListener('popstate', notify);
  addEventListener('hashchange', notify);

  // Both strings and Request objects use the proxy. Do not send the shell's
  // iron_session HttpOnly cookie in content requests.
  const nativeFetch = window.fetch?.bind(window);
  const NativeRequest = window.Request;
  if (NativeRequest) {
    try {
      window.Request = class IronRequest extends NativeRequest {
        constructor(input, init) {
          if (typeof input === 'string' || input instanceof URL) super(map(input), { ...init, credentials: 'omit' });
          else super(input, { ...init, credentials: 'omit' });
        }
      };
    } catch {}
  }
  if (nativeFetch) window.fetch = function (input, init) {
    let value = typeof input === 'string' || input instanceof URL ? map(input) : input;
    if (NativeRequest && input instanceof NativeRequest) {
      // Fetch(Request) is common in SPA frameworks and video/game assets.
      try {
        const mapped = map(input.url);
        if (mapped !== input.url) value = new NativeRequest(mapped, input);
      } catch { /* retain original Request if cloning its body isn't supported */ }
    }
    return nativeFetch(value, { ...init, credentials: 'omit' });
  };
  if (window.EventSource) {
    const NativeEventSource = window.EventSource;
    try { window.EventSource = class IronEventSource extends NativeEventSource {
      constructor(url, options) { super(map(url), { ...options, withCredentials:false }); }
    }; } catch {}
  }
  if (window.XMLHttpRequest) {
    const oldOpen = XMLHttpRequest.prototype.open;
    XMLHttpRequest.prototype.open = function (method, url, ...rest) { return oldOpen.call(this, method, map(url), ...rest); };
    // XHR withCredentials is ignored: the remote cookie jar is server-managed.
  }

  // Dynamically set asset URLs are extremely common in HTML5 games.
  const urlAttrs = new Set(['src', 'href', 'action', 'poster', 'data', 'formaction']);
  try {
    const oldSet = Element.prototype.setAttribute;
    Element.prototype.setAttribute = function (name, value) {
      const key = String(name).toLowerCase();
      return oldSet.call(this, name, urlAttrs.has(key) ? map(value) : value);
    };
  } catch {}
  const patches = [
    [HTMLImageElement, ['src', 'srcset']], [HTMLScriptElement, ['src']],
    [HTMLLinkElement, ['href']], [HTMLIFrameElement, ['src']],
    [HTMLMediaElement, ['src', 'poster']], [HTMLSourceElement, ['src']],
    [HTMLAnchorElement, ['href']], [HTMLFormElement, ['action']]
  ];
  for (const [ctor, properties] of patches) {
    if (!ctor?.prototype) continue;
    for (const name of properties) {
      if (name === 'srcset') continue; // srcset requires token parsing, not a single URL.
      try {
        const desc = Object.getOwnPropertyDescriptor(ctor.prototype, name);
        if (!desc?.set || !desc.configurable) continue;
        Object.defineProperty(ctor.prototype, name, {
          ...desc, set(value) { return desc.set.call(this, map(value)); }
        });
      } catch {}
    }
  }

  try {
    const oldPush = history.pushState, oldReplace = history.replaceState;
    history.pushState = function (state, title, url) { const out = oldPush.call(this, state, title, url == null ? url : map(url)); notify(); return out; };
    history.replaceState = function (state, title, url) { const out = oldReplace.call(this, state, title, url == null ? url : map(url)); notify(); return out; };
  } catch {}
  // Redirect popups into the isolated site frame, not a privileged Chrome tab.
  try { window.open = function (url) { if (url) location.assign(map(url)); return null; }; } catch {}

  // Browser-hosted WebSocket tunnel, with upstream validation on the server.
  if (window.WebSocket) {
    const NativeWS = window.WebSocket;
    try {
      window.WebSocket = class IronWebSocket extends NativeWS {
        constructor(url, protocols) {
          if (protocols === undefined) super(mapSocket(url));
          else super(mapSocket(url), protocols);
        }
      };
    } catch {}
  }

  // Lightweight worker bridge. Blob workers are experimental in opaque-origin
  // sandboxed frames and may be blocked by browser policy.
  if (window.Worker) {
    const NativeWorker = window.Worker;
    try {
      window.Worker = class IronWorker {
        constructor(url, options = {}) {
          const target = new URL(map(url), location.href).href;
          const code = options.type === 'module'
            ? `import(${JSON.stringify(target)});`
            : `importScripts(${JSON.stringify(target)});`;
          const blob = URL.createObjectURL(new Blob([code], { type: 'text/javascript' }));
          try { this.inner = new NativeWorker(blob, options); }
          finally { setTimeout(() => URL.revokeObjectURL(blob), 10_000); }
        }
        postMessage(...args) { return this.inner.postMessage(...args); }
        terminate() { return this.inner.terminate(); }
        addEventListener(...args) { return this.inner.addEventListener(...args); }
        removeEventListener(...args) { return this.inner.removeEventListener(...args); }
        get onmessage() { return this.inner.onmessage; }
        set onmessage(fn) { this.inner.onmessage = fn; }
        get onerror() { return this.inner.onerror; }
        set onerror(fn) { this.inner.onerror = fn; }
      };
    } catch {}
  }

  // Opaque sandbox frames otherwise throw SecurityError for storage access.
  // These are per-tab, per-original-origin, bounded, ephemeral virtual stores.
  const storageEndpoint = '/_iron/state/' + config.cap + '/' + config.ticket;
  const storage = config.storage || { local: {}, session: {} };
  const sync = (body) => {
    if (!nativeFetch) return;
    nativeFetch(storageEndpoint, {
      method: 'POST', mode: 'cors', credentials: 'omit',
      headers: { 'Content-Type': 'text/plain;charset=UTF-8' },
      body: JSON.stringify(body), keepalive: true
    }).catch(() => {});
  };
  function makeStorage(kind) {
    const entries = new Map(Object.entries(storage[kind] || {}));
    const store = {
      getItem(key) { const v = entries.get(String(key)); return v === undefined ? null : v; },
      setItem(key, value) {
        const k = String(key), v = String(value);
        if (k.length > 1024 || v.length > 64_000 || [...entries].reduce((n,[a,b])=>n+a.length+b.length,0) + k.length + v.length > 200_000) throw new DOMException('IRON storage quota exceeded', 'QuotaExceededError');
        entries.set(k, v); sync({ kind, op: 'set', key: k, value: v });
      },
      removeItem(key) { entries.delete(String(key)); sync({ kind, op: 'remove', key: String(key) }); },
      clear() { entries.clear(); sync({ kind, op: 'clear' }); },
      key(index) { return [...entries.keys()][index] ?? null; },
      get length() { return entries.size; }
    };
    return new Proxy(store, {
      get(obj, prop) { if (prop in obj || typeof prop === 'symbol') return obj[prop]; return obj.getItem(prop) ?? undefined; },
      set(obj, prop, value) { if (prop in obj) return false; obj.setItem(prop, value); return true; },
      deleteProperty(obj, prop) { obj.removeItem(prop); return true; },
      ownKeys() { return [...entries.keys()]; },
      getOwnPropertyDescriptor(obj, prop) { if (entries.has(prop)) return { configurable:true, enumerable:true, writable:true, value:entries.get(prop) }; }
    });
  }
  for (const kind of ['local','session']) {
    try { Object.defineProperty(window, kind + 'Storage', { configurable:true, value: makeStorage(kind) }); } catch {}
  }
  const cookieValues = new Map();
  for (const part of (config.cookies || '').split(/;\s*/)) {
    const eq = part.indexOf('=');
    if (eq > 0) cookieValues.set(part.slice(0, eq), part.slice(eq + 1));
  }
  try {
    Object.defineProperty(document, 'cookie', {
      configurable: true,
      get() { return [...cookieValues].map(([k,v]) => k + '=' + v).join('; '); },
      set(value) {
        const first = String(value).split(';')[0]; const pos = first.indexOf('=');
        if (pos <= 0) return;
        cookieValues.set(first.slice(0,pos).trim(), first.slice(pos+1).trim());
        sync({ kind: 'cookie', value: String(value).slice(0,4000) });
      }
    });
  } catch {}
}
