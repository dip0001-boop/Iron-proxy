/** Security decisions centralized to prevent accidental unsafe deployments. */
export const COMPAT_FLAG = 'IRON_ALLOW_UNISOLATED_COMPAT';
export function compatibilityAllowed(env = process.env) {
  // Scramjet's same-origin iframe can access its parent. Never enable that
  // configuration as the silent production default.
  return env.NODE_ENV !== 'production' || env[COMPAT_FLAG] === '1';
}
export function shellHeaders({ production = false, compatibility = false, contentOrigin = null } = {}) {
  return {
    'X-Frame-Options': 'DENY',
    'Referrer-Policy': 'no-referrer',
    'X-Content-Type-Options': 'nosniff',
    'Cross-Origin-Resource-Policy': 'same-origin',
    'Permissions-Policy': 'camera=(), microphone=(), geolocation=(), payment=()',
    'Cache-Control': 'no-store',
    ...(production ? { 'Strict-Transport-Security': 'max-age=31536000' } : {}),
    'Content-Security-Policy': [
      "default-src 'self'",
      `script-src 'self' blob: 'wasm-unsafe-eval'${compatibility ? " 'unsafe-eval'" : ''}`,
      "style-src 'self' 'unsafe-inline'",
      "connect-src 'self' wss: ws:",
      "frame-src 'self' blob:" + (contentOrigin ? ` ${contentOrigin}` : ''),
      "worker-src 'self' blob:",
      "img-src 'self' data: blob:",
      "object-src 'none'",
      "base-uri 'none'",
      "form-action 'self'"
    ].join('; ')
  };
}
export function runtimeWarnings({ compatibility = false } = {}) {
  return compatibility
    ? ['Advanced mode runs in the shell origin and is unsafe for sensitive logins. Use only for development until separate origins are deployed.']
    : ['Unisolated advanced mode is disabled. Native mode uses an opaque iframe origin.'];
}
