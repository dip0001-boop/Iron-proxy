/**
 * IRON REWRITE WORKER - expensive parse5, CSS AST and JavaScript AST work runs
 * outside the HTTP event loop. One worker by default to fit low-RAM Render.
 * Bounded queue, memory, task duration, cancellation, and graceful teardown.
 */
import { Worker } from 'node:worker_threads';
import { rewriteHtml, rewriteCss } from './rewriter.js';
import { rewriteJavaScript } from './javascript.js';

const MAX_WAITING = 12;
const MAX_WAITING_BYTES = 16 * 1024 * 1024;
const WORKER_THRESHOLD = 48 * 1024;
const TASK_TIMEOUT = 15_000;
let worker = null;
let running = null;
let queue = [];
let queuedBytes = 0;
let nextId = 0;
let completed = 0;
let failures = 0;
let timeouts = 0;
let cancelled = 0;
let idleTimer = null;
let shuttingDown = false;

function abortError() { const e = new Error('Page load cancelled'); e.name = 'AbortError'; return e; }
function busyError() { const e = new Error('Rewrite queue capacity reached'); e.statusCode = 503; return e; }
function forgetAbort(job) { if (job.signal && job.onAbort) job.signal.removeEventListener('abort', job.onAbort); }
function finalize(job, error, value) {
  if (job.settled) return;
  job.settled = true;
  forgetAbort(job);
  if (job.timer) clearTimeout(job.timer);
  if (error) job.reject(error); else job.resolve(value);
}
function removeWorker() {
  if (!worker) return;
  const previous = worker;
  worker = null;
  previous.removeAllListeners();
  previous.terminate().catch(() => {});
}
function onWorkerFailed(message) {
  failures++;
  if (running) {
    const job = running;
    running = null;
    finalize(job, Object.assign(new Error(message), { statusCode: 502 }));
  }
  removeWorker();
  pump();
}
function startWorker() {
  if (worker || shuttingDown) return;
  worker = new Worker(new URL('./rewrite-worker.js', import.meta.url), {
    resourceLimits: { maxOldGenerationSizeMb: 96, maxYoungGenerationSizeMb: 16 },
    execArgv: []
  });
  worker.unref();
  worker.on('message', ({ id, error, result }) => {
    if (!running || running.id !== id) return;
    const job = running;
    running = null;
    if (error) { failures++; finalize(job, Object.assign(new Error(error.message), { statusCode: error.statusCode })); }
    else { completed++; finalize(job, null, result); }
    pump();
  });
  worker.on('error', () => onWorkerFailed('Rewrite worker error'));
  worker.on('exit', code => { if (worker && !shuttingDown) onWorkerFailed(`Rewrite worker exited (${code})`); });
}
function scheduleIdleStop() {
  clearTimeout(idleTimer);
  idleTimer = setTimeout(() => { if (!running && !queue.length) removeWorker(); }, 45_000);
  idleTimer.unref();
}
function pump() {
  if (shuttingDown || running) return;
  clearTimeout(idleTimer);
  while (queue.length) {
    const job = queue.shift();
    queuedBytes -= job.size;
    if (job.settled || job.signal?.aborted) { cancelled++; finalize(job, abortError()); continue; }
    running = job;
    startWorker();
    job.timer = setTimeout(() => {
      if (running !== job) return;
      running = null;
      timeouts++;
      finalize(job, Object.assign(new Error('Rewrite timed out'), { statusCode: 504 }));
      removeWorker();
      pump();
    }, TASK_TIMEOUT);
    job.timer.unref();
    worker.postMessage({ id: job.id, kind: job.kind, text: job.text, url: job.url, cap: job.cap, options: job.options });
    return;
  }
  scheduleIdleStop();
}

export function rewriteDocument(kind, text, url, cap, options = {}, signal = null) {
  if (signal?.aborted) return Promise.reject(abortError());
  if (!['html', 'css', 'js'].includes(kind)) return Promise.reject(new Error('Unknown rewrite kind'));
  // Small scripts and styles are faster in-process. Large jobs go to a worker.
  if (Buffer.byteLength(text) < WORKER_THRESHOLD) {
    try {
      return Promise.resolve(kind === 'html' ? rewriteHtml(text, url, cap, options) :
        kind === 'css' ? rewriteCss(text, url, cap) : rewriteJavaScript(text, url, cap));
    } catch (e) { return Promise.reject(e); }
  }
  const size = Buffer.byteLength(text);
  if (queue.length >= MAX_WAITING || queuedBytes + size > MAX_WAITING_BYTES) return Promise.reject(busyError());
  return new Promise((resolve, reject) => {
    const job = { id: ++nextId, kind, text, url, cap, options, signal, size, resolve, reject, settled: false, onAbort: null };
    job.onAbort = () => {
      if (job.settled) return;
      const idx = queue.indexOf(job);
      if (idx >= 0) {
        queue.splice(idx, 1); queuedBytes -= size; cancelled++; finalize(job, abortError());
      } else if (running === job) {
        running = null; cancelled++; finalize(job, abortError()); removeWorker(); pump();
      }
    };
    signal?.addEventListener('abort', job.onAbort, { once: true });
    queue.push(job); queuedBytes += size;
    if (signal?.aborted) job.onAbort(); else pump();
  });
}
export function rewritePoolStats() {
  return { rewriteWorkerActive: !!running, rewriteQueueDepth: queue.length, rewriteQueueMB: +(queuedBytes / 1048576).toFixed(2),
    rewritesInWorker: completed, rewriteWorkerFailures: failures, rewriteTimeouts: timeouts, rewriteCancelled: cancelled };
}
export async function closeRewritePool() {
  shuttingDown = true;
  clearTimeout(idleTimer);
  for (const job of queue) finalize(job, abortError());
  queue = []; queuedBytes = 0;
  if (running) { finalize(running, abortError()); running = null; }
  if (worker) { const old = worker; worker = null; old.removeAllListeners(); await old.terminate(); }
}
