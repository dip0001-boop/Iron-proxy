/**
 * Per-tab, in-memory, bounded request diagnostics. This is intentionally NOT
 * a request/URL logger. Store only destination HOSTNAMES (never URL paths,
 * queries, headers, passwords, cookies, referrers, or request bodies). The
 * contents are visible only to the owning authenticated session, can be
 * cleared instantly, and disappear when the tab expires or is closed.
 */
const MAX_ITEMS = 72;
export function recordTabRequest(tab, { hostname, status, kind = 'other', milliseconds = 0, aborted = false } = {}) {
  if (!tab || typeof hostname !== 'string') return;
  if (!Array.isArray(tab.trace)) tab.trace = [];
  tab.trace.push({ host: hostname.slice(0, 253), status: Number(status) || 0,
    kind: String(kind).slice(0, 24), ms: Math.max(0, Math.round(Number(milliseconds) || 0)), aborted: !!aborted });
  if (tab.trace.length > MAX_ITEMS) tab.trace.splice(0, tab.trace.length - MAX_ITEMS);
}
export function getTabTrace(tab) {
  return Array.isArray(tab?.trace) ? tab.trace.map(x => ({ ...x })) : [];
}
export function clearTabTrace(tab) {
  if (tab) tab.trace = [];
}
