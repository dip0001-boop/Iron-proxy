import dns from 'node:dns';
import ipaddr from 'ipaddr.js';

const deniedHosts = new Set(['localhost', 'localhost.localdomain', 'metadata.google.internal']);
const MAX_URL = 8192;

// Domain rules are checked BEFORE the transport and every address returned by DNS
// is checked again by the transport's actual connection-time DNS lookup.
export function isPublicIp(ip) {
  try {
    let parsed = ipaddr.parse(ip);
    if (parsed.kind() === 'ipv6' && parsed.isIPv4MappedAddress()) parsed = parsed.toIPv4Address();
    // ipaddr.js recognises private, link-local, loopback, CGNAT, reserved,
    // documentation, multicast, and more. Only globally unicast IPs pass.
    return parsed.range() === 'unicast';
  } catch { return false; }
}

export function validateTarget(value) {
  if (typeof value !== 'string' || value.length > MAX_URL) throw new Error('Invalid URL length');
  let url;
  try { url = new URL(value); } catch { throw new Error('Invalid URL'); }
  if (!['https:', 'http:'].includes(url.protocol)) throw new Error('Only HTTP and HTTPS are supported');
  if (url.username || url.password) throw new Error('Credentials in URLs are not allowed');
  if (!url.hostname || url.hostname.endsWith('.') || /[\u0000-\u0020]/.test(url.hostname)) throw new Error('Invalid host');
  const host = url.hostname.replace(/^\[|\]$/g, '').toLowerCase();
  if (deniedHosts.has(host) || host.endsWith('.localhost') || host.endsWith('.local') || host.endsWith('.internal') || host.endsWith('.test') || host.endsWith('.invalid') || host.endsWith('.home.arpa')) {
    throw new Error('Private or local hosts are blocked');
  }
  // Port restrictions prevent the proxy being used as a service scanner.
  if (url.port && !['80','443'].includes(url.port)) {
    // Local fixture port is permitted ONLY for tests, never in production.
    if (!(process.env.NODE_ENV === 'test' && process.env.IRON_TEST_ALLOW_LOOPBACK === '1' && host === '127.0.0.1')) {
      throw new Error('Nonstandard upstream ports are blocked');
    }
  }
  if (ipaddr.isValid(host) && !isPublicIp(host)) {
    if (!(process.env.NODE_ENV === 'test' && process.env.IRON_TEST_ALLOW_LOOPBACK === '1' && host === '127.0.0.1')) {
      throw new Error('Private IP addresses are blocked');
    }
  }
  url.hash = ''; // fragments are handled by the client, never sent upstream
  return url;
}

export function pinnedPublicLookup(hostname, options, callback) {
  const host = hostname.replace(/^\[|\]$/g, '');
  if (ipaddr.isValid(host)) {
    if (!isPublicIp(host) && !(process.env.NODE_ENV === 'test' && process.env.IRON_TEST_ALLOW_LOOPBACK === '1' && host === '127.0.0.1')) {
      callback(new Error('Blocked upstream address'));
      return;
    }
    const family = ipaddr.parse(host).kind() === 'ipv4' ? 4 : 6;
    if (options?.all) callback(null, [{ address: host, family }]);
    else callback(null, host, family);
    return;
  }
  dns.lookup(hostname, { all: true, verbatim: true }, (error, addresses) => {
    if (error) return callback(error);
    if (!addresses.length || addresses.some(({ address }) => !isPublicIp(address))) {
      callback(new Error('Blocked DNS resolution'));
      return;
    }
    const candidate = addresses.find(x => x.family === options?.family) || addresses[0];
    if (options?.all) callback(null, [candidate]);
    else callback(null, candidate.address, candidate.family);
  });
}

export function browserProxyPath(cap, remote) {
  const u = validateTarget(remote);
  return `/p/${cap}/${u.protocol.slice(0,-1)}/${u.host}${u.pathname}${u.search}${new URL(remote).hash}`;
}

export function decodeBrowserPath(pathname, search) {
  // Receives a path like /p/<cap>/https/www.example.com/foo?x=1
  const match = pathname.match(/^\/p\/([a-f0-9]{48})\/(https?)\/([^/]+)(\/.*)?$/);
  if (!match) throw new Error('Malformed proxy URL');
  const [, cap, scheme, host, path = '/'] = match;
  // URL constructor canonicalizes encoded numeric IPv4 variants before validation.
  return { cap, target: validateTarget(`${scheme}://${host}${path}${search || ''}`) };
}

export function decodeSocketPath(pathname, search = '') {
  const match = pathname.match(/^\/ws\/([a-f0-9]{48})\/(wss?)\/([^/]+)(\/.*)?$/);
  if (!match) throw new Error('Malformed WebSocket proxy URL');
  const [, cap, protocol, host, rest = '/'] = match;
  const safe = validateTarget(`${protocol === 'wss' ? 'https' : 'http'}://${host}${rest}${search}`);
  const target = new URL(safe.href.replace(/^https:/, 'wss:').replace(/^http:/, 'ws:'));
  return { cap, target };
}
