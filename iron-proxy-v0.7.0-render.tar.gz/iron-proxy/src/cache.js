/**
 * Tiny, bounded, process-local cache for safe explicitly public web assets.
 * No HTML, cookies, authorization responses, private assets or byte ranges.
 * Every entry is keyed with a tab capability and its current upstream cookie
 * context, and the map key is a hash (so browsing URLs are not logged).
 */
import { createHash } from 'node:crypto';
const MAX_ITEMS = 128;
const MAX_BYTES = 12 * 1024 * 1024;
const MAX_ITEM_BYTES = 512 * 1024;
const MAX_TTL_SECONDS = 600;
const entries = new Map();
let usedBytes = 0;
let hits = 0;
let misses = 0;
let evictions = 0;

function remove(key) {
  const entry = entries.get(key);
  if (!entry) return;
  usedBytes -= entry.body.length;
  entries.delete(key);
}

export function assetCacheKey(cap, remoteUrl, headers, cookie = '', referrer = '') {
  // Cache lookup includes every upstream-eligible request header to respect Vary.
  // The key is a digest only; raw header contents are never emitted in metrics.
  const eligible = ['accept', 'accept-language', 'range', 'if-range', 'if-none-match', 'if-modified-since', 'content-type', 'authorization', 'x-requested-with', 'user-agent'];
  const material = [cap, remoteUrl, cookie, referrer, ...eligible.map(name => name + ':' + String(headers[name] || ''))].join('\0');
  return createHash('sha256').update(material).digest('hex');
}
export function shouldCacheAsset({ method = 'GET', status = 200, type = '', responseHeaders = {}, requestHeaders = {}, hasUpstreamCookies = false } = {}) {
  if (method !== 'GET' || status !== 200 || hasUpstreamCookies) return 0;
  if (requestHeaders.range || requestHeaders.authorization || requestHeaders['if-range'] || requestHeaders['if-none-match'] || requestHeaders['if-modified-since']) return 0;
  if (responseHeaders['content-disposition']) return 0;
  // '*' means Vary depends on unspecified request metadata; cannot cache safely.
  if (String(responseHeaders.vary || '').split(',').some(name => name.trim() === '*')) return 0;
  const t = String(type).toLowerCase().split(';')[0].trim();
  if (!/^(image\/(?:png|jpeg|gif|webp|avif|svg\+xml)|font\/[^;]+|application\/(?:font-woff|font-woff2|wasm|javascript|x-javascript)|text\/(?:css|javascript))$/.test(t)) return 0;
  const control = String(responseHeaders['cache-control'] || '').toLowerCase();
  if (!/(?:^|,)\s*public(?:\s|,|$)/.test(control) || /(?:^|,)\s*(?:no-store|no-cache|private)(?:\s|,|$)/.test(control)) return 0;
  const max = control.match(/(?:^|,)\s*max-age\s*=\s*(\d+)/);
  if (!max) return 0;
  const ttl = Math.min(MAX_TTL_SECONDS, Number(max[1]));
  return ttl >= 10 ? ttl : 0;
}
export function readAsset(key, now = Date.now()) {
  const hit = entries.get(key);
  if (!hit || hit.expires <= now) {
    misses++;
    if (hit) remove(key);
    return null;
  }
  hits++;
  entries.delete(key);
  entries.set(key, hit); // LRU
  return { body: hit.body, headers: hit.headers, status: hit.status };
}
export function saveAsset(key, body, headers, ttlSeconds, now = Date.now()) {
  if (!Buffer.isBuffer(body) || body.length > MAX_ITEM_BYTES || body.length === 0 || ttlSeconds < 10) return false;
  if (entries.has(key)) remove(key);
  const headerCopy = {};
  for (const name of ['Content-Type','Content-Encoding','Content-Length','ETag','Last-Modified','Vary']) {
    if (typeof headers[name] === 'string') headerCopy[name] = headers[name];
  }
  while (entries.size >= MAX_ITEMS || usedBytes + body.length > MAX_BYTES) {
    const oldest = entries.keys().next().value;
    if (!oldest) break;
    remove(oldest); evictions++;
  }
  entries.set(key, { body: Buffer.from(body), headers: headerCopy, status: 200, expires: now + Math.min(ttlSeconds,MAX_TTL_SECONDS)*1000 });
  usedBytes += body.length;
  return true;
}
export function clearAssetCache() { entries.clear(); usedBytes = 0; }
export function assetCacheStats() {
  return { cacheEntries: entries.size, cacheMB: Number((usedBytes/1048576).toFixed(2)), cacheHits: hits, cacheMisses: misses, cacheEvictions: evictions };
}
