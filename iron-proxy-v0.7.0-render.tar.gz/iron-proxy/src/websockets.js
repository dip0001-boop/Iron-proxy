// Bounded WebSocket bridge. Server-side validation for every upstream socket.
import WebSocket, { WebSocketServer } from 'ws';
import { pinnedPublicLookup, decodeSocketPath } from './security.js';
import { getCap } from './sessions.js';

const wss = new WebSocketServer({ noServer: true, perMessageDeflate: false, maxPayload: 2_000_000, clientTracking: false });
const MAX_BUFFER = 4_000_000;
let openCount = 0;
let rejectedCount = 0;

function reject(socket, code = 403) {
  rejectedCount++;
  try { socket.end(`HTTP/1.1 ${code} Forbidden\r\nConnection: close\r\n\r\n`); } catch { socket.destroy(); }
}
export function websocketStats() { return { openWebSockets: openCount, rejectedWebSockets: rejectedCount }; }
export function acceptUpgrade(req, socket, head) {
  let parsed;
  try { parsed = decodeSocketPath(new URL(req.url, 'http://iron.local').pathname, new URL(req.url, 'http://iron.local').search); }
  catch { return reject(socket); }
  const tab = getCap(parsed.cap);
  if (!tab || tab.sockets.size >= 4) return reject(socket, 429);
  if (req.headers.origin && req.headers.origin !== 'null' && req.headers.origin !== `https://${req.headers.host}` && req.headers.origin !== `http://${req.headers.host}`) return reject(socket);
  socket.on('error', () => {});
  wss.handleUpgrade(req, socket, head, async browser => {
    tab.sockets.add(browser);
    openCount++;
    let upstream;
    let done = false;
    const queued = [];
    let queuedSize = 0;
    const finish = () => {
      if (done) return;
      done = true;
      openCount--;
      tab.sockets.delete(browser);
      if (browser.readyState === WebSocket.OPEN || browser.readyState === WebSocket.CONNECTING) browser.terminate();
      if (upstream && (upstream.readyState === WebSocket.OPEN || upstream.readyState === WebSocket.CONNECTING)) upstream.terminate();
    };
    browser.on('error', finish);
    browser.on('close', finish);
    try {
      const cookie = await tab.cookies.getCookieString(parsed.target.href);
      if (done) return;
      // Browser-sent protocols are forwarded as a validated list to the upstream.
      const rawProtocols = req.headers['sec-websocket-protocol'] || '';
      const protocols = String(rawProtocols).split(',').map(x => x.trim()).filter(x => /^[\w!#$%&'*+.^`|~-]{1,100}$/.test(x)).slice(0, 8);
      const headers = { Origin: parsed.target.origin.replace(/^ws/,'http') };
      if (cookie) headers.Cookie = cookie;
      upstream = new WebSocket(parsed.target.href, protocols, {
        handshakeTimeout: 10_000,
        maxPayload: 2_000_000,
        perMessageDeflate: false,
        followRedirects: false,
        lookup: pinnedPublicLookup,
        headers
      });
      upstream.on('open', () => {
        if (done) return upstream.terminate();
        for (const [data, binary] of queued) upstream.send(data, { binary }, err => { if (err) finish(); });
        queued.length = 0;
        queuedSize = 0;
      });
      upstream.on('message', (data, binary) => {
        if (done || browser.readyState !== WebSocket.OPEN) return;
        if (browser.bufferedAmount > MAX_BUFFER) return finish();
        browser.send(data, { binary }, err => { if (err) finish(); });
      });
      browser.on('message', (data, binary) => {
        if (done) return;
        if (upstream.readyState === WebSocket.CONNECTING) {
          queuedSize += data.length;
          if (queuedSize > 250_000 || queued.length >= 50) return finish();
          queued.push([data, binary]);
          return;
        }
        if (upstream.readyState !== WebSocket.OPEN) return;
        if (upstream.bufferedAmount > MAX_BUFFER) return finish();
        upstream.send(data, { binary }, err => { if (err) finish(); });
      });
      upstream.on('error', finish);
      upstream.on('close', finish);
    } catch { finish(); }
  });
}
