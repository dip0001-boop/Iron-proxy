import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';

const server = await readFile(new URL('../src/server.js', import.meta.url), 'utf8');

test('browser shell allows opaque sandboxed frames instead of requiring cross-origin isolation', () => {
  assert.match(server, /frame-src 'self' blob:/);
  assert.match(server, /'X-Frame-Options':'DENY'/);
  assert.doesNotMatch(server, /'Cross-Origin-Embedder-Policy'\s*:/);
  assert.doesNotMatch(server, /'Cross-Origin-Opener-Policy'\s*:/);
});
