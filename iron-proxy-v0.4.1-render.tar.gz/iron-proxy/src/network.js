import { Agent, request } from 'undici';
import { pipeline } from 'node:stream/promises';
import { gunzipSync, inflateSync, brotliDecompressSync } from 'node:zlib';
import { pinnedPublicLookup, validateTarget, browserProxyPath, decodeBrowserPath } from './security.js';
import { rewriteCss, rewriteHtml } from './rewriter.js';
import { rewriteJavaScript } from './javascript.js';
import { documentState } from './sessions.js';
import { scheduled } from './scheduler.js';

const agent = new Agent({
  connections: 8,
  pipelining: 1,
  keepAliveTimeout: 10_000,
  connect: { timeout: 8_000, lookup: pinnedPublicLookup },
  headersTimeout: 15_000,
  bodyTimeout: 90_000
});
const MAX_REWRITE = 6_000_000;
const passHeaders = new Set(['accept','accept-language','range','if-range','if-none-match','if-modified-since','content-type','authorization','x-requested-with','user-agent']);
const permittedMethods = new Set(['GET','HEAD','POST','PUT','PATCH','DELETE']);

// Undici's BodyReadable can emit UND_ERR_ABORTED asynchronously after destroy().
// When we intentionally discard a redirect or HEAD body, it is not piped to a
// destination stream, so register a listener BEFORE destroying it. Otherwise
// Node treats the emitted error as uncaught and terminates the entire server.
function discardUpstreamBody(body) {
  if (!body || body.destroyed) return;
  body.on('error', () => {});
  body.destroy();
}

// Restore the actual original-page Referer when a request comes from an
// IRON proxied document. Do not invent a browser identity or forge traffic.
// The client-provided referer must refer to THIS tab's routed document.
export function originalReferrer(req, tab) {
  try {
    const ref = new URL(String(req.headers.referer || ''));
    if (ref.host !== req.headers.host) return null;
    const route = decodeBrowserPath(ref.pathname, ref.search);
    return route.cap === tab.cap ? route.target : null;
  } catch { return null; }
}

function upstreamHeaders(req, url, jarCookie, referrer) {
  const headers = { 'accept-encoding': 'identity' };
  for (const [name, value] of Object.entries(req.headers)) {
    if (passHeaders.has(name) && typeof value === 'string') headers[name] = value;
  }
  if (jarCookie) headers.cookie = jarCookie;
  if (referrer) headers.referer = referrer.href;
  // Origin must reflect the requesting document, not always the destination.
  // This matters for real cross-origin form posts and normal site CSRF rules.
  if (['POST', 'PUT', 'PATCH', 'DELETE'].includes(req.method)) headers.origin = referrer?.origin || url.origin;
  return headers;
}

async function toLimitedBuffer(body, max = MAX_REWRITE) {
  let size = 0;
  const chunks = [];
  for await (const chunk of body) {
    size += chunk.length;
    if (size > max) {
      discardUpstreamBody(body);
      const e = new Error('Document exceeds safe rewrite limit'); e.statusCode = 413; throw e;
    }
    chunks.push(chunk);
  }
  return Buffer.concat(chunks);
}

function decoded(buffer, encoding) {
  if (!encoding || encoding === 'identity') return buffer;
  if (encoding === 'gzip') return gunzipSync(buffer, { maxOutputLength: MAX_REWRITE });
  if (encoding === 'deflate') return inflateSync(buffer, { maxOutputLength: MAX_REWRITE });
  if (encoding === 'br') return brotliDecompressSync(buffer, { maxOutputLength: MAX_REWRITE });
  throw new Error('Unsupported compressed upstream content');
}

function writeStandard(res, status) {
  res.statusCode = status;
  res.setHeader('Referrer-Policy', 'no-referrer');
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('Cache-Control', 'private, no-store');
  // Sandboxed iframe has an opaque origin. Requests from it require CORS.
  // No credentials are exposed to it: remote cookies live only in tab jars.
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Cross-Origin-Resource-Policy', 'cross-origin');
  res.setHeader('Access-Control-Expose-Headers', 'Content-Length, Content-Range, Accept-Ranges, ETag, Last-Modified');
}

export async function proxyRequest(req, res, tab, target) {
  return scheduled(() => executeRequest(req, res, tab, target));
}

async function executeRequest(req, res, tab, target) {
  if (!permittedMethods.has(req.method)) {
    res.writeHead(405, { Allow: 'GET, HEAD, POST, PUT, PATCH, DELETE' }).end('Method not allowed'); return;
  }
  if (['POST','PUT','PATCH','DELETE'].includes(req.method) && Number(req.headers['content-length'] || 0) > 8_000_000) {
    res.writeHead(413, { 'Content-Type':'text/plain', 'Cache-Control':'no-store' }).end('Upload too large'); return;
  }
  const url = validateTarget(target.href);
  const cookie = await tab.cookies.getCookieString(url.href);
  const referrer = originalReferrer(req, tab);
  const control = new AbortController();
  const abortIfClosed = () => { if (!res.writableFinished) control.abort(); };
  res.once('close', abortIfClosed);
  let upstream;
  try {
    upstream = await request(url, {
      dispatcher: agent,
      method: req.method,
      headers: upstreamHeaders(req, url, cookie, referrer),
      body: ['POST','PUT','PATCH','DELETE'].includes(req.method) ? req : undefined,
      maxRedirections: 0,
      headersTimeout: 15_000,
      bodyTimeout: 90_000,
      signal: control.signal
    });
  } catch (e) {
    res.removeListener('close', abortIfClosed);
    if (res.destroyed) return;
    res.writeHead(502, { 'Content-Type': 'text/plain; charset=utf-8', 'Cache-Control':'no-store' });
    res.end('IRON NETWORK could not connect to this website.');
    return;
  }
  // Attach before intentional body cancellation or pipeline shutdown.
  upstream.body?.on('error', () => {});
  // Store upstream cookies in the tab's private server-side jar.
  const setCookies = upstream.headers['set-cookie'];
  for (const item of (Array.isArray(setCookies) ? setCookies : setCookies ? [setCookies] : []).slice(0, 40)) {
    if ((tab.cookieWrites || 0) >= 2000) break;
    tab.cookieWrites = (tab.cookieWrites || 0) + 1;
    try { await tab.cookies.setCookie(item, url.href, { ignoreError: true }); } catch {}
  }

  const type = String(upstream.headers['content-type'] || 'application/octet-stream');
  const status = upstream.statusCode;
  writeStandard(res, status);
  // Never forward upstream cookies, CSP, frame policy, HSTS or auth challenges
  // to the proxy's own origin.
  res.setHeader('Content-Type', type);
  if (upstream.headers['content-disposition']) res.setHeader('Content-Disposition', String(upstream.headers['content-disposition']));
  if (upstream.headers['accept-ranges']) res.setHeader('Accept-Ranges', String(upstream.headers['accept-ranges']));
  if (upstream.headers['content-range']) res.setHeader('Content-Range', String(upstream.headers['content-range']));
  if (upstream.headers['etag']) res.setHeader('ETag', String(upstream.headers['etag']));
  if (upstream.headers['last-modified']) res.setHeader('Last-Modified', String(upstream.headers['last-modified']));
  if (upstream.headers['vary']) res.setHeader('Vary', String(upstream.headers['vary']));

  if (status >= 300 && status < 400 && upstream.headers.location) {
    let dest;
    try {
      dest = validateTarget(new URL(String(upstream.headers.location), url.href).href);
    } catch {
      discardUpstreamBody(upstream.body);
      res.statusCode = 403;
      res.removeHeader('Content-Type');
      res.setHeader('Content-Type', 'text/plain; charset=utf-8');
      res.end('IRON NETWORK blocked an unsafe redirect.');
      return;
    }
    res.setHeader('Location', browserProxyPath(tab.cap, dest.href));
    discardUpstreamBody(upstream.body);
    res.end();
    return;
  }
  const html = /(?:^|\s|;)text\/html(?:;|$)/i.test(type);
  const css = /(?:^|\s|;)text\/css(?:;|$)/i.test(type);
  const javascript = /(?:javascript|ecmascript)/i.test(type) && !/json/i.test(type);
  const transform = req.method !== 'HEAD' && status >= 200 && status !== 204 && status !== 206 && status !== 304 && !(status >= 300 && status < 400) && (html || css || javascript);
  if (transform) {
    try {
      const raw = await toLimitedBuffer(upstream.body);
      const text = decoded(raw, String(upstream.headers['content-encoding'] || '').toLowerCase()).toString('utf8');
      let result;
      if (html) {
        const doc = documentState(tab, url);
        const allCookies = await tab.cookies.getCookies(url.href);
        const visibleCookies = allCookies.filter(cookie => !cookie.httpOnly).map(cookie => cookie.key + '=' + cookie.value).join('; ');
        result = rewriteHtml(text, url.href, tab.cap, { ...doc, cookies: visibleCookies });
      } else if (css) result = rewriteCss(text, url.href, tab.cap);
      else result = rewriteJavaScript(text, url.href, tab.cap);
      res.setHeader('X-Iron-Transform', html ? 'html' : css ? 'css' : 'js');
      res.end(result);
    } catch (e) {
      if (!res.headersSent) {
        res.statusCode = e.statusCode || 502;
        res.setHeader('Content-Type', 'text/plain; charset=utf-8');
        res.end('IRON CORE could not safely rewrite this document.');
      } else res.destroy(e);
    }
  } else if (req.method === 'HEAD' || status === 204 || status === 304) {
    discardUpstreamBody(upstream.body);
    res.end();
  } else {
    if (upstream.headers['content-encoding']) res.setHeader('Content-Encoding', String(upstream.headers['content-encoding']));
    if (upstream.headers['content-length']) res.setHeader('Content-Length', String(upstream.headers['content-length']));
    try { await pipeline(upstream.body, res); }
    catch { if (!res.destroyed) res.destroy(); }
  }
}

export async function closeTransport() { await agent.close(); }
