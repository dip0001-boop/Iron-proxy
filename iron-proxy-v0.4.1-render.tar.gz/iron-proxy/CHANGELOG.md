# Changelog

## 0.3.0 — Browser Shell overhaul

- Rebuilt browser UI with horizontal draggable tabs, compact omnibox, bookmarks bar, modern new-tab page, overflow menu, responsive layouts and visual progress.
- Added true per-tab *history-free mode* (private flag only affects local history; other isolation stays as in normal tabs), closed-tab restore in-session, shortcuts, and title sync.
- Improved HTTP request context using original source referer + origin where available (not spoofed browser identity).
- Added JS AST rewriting for `new URL(x, import.meta.url)` literal asset references; best-effort remapping of `fetch(Request)` and EventSource URLs.
- Corrected invalid upstream SRI attributes for rewritten JS/CSS, enabled pointer-lock permission within isolated games.
- Added regression tests for UI pieces, referrer/origin mapping and AST asset resolution.

## 0.2.0 — Network and JS compatibility foundations

- JavaScript AST rewriting, HTTP range/media streaming, bounded WebSockets, virtual storage and frame bootstrap.

## 0.4.0
- Added real third-party Scramjet 2.x Compatibility Mode via Service Worker interception, Wisp, and libcurl transport.
- Retained IRON Native as an independent fallback and for opaque-origin private tabs.
- Added engine control, per-frame lifecycle, security limits on Wisp, and runtime fixture tests.
- Explicitly documented same-origin isolation tradeoff and third-party licensing.
