import test from 'node:test';
import assert from 'node:assert/strict';
import { spawn } from 'node:child_process';
import http from 'node:http';
import { setTimeout as delay } from 'node:timers/promises';

function startLocal(fn) {
  const server=http.createServer(fn);
  return new Promise(resolve => server.listen(0, '127.0.0.1', ()=>resolve(server)));
}
function stop(server) { return new Promise(resolve=>server.close(resolve)); }

test('live integration: login, isolate tabs, rewrite and stream assets', { timeout: 25_000 }, async () => {
  const fixture = await startLocal((req,res) => {
    if (req.url === '/page') {
      res.writeHead(200, { 'Content-Type':'text/html', 'Set-Cookie':'example=one; Path=/' });
      res.end('<h1>HELLO FROM FIXTURE</h1><img src="/image.png"><a href="/next">Next</a>');
    } else if (req.url === '/redirect') {
      res.writeHead(302, { 'Location': '/page', 'Content-Type': 'text/plain' });
      res.end('Redirect (discarded by IRON)');
    } else if (req.url === '/blocked-redirect') {
      res.writeHead(302, { 'Location': 'http://localhost/' });
      res.end('Blocked private destination');
    } else if (req.url === '/cookie') {
      res.writeHead(200, { 'Content-Type':'text/plain' }); res.end(req.headers.cookie || '(empty)');
    } else if (req.url === '/image.png') {
      res.writeHead(200, {'Content-Type':'image/png'});res.end(Buffer.from([137,80,78,71]));
    } else { res.writeHead(404);res.end('missing'); }
  });
  const port = fixture.address().port;
  const ironPort = await (async () => { const s=await startLocal((q,r)=>r.end()); const p=s.address().port;await stop(s);return p;})();
  const child = spawn(process.execPath, ['src/server.js'], {
    cwd: process.cwd(),
    env: {...process.env, PORT:String(ironPort), IRON_ACCESS_KEY:'integration-test-only-passphrase', NODE_ENV:'test', IRON_TEST_ALLOW_LOOPBACK:'1'},
    stdio:'ignore'
  });
  const root=`http://127.0.0.1:${ironPort}`;
  const call = async (path, cookie='', opts={}) => fetch(root+path,{...opts, headers:{'X-IRON-Client':'1',...(cookie?{Cookie:cookie}:{}),...opts.headers}});
  try {
    let ready=false;
    for(let i=0;i<80;i++) { try {const r=await fetch(root+'/healthz'); if(r.ok){ready=true;break;} } catch {} await delay(70); }
    assert.equal(ready,true,'server started');
    const bad=await call('/api/tabs','','POST'=== 'POST' ? {method:'POST'} : {});
    assert.equal(bad.status,401);
    const login=await call('/api/login','',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({password:'integration-test-only-passphrase'})});
    assert.equal(login.status,200);
    const cookie=login.headers.get('set-cookie').split(';')[0];
    const create=()=>call('/api/tabs',cookie,{method:'POST'}).then(r=>r.json());
    const a=await create(); const b=await create();
    const prefix=id=>`/p/${id}/http/127.0.0.1:${port}`;
    const page=await fetch(root+prefix(a.cap)+'/page');
    assert.equal(page.status,200);
    const text=await page.text();
    assert.match(text,/HELLO FROM FIXTURE/);
    assert.match(text,new RegExp(`/p/${a.cap}/http/127.0.0.1:${port}/image.png`));
    const readA=await fetch(root+prefix(a.cap)+'/cookie');
    assert.equal(await readA.text(),'example=one');
    const readB=await fetch(root+prefix(b.cap)+'/cookie');
    assert.equal(await readB.text(),'(empty)');
    const bin=await fetch(root+prefix(b.cap)+'/image.png');
    assert.equal(bin.status,200);
    assert.equal((await bin.arrayBuffer()).byteLength,4);
    // Regression: intentional Undici body cancellation must not crash Node.
    // redirect:'manual' verifies the proxied Location rather than following it.
    const moved=await fetch(root+prefix(a.cap)+'/redirect',{redirect:'manual'});
    assert.equal(moved.status,302);
    assert.equal(moved.headers.get('location'),prefix(a.cap)+'/page');
    assert.equal((await fetch(root+'/healthz')).status,200,'server alive after redirect body disposal');
    const blocked=await fetch(root+prefix(a.cap)+'/blocked-redirect',{redirect:'manual'});
    assert.equal(blocked.status,403);
    assert.equal((await fetch(root+'/healthz')).status,200,'server alive after unsafe redirect');
    const head=await fetch(root+prefix(a.cap)+'/page',{method:'HEAD'});
    assert.equal(head.status,200);
    assert.equal((await fetch(root+'/healthz')).status,200,'server alive after HEAD body disposal');
    const deleted=await call('/api/tabs/'+a.cap,cookie,{method:'DELETE'});
    assert.equal(deleted.status,200);
    assert.equal((await fetch(root+prefix(a.cap)+'/cookie')).status,403);
  } finally {
    child.kill('SIGTERM');
    await stop(fixture);
  }
});
