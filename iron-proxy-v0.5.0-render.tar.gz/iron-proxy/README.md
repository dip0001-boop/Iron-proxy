# IRON BROWSER v0.5.0 — Engineering Release

IRON is an experimental, hosted browser-style proxy application with two
**explicitly differentiated** runtimes:

- **IRON Native**: IRON's own Node.js request transport, HTML/CSS/JavaScript rewrites,
  bounded streaming, isolated tab cookie jars, limited storage shims.
- **Scramjet Compatibility**: an attributed third-party Service Worker + Wisp
  compatibility mode. Its iframe uses `allow-same-origin` and is **not safely
  isolated from the parent shell**. Do not use it for sensitive sessions.

This release is a stability and observability upgrade, not a claim of universal
website compatibility or of faster performance than UV/Rammerhead/Scramjet.

## First run

1. Install Node.js 22.19+ (Render uses a compatible Node version).
2. Run `npm install --omit=dev && npm run check && npm test`.
3. Create a long random `IRON_ACCESS_KEY` as an environment variable.
4. Run `npm start` (binds `0.0.0.0:${PORT:-10000}`).
5. Visit `/healthz` and verify `{"ok":true,"version":"0.5.0"}`.
6. Sign in with your own secret. Open **Diagnostics** for connection checks.

No Python is needed.

### Render deployment when the GitHub repository contains only a TAR.GZ file

Upload `iron-proxy-v0.5.0-render.tar.gz` to the repository root (not just a ZIP).

**Build command**:

```sh
tar -xzf iron-proxy-v0.5.0-render.tar.gz && cd iron-proxy && npm install --omit=dev && npm run check && npm test
```

**Start command**:

```sh
cd iron-proxy && npm start
```

Set `IRON_ACCESS_KEY` (required), `NODE_ENV=production`, and optionally
`BRAVE_SEARCH_API_KEY`. Keep **Root Directory** blank when the archive is at
repository root. Keep `/healthz` as the Render HTTP health-check path.

If you upload extracted source instead of the archive, use `npm install
--omit=dev && npm run check && npm test` and `npm start`, with `package.json`
at the root.

## What's actually new in v0.5

1. A bounded 12 MiB memory cache for *only* explicitly public static assets.
   It never caches HTML, ranges, private responses, authorization requests,
   or Set-Cookie responses. Cache keys include a tab's identity and upstream
   cookie context. Max object 512 KiB, max lifetime 10 minutes. Cache does not
   survive restarts and can be cleared via the Diagnostics panel.
2. Request-duration distributions, p50/p95, concurrency counts, rewritten
   byte counts and cache hit statistics. **No browsing URLs or credentials
   are retained in telemetry.** These numbers measure HTTP request processing,
   not full user-perceived page loading.
3. Authenticated, rate-limited connectivity tests with safe DNS/IP checks and
   explicit statuses, redirects and timeouts. A successful HEAD probe does not
   imply the full page works in IRON.
4. User-facing native failure pages instead of opaque 502 messages; clear retry.
5. Cancelled queued requests no longer consume scarce network slots.
6. 8 MiB inbound request body cap even for chunked uploads.
7. Real regression tests for cache isolation, expiry, scheduler cancellation,
   errors, upstream redirect handling, and authenticated HTTP probes.
8. Native is the recommended default for new installations. Compatibility mode
   requires an explicit acknowledgment of its isolation tradeoff.

### Known limitations / security requirements

- YouTube videos, sophisticated games, DRM, logins, CAPTCHAs, browser extensions,
  WebRTC, arbitrary popup windows, and modern anti-bot systems are not guaranteed.
- Browser shell frames are **not a native rendering engine**; Chrome renders
  the content, with rewriting/interception in front.
- Native and Compatibility have **different isolation properties**. Before
  exposing to outside paying customers, deploy compatibility rendering on a
  separate origin with independent cookies and complete security review.
- All logins/tabs are in memory; restarts sign everyone out. There are **no
  customer accounts, durable sessions, billing, backups, SLOs, or SLA** yet.
- Free Render plans may sleep; a service priced at $100/month needs measured
  uptime and a paid hosting plan.
- Scramjet is third-party, AGPL-3.0 licensed. Review `THIRD_PARTY.md` and the
  license obligations before commercial launch, including network source offers.
- Changing User-Agent doesn't solve IP reputation or bot challenges. IRON
  intentionally does not bypass CAPTCHA or forge browser credentials.

## Verification

`npm run check`: syntax validation.

`npm test`: Node integration, WebSocket, rewriting, security, frontend structure,
asset-cache, metrics and scheduler tests.

`npm run bench -- --target https://example.com --runs 20`: one-target HTTP
request sampler; this is **not** a comparative benchmark or browser E2E result.

Regression acceptance on Render: `/healthz` v0.5.0, native Wikipedia article
navigation, a 206 range response, no crash on redirects, cache hits observed,
connectivity lab, advanced tab still starts. For video/game failures, record
an exact site and failure and create a reproducible fixture before changing
more rewrite logic.

## Commercialization

See `COMMERCIAL-READINESS.md`. Do **not** market IRON as private, anonymous,
secure for banking, universally compatible, or better than established engines
without independent testing and hardening.
