/**
 * Bounded, FIFO HTTP scheduling with cancellation for abandoned page loads.
 * A queued navigation cannot consume a slot after its browser tab closes.
 */
const MAX_ACTIVE = 24;
const MAX_WAITING = 100;
let active = 0;
let cancelled = 0;
const waiting = [];

function capacityError() {
  const error = new Error('IRON NETWORK is busy. Retry in a moment.');
  error.statusCode = 503;
  return error;
}
function abortedError() {
  const error = new Error('Request cancelled');
  error.name = 'AbortError';
  error.statusCode = 499;
  return error;
}

export async function scheduled(run, signal = null) {
  if (signal?.aborted) throw abortedError();
  if (active >= MAX_ACTIVE) {
    if (waiting.length >= MAX_WAITING) throw capacityError();
    await new Promise((resolve, reject) => {
      const waiter = { resolve, reject, signal, listener: null };
      if (signal) {
        waiter.listener = () => {
          const i = waiting.indexOf(waiter);
          if (i < 0) return; // Slot was already transferred.
          waiting.splice(i, 1);
          cancelled++;
          reject(abortedError());
        };
        signal.addEventListener('abort', waiter.listener, { once: true });
        if (signal.aborted) { signal.removeEventListener('abort', waiter.listener); reject(abortedError()); return; }
      }
      waiting.push(waiter);
    });
  } else active++;
  try { return await run(); }
  finally {
    let waiter;
    while ((waiter = waiting.shift())) {
      if (waiter.listener) waiter.signal.removeEventListener('abort', waiter.listener);
      if (waiter.signal?.aborted) { cancelled++; waiter.reject(abortedError()); continue; }
      waiter.resolve();
      break;
    }
    if (!waiter) active--;
  }
}
export function schedulerStats() {
  return { activeRequests: active, queuedRequests: waiting.length, cancelledQueuedRequests: cancelled, maxConcurrentRequests: MAX_ACTIVE };
}
