import test from 'node:test';
import assert from 'node:assert/strict';
import { observeRequest, telemetrySnapshot, resetTelemetryForTests } from '../src/metrics.js';
import { siteErrorHtml } from '../src/errors.js';
import { scheduled, schedulerStats } from '../src/scheduler.js';

const delay = ms => new Promise(resolve => setTimeout(resolve, ms));

test('telemetry reports percentiles without retaining URLs or headers', () => {
  resetTelemetryForTests();
  for (const ms of [100, 200, 300, 400, 1000]) observeRequest({ durationMs: ms, status: 200, kind: 'rewritten', bytes: 128, url: 'https://private.example/secret' });
  observeRequest({ durationMs: 1200, status: 502, kind: 'other' });
  const data = telemetrySnapshot();
  assert.equal(data.requests, 6);
  assert.equal(data.successes, 5);
  assert.equal(data.upstreamErrors, 1);
  assert.equal(data.rewrittenDocuments, 5);
  assert.equal(data.bytesRewritten, 640);
  assert.equal(data.medianMs, 300);
  assert.equal(data.p95Ms, 1200);
  assert.equal(JSON.stringify(data).includes('private.example'),false);
});

test('error pages escape user-visible untrusted content', () => {
  const html = siteErrorHtml(502,'BROKEN','<script>alert(1)</script>');
  assert.ok(html.includes('&lt;script&gt;'));
  assert.equal(html.includes('<script>alert(1)</script>'), false);
  assert.match(html, /Retry page/);
});

test('scheduler cancels queued requests without consuming active slots', async () => {
  const controllers = Array.from({ length: 24 }, () => new AbortController());
  let release;
  const hold = new Promise(resolve => { release = resolve; });
  const running = controllers.map(() => scheduled(() => hold));
  const ctrl = new AbortController();
  const queued = scheduled(() => Promise.resolve('should never run'), ctrl.signal).catch(e => e.name);
  assert.equal(schedulerStats().activeRequests, 24);
  assert.equal(schedulerStats().queuedRequests, 1);
  ctrl.abort();
  assert.equal(await queued, 'AbortError');
  assert.equal(schedulerStats().queuedRequests, 0);
  release();
  await Promise.all(running);
  assert.equal(schedulerStats().activeRequests, 0);
});
