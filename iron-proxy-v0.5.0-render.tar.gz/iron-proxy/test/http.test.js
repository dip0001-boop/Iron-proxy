import test from 'node:test';
import assert from 'node:assert/strict';
import { spawn } from 'node:child_process';
import http from 'node:http';
import { setTimeout as delay } from 'node:timers/promises';
import WebSocket, { WebSocketServer } from 'ws';

function startLocal(fn) {
  const server=http.createServer(fn);
  return new Promise(resolve => server.listen(0, '127.0.0.1', ()=>resolve(server)));
}
function stop(server) { return new Promise(resolve=>server.close(resolve)); }

test('live integration: login, isolate tabs, rewrite and stream assets', { timeout: 25_000 }, async () => {
  let publicAssetHits = 0;
  const fixture = await startLocal((req,res) => {
    if (req.url === '/page') {
      res.writeHead(200, { 'Content-Type':'text/html', 'Set-Cookie':'example=one; Path=/' });
      res.end('<h1>HELLO FROM FIXTURE</h1><img src="/image.png"><a href="/next">Next</a><script type="module" src="/app.mjs"></script><video src="/clip.mp4"></video>');
    } else if (req.url === '/cache.png') {
      publicAssetHits++;
      res.writeHead(200, {'Content-Type':'image/png','Cache-Control':'public, max-age=120'});
      res.end(Buffer.from([1,2,3,4,5]));
    } else if (req.url === '/app.mjs') {
      res.writeHead(200, {'Content-Type':'application/javascript'});
      res.end('import "/helper.mjs"; export async function go(){ return import("/later.mjs"); }');
    } else if (req.url === '/clip.mp4') {
      if (req.headers.range === 'bytes=0-3') {
        res.writeHead(206, {'Content-Type':'video/mp4','Accept-Ranges':'bytes','Content-Range':'bytes 0-3/8','Content-Length':'4'});
        res.end(Buffer.from([1,2,3,4]));
      } else { res.writeHead(200, {'Content-Type':'video/mp4','Accept-Ranges':'bytes'}); res.end(Buffer.from([1,2,3,4,5,6,7,8])); }
    } else if (req.url === '/redirect') {
      res.writeHead(302, { 'Location': '/page', 'Content-Type': 'text/plain' });
      res.end('Redirect (discarded by IRON)');
    } else if (req.url === '/blocked-redirect') {
      res.writeHead(302, { 'Location': 'http://localhost/' });
      res.end('Blocked private destination');
    } else if (req.url === '/referer') {
      res.writeHead(200, { 'Content-Type':'text/plain' }); res.end(req.headers.referer || '(empty)');
    } else if (req.url === '/origin') {
      res.writeHead(200, { 'Content-Type':'text/plain' }); res.end(req.headers.origin || '(empty)');
    } else if (req.url === '/cookie') {
      res.writeHead(200, { 'Content-Type':'text/plain' }); res.end(req.headers.cookie || '(empty)');
    } else if (req.url === '/image.png') {
      res.writeHead(200, {'Content-Type':'image/png'});res.end(Buffer.from([137,80,78,71]));
    } else { res.writeHead(404);res.end('missing'); }
  });
  const upstreamWs = new WebSocketServer({ server: fixture, perMessageDeflate: false });
  upstreamWs.on('connection', ws => { ws.on('error', () => {}); ws.on('message', data => ws.send(data)); });
  const port = fixture.address().port;
  const ironPort = await (async () => { const s=await startLocal((q,r)=>r.end()); const p=s.address().port;await stop(s);return p;})();
  const child = spawn(process.execPath, ['src/server.js'], {
    cwd: process.cwd(),
    env: {...process.env, PORT:String(ironPort), IRON_ACCESS_KEY:'integration-test-only-passphrase', NODE_ENV:'test', IRON_TEST_ALLOW_LOOPBACK:'1'},
    stdio:'ignore'
  });
  const root=`http://127.0.0.1:${ironPort}`;
  const call = async (path, cookie='', opts={}) => fetch(root+path,{...opts, headers:{'X-IRON-Client':'1',...(cookie?{Cookie:cookie}:{}),...opts.headers}});
  try {
    let ready=false;
    for(let i=0;i<80;i++) { try {const r=await fetch(root+'/healthz'); if(r.ok){ready=true;break;} } catch {} await delay(70); }
    assert.equal(ready,true,'server started');
    const bad=await call('/api/tabs','','POST'=== 'POST' ? {method:'POST'} : {});
    assert.equal(bad.status,401);
    const login=await call('/api/login','',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({password:'integration-test-only-passphrase'})});
    assert.equal(login.status,200);
    const cookie=login.headers.get('set-cookie').split(';')[0];
    const probe=await call('/api/probe?url='+encodeURIComponent(`http://127.0.0.1:${port}/page`), cookie);
    assert.equal(probe.status,200,'Authenticated connectivity probe returns HTTP response');
    const probePayload=await probe.json();
    assert.equal(probePayload.reachable,true);
    assert.equal(probePayload.status,200);
    const rejectPrivate=await call('/api/probe?url='+encodeURIComponent('http://169.254.169.254/latest/meta-data'), cookie);
    assert.equal(rejectPrivate.status,400,'Probe cannot access cloud instance metadata');
    const create=()=>call('/api/tabs',cookie,{method:'POST'}).then(r=>r.json());
    const a=await create(); const b=await create();
    const prefix=id=>`/p/${id}/http/127.0.0.1:${port}`;
    const page=await fetch(root+prefix(a.cap)+'/page');
    assert.equal(page.status,200);
    const text=await page.text();
    assert.match(text,/HELLO FROM FIXTURE/);
    assert.match(text,new RegExp(`/p/${a.cap}/http/127.0.0.1:${port}/image.png`));
    const readA=await fetch(root+prefix(a.cap)+'/cookie');
    assert.equal(await readA.text(),'example=one');
    const readB=await fetch(root+prefix(b.cap)+'/cookie');
    assert.equal(await readB.text(),'(empty)');
    const ref=await fetch(root+prefix(a.cap)+'/referer', {headers:{Referer:root+prefix(a.cap)+'/page'}});
    assert.equal(await ref.text(),`http://127.0.0.1:${port}/page`,'original upstream referer preserved');
    const origin=await fetch(root+prefix(a.cap)+'/origin', {method:'POST',headers:{Referer:root+prefix(a.cap)+'/page'},body:'test'});
    assert.equal(await origin.text(),`http://127.0.0.1:${port}`,'original upstream origin preserved');
    const bin=await fetch(root+prefix(b.cap)+'/image.png');
    assert.equal(bin.status,200);
    assert.equal((await bin.arrayBuffer()).byteLength,4);
    const cachedOnce = await fetch(root+prefix(a.cap)+'/cache.png');
    assert.equal(cachedOnce.status,200);
    assert.equal(cachedOnce.headers.get('x-iron-cache'),null);
    const cachedTwice = await fetch(root+prefix(a.cap)+'/cache.png');
    assert.equal(cachedTwice.headers.get('x-iron-cache'),'HIT');
    assert.deepEqual(Buffer.from(await cachedTwice.arrayBuffer()), Buffer.from([1,2,3,4,5]));
    assert.equal(publicAssetHits,1,'second request served without network');
    const isolationRequest = await fetch(root+prefix(b.cap)+'/cache.png');
    assert.equal(isolationRequest.status,200);
    assert.equal(publicAssetHits,2,'other tabs cannot use cached content');
    const cleared = await call('/api/cache',cookie,{method:'DELETE'});
    assert.equal(cleared.status,200);
    await fetch(root+prefix(a.cap)+'/cache.png');
    assert.equal(publicAssetHits,3,'cache clearing discards saved objects');
    const js = await fetch(root+prefix(a.cap)+'/app.mjs');
    assert.equal(js.status,200);
    assert.equal(js.headers.get('x-iron-transform'),'js');
    assert.match(await js.text(), new RegExp(`/p/${a.cap}/http/127.0.0.1:${port}/helper.mjs`));
    const ranged = await fetch(root+prefix(a.cap)+'/clip.mp4',{ headers: { Range:'bytes=0-3' }});
    assert.equal(ranged.status,206);
    assert.equal(ranged.headers.get('content-range'),'bytes 0-3/8');
    assert.deepEqual(Buffer.from(await ranged.arrayBuffer()),Buffer.from([1,2,3,4]));
    const ticketMatch = text.match(/"ticket":"([a-f0-9]{32})"/);
    assert.ok(ticketMatch,'document gets storage ticket');
    const stateResponse = await fetch(root+`/_iron/state/${a.cap}/${ticketMatch[1]}`,{
      method:'POST',headers:{'Content-Type':'text/plain'},body:JSON.stringify({kind:'local',op:'set',key:'score',value:'27'})
    });
    assert.equal(stateResponse.status,200);
    const reloaded = await fetch(root+prefix(a.cap)+'/page');
    assert.match(await reloaded.text(),/"score":"27"/);
    const websocket = new WebSocket(`ws://127.0.0.1:${ironPort}/ws/${a.cap}/ws/127.0.0.1:${port}/echo`);
    try {
      await new Promise((resolve,reject) => { websocket.once('open', resolve); websocket.once('error', reject); });
      const echo = new Promise((resolve,reject) => { websocket.once('message', resolve); websocket.once('error', reject); });
      websocket.send('IRON WS ECHO');
      assert.equal((await echo).toString(),'IRON WS ECHO');
    } finally { websocket.close(); }
    // Regression: intentional Undici body cancellation must not crash Node.
    // redirect:'manual' verifies the proxied Location rather than following it.
    const moved=await fetch(root+prefix(a.cap)+'/redirect',{redirect:'manual'});
    assert.equal(moved.status,302);
    assert.equal(moved.headers.get('location'),prefix(a.cap)+'/page');
    assert.equal((await fetch(root+'/healthz')).status,200,'server alive after redirect body disposal');
    const blocked=await fetch(root+prefix(a.cap)+'/blocked-redirect',{redirect:'manual'});
    assert.equal(blocked.status,403);
    assert.equal((await fetch(root+'/healthz')).status,200,'server alive after unsafe redirect');
    const head=await fetch(root+prefix(a.cap)+'/page',{method:'HEAD'});
    assert.equal(head.status,200);
    assert.equal((await fetch(root+'/healthz')).status,200,'server alive after HEAD body disposal');
    const deleted=await call('/api/tabs/'+a.cap,cookie,{method:'DELETE'});
    assert.equal(deleted.status,200);
    assert.equal((await fetch(root+prefix(a.cap)+'/cookie')).status,403);
  } finally {
    child.kill('SIGTERM');
    for (const socket of upstreamWs.clients) socket.terminate();
    await new Promise(resolve=>upstreamWs.close(resolve));
    await stop(fixture);
  }
});
