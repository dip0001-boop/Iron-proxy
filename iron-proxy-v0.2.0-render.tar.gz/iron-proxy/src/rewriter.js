import * as parse5 from 'parse5';
import * as csstree from 'css-tree';
import { browserProxyPath } from './security.js';
import { bootScript } from './compat.js';
import { rewriteJavaScript } from './javascript.js';

const urlAttrs = new Set(['href', 'src', 'action', 'poster', 'data', 'formaction', 'cite', 'background', 'manifest', 'xlink:href']);

export function mapUrl(value, base, cap) {
  if (!value || /^\s*(?:data:|blob:|javascript:|mailto:|tel:|about:|#)/i.test(value)) return value;
  try {
    const u = new URL(value, base);
    if (!['http:', 'https:'].includes(u.protocol)) return value;
    return browserProxyPath(cap, u.href);
  } catch { return value; }
}

export function rewriteCss(css, base, cap) {
  try {
    const ast = csstree.parse(css, { parseValue: true, parseRulePrelude: false });
    csstree.walk(ast, (node) => {
      if (node.type === 'Url') {
        node.value = mapUrl(node.value, base, cap);
      }
      // @import 'file.css' is represented as a String node in an Atrule prelude.
      if (node.type === 'Atrule' && node.name.toLowerCase() === 'import' && node.prelude?.children) {
        const first = node.prelude.children.first;
        if (first?.type === 'String') first.value = mapUrl(first.value, base, cap);
      }
    });
    return csstree.generate(ast);
  } catch {
    // Fail closed on parsing failure: original stylesheet may be partly broken,
    // but we do not guess rewrites using a broad regex.
    return css;
  }
}

function rewriteSrcset(value, base, cap) {
  // Comma separation here covers ordinary srcset; data: URLs with commas are
  // retained and complex edge cases are documented as unsupported.
  return value.split(',').map(part => {
    const match = part.trim().match(/^(\S+)(\s+.*)?$/);
    return match ? mapUrl(match[1], base, cap) + (match[2] || '') : part;
  }).join(', ');
}

function getAttr(node, name) { return node.attrs?.find(a => a.name === name)?.value; }
function setAttr(node, name, value) {
  if (!node.attrs) node.attrs = [];
  const a = node.attrs.find(x => x.name === name);
  if (a) a.value = value;
  else node.attrs.push({ name, value });
}
function removeAttr(node, name) {
  if (node.attrs) node.attrs = node.attrs.filter(a => a.name !== name);
}

export function rewriteHtml(html, originalUrl, cap, state = {}, depth = 0) {
  const document = parse5.parse(html);
  let base = originalUrl;
  // Honor the first legitimate <base href>, but never let it point the iframe
  // outside IRON's routed paths.
  function findBase(node) {
    if (node.tagName === 'base' && getAttr(node, 'href')) {
      try { base = new URL(getAttr(node, 'href'), originalUrl).href; } catch {}
      return true;
    }
    for (const c of node.childNodes || []) if (findBase(c)) return true;
    return false;
  }
  findBase(document);

  function walk(node) {
    if (node.tagName) {
      for (const attr of node.attrs || []) {
        if (urlAttrs.has(attr.name)) attr.value = mapUrl(attr.value, base, cap);
        if (attr.name === 'srcset' || attr.name === 'imagesrcset') attr.value = rewriteSrcset(attr.value, base, cap);
        if (attr.name === 'style') attr.value = rewriteCss(attr.value, base, cap);
      }
      if (node.tagName === 'base') setAttr(node, 'href', mapUrl(base, base, cap));
      if (node.tagName === 'a' || node.tagName === 'form') {
        removeAttr(node, 'ping');
        if (getAttr(node, 'target')) setAttr(node, 'target', '_self');
      }
      if (node.tagName === 'iframe' && getAttr(node, 'srcdoc')) {
        const srcdoc = getAttr(node, 'srcdoc');
        if (depth === 0 && srcdoc.length < 100_000) setAttr(node, 'srcdoc', rewriteHtml(srcdoc, base, cap, state, depth + 1));
        else removeAttr(node, 'srcdoc');
      }
      if (node.tagName === 'script' && !getAttr(node, 'src')) {
        const type = (getAttr(node, 'type') || '').toLowerCase().trim();
        if (type === 'importmap' || type === 'application/importmap+json') {
          for (const c of node.childNodes || []) if (c.nodeName === '#text') {
            try {
              const obj = JSON.parse(c.value);
              const rewriteMap = entries => entries && Object.fromEntries(Object.entries(entries).map(([key, value]) => [key, typeof value === 'string' ? mapUrl(value, base, cap) : value]));
              obj.imports = rewriteMap(obj.imports);
              if (obj.scopes) obj.scopes = Object.fromEntries(Object.entries(obj.scopes).map(([key,value]) => [mapUrl(key, base, cap), rewriteMap(value)]));
              c.value = JSON.stringify(obj);
            } catch {}
          }
        } else if (!type || type === 'module' || /(?:javascript|ecmascript)/.test(type)) {
          for (const c of node.childNodes || []) if (c.nodeName === '#text') c.value = rewriteJavaScript(c.value, base, cap);
        }
      }
      if (node.tagName === 'meta' && (getAttr(node, 'http-equiv') || '').toLowerCase() === 'content-security-policy') {
        setAttr(node, 'content', '');
      }
      if (node.tagName === 'meta' && (getAttr(node, 'http-equiv') || '').toLowerCase() === 'refresh') {
        const content = getAttr(node, 'content') || '';
        const m = content.match(/^(\s*\d+\s*;\s*url\s*=\s*)(.+)$/i);
        if (m) setAttr(node, 'content', m[1] + mapUrl(m[2].replace(/^["']|["']$/g, ''), base, cap));
      }
      if (node.tagName === 'style') {
        for (const c of node.childNodes || []) if (c.nodeName === '#text') c.value = rewriteCss(c.value, base, cap);
      }
    }
    for (const c of node.childNodes || []) walk(c);
  }
  walk(document);

  const script = bootScript({ cap, remote: originalUrl, ticket: state.ticket || "", storage: state.storage || {}, cookies: state.cookies || "" });
  const fragment = parse5.parseFragment(`<script data-iron-bootstrap>${script.replace(/<\/script/gi, '<\\/script')}</script>`);
  let head;
  function seek(node) {
    if (node.tagName === 'head') { head = node; return; }
    for (const c of node.childNodes || []) if (!head) seek(c);
  }
  seek(document);
  if (head) {
    const inserted = fragment.childNodes[0];
    inserted.parentNode = head;
    head.childNodes.unshift(inserted);
  }
  return parse5.serialize(document);
}

