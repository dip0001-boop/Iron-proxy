// IRON CORE 0.2: bounded, conservative JavaScript AST rewriting.
// A failed parse leaves original code intact rather than emitting broken source.
import * as acorn from 'acorn';
import * as walk from 'acorn-walk';
import { mapUrl } from './rewriter.js';

export function rewriteJavaScript(source, remoteUrl, cap) {
  if (typeof source !== 'string' || source.length > 6_000_000) return source;
  let ast;
  try {
    ast = acorn.parse(source, { ecmaVersion: 'latest', sourceType: 'module', allowHashBang: true });
  } catch {
    try { ast = acorn.parse(source, { ecmaVersion: 'latest', sourceType: 'script', allowHashBang: true, allowReturnOutsideFunction: true }); }
    catch { return source; }
  }
  const edits = [];
  const rewriteLiteral = (literal) => {
    if (!literal || literal.type !== 'Literal' || typeof literal.value !== 'string') return;
    const mapped = mapUrl(literal.value, remoteUrl, cap);
    if (mapped !== literal.value) edits.push({ start: literal.start, end: literal.end, text: JSON.stringify(mapped) });
  };
  walk.full(ast, node => {
    if (node.type === 'ImportDeclaration' || node.type === 'ExportNamedDeclaration' || node.type === 'ExportAllDeclaration') rewriteLiteral(node.source);
    else if (node.type === 'ImportExpression') rewriteLiteral(node.source);
    else if (node.type === 'NewExpression' && node.callee.type === 'Identifier' &&
      ['Worker', 'SharedWorker'].includes(node.callee.name)) rewriteLiteral(node.arguments[0]);
    else if (node.type === 'CallExpression' && node.callee.type === 'Identifier' && node.callee.name === 'importScripts') {
      for (const argument of node.arguments) rewriteLiteral(argument);
    }
    // No generic rewriting of arbitrary strings or globals: it breaks apps.
  });
  edits.sort((a,b) => b.start - a.start);
  let previous = source.length + 1;
  for (const edit of edits) {
    if (edit.end > previous) continue;
    source = source.slice(0, edit.start) + edit.text + source.slice(edit.end);
    previous = edit.start;
  }
  return source;
}
