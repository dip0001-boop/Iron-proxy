# Changelog

## v0.2.0 (2026-10-28)

Experimental JS AST import rewriting, original-source-aware script bootstrap, dynamic asset setters, better fetch/Request/XHR compatibility, HTTP Range and media streaming without short total timeout, bounded WebSocket gateway, per-tab/origin state facade, embedded srcdoc and import maps, fuller diagnostics, build-gated regression tests. Universal site/media compatibility not established.

## v0.1.1

Undici aborted-response-body crash hotfix.

## v0.1.0

Initial independent IRON CORE routing, rewriting, network transport and browser shell.
