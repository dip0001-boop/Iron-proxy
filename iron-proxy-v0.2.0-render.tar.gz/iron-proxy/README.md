# IRON PROXY 0.2.0 — IRON CORE / IRON NETWORK / IRON BROWSER

**Experimental custom browser-proxy alpha. It is not Chrome, Chromium, a native rendering engine, or a rebranded UV/Rammerhead/Scramjet installation.** Browser rendering is still performed by the user's browser inside a sandboxed frame. Only use this with accounts and websites you are authorized to access. Not audited for sensitive data. A passing `/healthz` test does not establish website compatibility.

## Release highlights compared to v0.1.1

- **Native JavaScript AST transformer** (`src/javascript.js`) built with Acorn and acorn-walk. Rewrites static `import`, `export ... from`, string-literal dynamic imports, Worker constructor URL literals, and `importScripts()` string literals; leaves unparseable JS unchanged. Applies to inline JS scripts and external JavaScript responses. It is intentionally NOT a complete JS virtualization engine.
- **IRON runtime** (`src/compat.js`) now has URL mapping for `fetch`, `Request`, XHR, dynamically added asset `src/href/action/poster`, basic WebSocket construction, experimental Worker bootstrapping, form/navigation shim, history notifications, and a per-tab virtual `localStorage`, `sessionStorage`, and `document.cookie` facade. Remote HttpOnly cookies are never exposed to the facade.
- **WebSocket bridge** (`src/websockets.js`) via actively maintained `ws`: upstream DNS/IP validation, limited to four sockets per tab, 2 MB max frame payload, 4 MB buffer ceiling, 250 KB pre-connection queue, explicit cleanup on tab disposal; compression disabled to save memory.
- **Improved HTTP media transport**: Range and If-Range request forwarding, 206/Content-Range passthrough, streaming binary media without buffering or fixed 30-second total timeout, longer idle timeout, and optional fullscreen/autoplay frame permissions (browser policies still apply). Supports GET, HEAD, POST, PUT, PATCH, DELETE.
- **Document tickets** for each HTML view to limit storage mutations to its own original origin, instead of using a tab capability alone; storage is session-only, memory-limited, and cleared on tab disposal or server restart.
- **Navigation and embedded games**: preserve and rewrite small `srcdoc` HTML; transform JS import maps; source URLs created by many DOM APIs are remapped.
- **Regressions**: tests for transforms, media byte ranges, scoped storage, WS echo, redirects, and security validation; repeatable benchmark script retained.

## What is NOT fixed / NOT guaranteed

| Area | v0.2.0 status |
|---|---|
| Basic HTML & CSS | Implemented; real live sites still need tests |
| JavaScript imports / dynamically assigned src/href | Implemented targeted rewrites; incomplete JS APIs |
| HTML5 progressive MP4 with Range support | Transport implementation added; actual playback needs browser test |
| MediaSource / segmented video | May improve with better requests; not a complete MSE compatibility layer |
| YouTube videos | **Not verified.** Player scripts, origin/cross-site policies, signatures, authentication, DRM/EME and modern browser APIs may still prevent playback |
| HTML5 game assets & XHR/fetch | Partial support; test game-by-game |
| WebSockets | Implemented bounded tunnel; integration test supplied, not run in build environment |
| Web Workers | Experimental bootstrap; opaque origins and worker policies can still block them |
| localStorage/sessionStorage | In-memory per-tab emulation, not a full synchronous browser storage clone; snapshot updates may race |
| document.cookie | Best-effort per-origin in-page facade; HttpOnly remains server-side; cookie timing and scope edge cases remain |
| Service Workers, cross-origin isolation, SharedWorker | Unsupported |
| CAPTCHA / bot protection / Google search | **No bypass.** Google may challenge Render IPs. Configure Brave Search API for genuine omnibox results |
| DRM, OAuth, permissions, WebRTC, full browser extensions | Unsupported / unreliable |
| Benchmark leadership | **Not tested or claimed** |

## IMPORTANT SECURITY NOTE

The server uses a password login and per-tab bearer capability. Untrusted pages execute only in a sandboxed iframe **without** `allow-same-origin`. This is not a fully secure origin virtualization solution: it cannot perfectly reproduce the original site's native origin, cookies, navigation or permissions. A site may learn its own routing capability; any holder of a live capability can request public web resources through that tab. Never expose this as an anonymous open proxy, and do not put real passwords or sensitive information into proxied pages. DNS and IP restrictions limit SSRF but do not replace a security review. Logging is minimal by design. Render restarts erase server-side sessions, storage, and cookies.

## Deploy the compressed archive through GitHub → Render

This distribution is intended for the user's existing GitHub repo containing previous compressed releases and a Render Web Service configured with a build command.

1. Upload **`iron-proxy-v0.2.0-render.tar.gz`** to the TOP LEVEL of your GitHub repository using **Add file → Upload files**. Leave the older archives untouched so rolling back is easy.
2. Render → select the existing Iron-proxy Web Service → **Settings → Build & Deploy**.
3. Set **Build Command** exactly to:

   ```bash
   tar -xzf iron-proxy-v0.2.0-render.tar.gz && cd iron-proxy && npm install --omit=dev && npm test
   ```

4. Keep **Start Command** exactly `cd iron-proxy && npm start`, Root Directory blank, runtime Node.
5. KEEP the existing secret `IRON_ACCESS_KEY` environment variable. Never post it in chat or commit it to GitHub. Optional `BRAVE_SEARCH_API_KEY` enables the real omnibox search API. Set `NODE_ENV=production` (not test). Never set `IRON_TEST_ALLOW_LOOPBACK` on Render.
6. Click **Manual Deploy → Deploy latest commit**. The build will **stop without replacing your live release** if the test suite fails. Copy the failed test / build logs if that happens.
7. After successful deployment, `https://iron-proxy.onrender.com/healthz` should show version **`0.2.0`**. Keep the same application URL and login key.

For repos where the extracted files are at the root instead, use `npm install --omit=dev && npm test` and `npm start` without any `tar` or `cd`.

## Local development (Node >=22.19)

```bash
npm install
# set IRON_ACCESS_KEY in your environment to your own 16+ character secret
npm test
npm start
```

`npm run check` does JavaScript syntax checks. `npm run bench -- --base http://localhost:10000 --target https://example.com --runs 20` is the existing synthetic benchmark script, **not a page-render benchmark**.

## How to test the known failures

1. **Wikipedia**: search, click articles, back/forward, and open a second tab.
2. **Media**: inside IRON try the public sample at `https://www.w3schools.com/html/html5_video.asp`. If it plays, that verifies a basic HTML5 media path, not YouTube.
3. **YouTube**: browse videos, press play, test seek and sound; record errors or a 502/413 in the Render logs. Video playback is not guaranteed.
4. **Game**: select a specific HTML5 game and see whether script, texture, WebSocket, or WASM loads. Name the game and report whether it gets a blank screen, infinite loading, network error, or a crash.
5. **Google**: do not attempt to bypass or hammer challenges. Text search in IRON's own omnibox uses Brave Search API **only if configured**. Google's challenge can still appear for Google pages opened inside IRON.
6. **Built-in diagnostics**: Settings → Core/Diagnostics; active WebSocket count and request concurrency should update as websites load.

## Layout

```
iron-proxy/
  src/
    server.js       # auth, HTTP API, health, session state, upgrades
    network.js      # Undici HTTP transport, range/streaming, resource transforms
    security.js     # URL/IP validation, DNS pinning, WS path validation
    sessions.js     # logins, cookie jars, storage/tickets, tab disposal
    scheduler.js    # bounded connection concurrency
    rewriter.js     # parse5 HTML + CSSTree CSS rewriting
    javascript.js   # Acorn JS AST rewriting
    compat.js       # injected site compatibility runtime
    websockets.js   # bounded WS gateway
  public/
    index.html      # browser shell
    app.js          # tabs, search, history, bookmarks, diagnostics
    app.css         # original browser design system
  test/
    bootstrap.test.js
    core.test.js
    http.test.js
  scripts/bench.js
  package.json
  render.yaml
  .env.example
```

### Verification performed in source-building environment

- **Passed:** `node --check` JavaScript syntax on every project source/test file.
- **Passed:** `node --test test/bootstrap.test.js` for generated compatibility-bootstrap syntax and safe encoding.
- **Not performed here:** full `npm test`, live YouTube, game playback, external WebSocket handshake or competing-engine benchmarks. This environment could not access npm registry. Run the full suite in Render's build instead; any failing case requires a fix before release.

### Architecture

```
User's browser
  IRON BROWSER shell, privileged local UI
    └── sandboxed per-tab content frame (opaque origin)
          └── IRON CORE rewritten HTML/CSS/JS + compat shim
              ├── /p/<tabcap>/https/<host>/<path> → IRON NETWORK Undici → public HTTP/S
              ├── /ws/<tabcap>/wss/<host>/<path> → bounded ws bridge → public WS/S
              └── /_iron/state/<tabcap>/<docticket> → per-origin storage/cookie updates
```

Do not claim IRON is faster than Ultraviolet, Rammerhead or Scramjet without reproducible same-site benchmarks, and do not claim arbitrary websites are universally playable. IRON 0.2 is a larger compatibility alpha, not a finished browser engine.
